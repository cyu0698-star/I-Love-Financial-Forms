import svgPaths from "./svg-4dhgyxt7jf";

export default function Sidebar() {
  return (
    <div className="bg-[#fdffff] relative size-full" data-name="sidebar">
      <div className="flex flex-col items-center size-full">
        <div className="content-stretch flex flex-col items-center justify-between p-[24px] relative size-full">
          <div className="h-[102px] relative shrink-0 w-[67px]">
            <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 67 102">
              <g id="Frame 1261153161">
                <path d={svgPaths.p45f1300} fill="var(--fill-0, #0A6ED1)" id="Vector 15" />
                <path d="M0 78H67" id="Vector 2802" stroke="var(--stroke-0, #EBEBEB)" />
              </g>
            </svg>
          </div>
          <div className="content-stretch flex flex-col gap-[32px] items-center relative shrink-0 w-[52px]">
            <div className="bg-[#f5f9ff] content-stretch flex flex-col gap-[16px] items-center justify-center p-[8px] relative rounded-[4px] shrink-0">
              <div className="relative shrink-0 size-[34px]" data-name="File_dock_light">
                <div className="absolute inset-[0_5.23%_0_5.88%]">
                  <div className="absolute inset-[-2.21%_-2.48%]">
                    <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 31.7224 35.5">
                      <g id="Group 2516">
                        <path d={svgPaths.pcf6ec00} id="Rectangle 4012" stroke="var(--stroke-0, #0A6ED1)" strokeLinecap="round" strokeWidth="1.5" />
                        <path d={svgPaths.p102a6600} id="Vector 52" stroke="var(--stroke-0, #0A6ED1)" strokeLinecap="round" strokeWidth="1.5" />
                        <path d={svgPaths.p21818b00} id="Vector 53" stroke="var(--stroke-0, #0A6ED1)" strokeLinecap="round" strokeWidth="1.5" />
                        <path d={svgPaths.p20f87780} id="Vector 60" stroke="var(--stroke-0, #0A6ED1)" strokeLinecap="round" strokeWidth="1.5" />
                        <path d={svgPaths.p37fe3be0} id="Vector 61" stroke="var(--stroke-0, #0A6ED1)" strokeLinecap="round" strokeWidth="1.5" />
                        <path d={svgPaths.pdeca900} id="Vector 62" stroke="var(--stroke-0, #0A6ED1)" strokeLinecap="round" strokeWidth="1.5" />
                      </g>
                    </svg>
                  </div>
                </div>
              </div>
              <p className="font-['ABeeZee:Italic','Noto_Sans_JP:Regular',sans-serif] italic leading-[20px] relative shrink-0 text-[#0a6ed1] text-[13px] text-center whitespace-nowrap" style={{ fontVariationSettings: "'wght' 400" }}>
                文档生成
              </p>
            </div>
            <div className="content-stretch flex flex-col gap-[16px] items-center relative shrink-0 w-[34px]">
              <div className="aspect-[24/24] relative shrink-0 w-full" data-name="Basket_alt_3_light">
                <div className="absolute inset-[2.94%_0_0_0]">
                  <div className="absolute inset-[-2.27%_0_0_-2.21%]">
                    <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 34.7502 33.75">
                      <g id="Group 2515">
                        <path d={svgPaths.p3a8d2e00} id="Vector" stroke="var(--stroke-0, #475E75)" strokeLinecap="round" strokeWidth="1.5" />
                        <path d={svgPaths.p13f53800} id="Rectangle 41" stroke="var(--stroke-0, #475E75)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
                        <path d={svgPaths.p3c579d00} id="Vector 339" stroke="var(--stroke-0, #475E75)" strokeLinecap="round" strokeWidth="1.5" />
                        <ellipse cx="27.7501" cy="31.75" fill="var(--fill-0, #475E75)" id="Ellipse 167" rx="2.00001" ry="1.99997" />
                        <ellipse cx="11.7502" cy="31.75" fill="var(--fill-0, #475E75)" id="Ellipse 168" rx="2.00001" ry="1.99997" />
                      </g>
                    </svg>
                  </div>
                </div>
              </div>
              <div className="flex flex-col font-['ABeeZee:Italic','Noto_Sans_JP:Regular','Noto_Sans_SC:Regular',sans-serif] italic justify-center leading-[0] relative shrink-0 text-[#475e75] text-[13px] text-center w-full" style={{ fontVariationSettings: "'wght' 400" }}>
                <p className="leading-[20px]">充值</p>
              </div>
            </div>
          </div>
          <div className="relative rounded-[4px] shrink-0" data-name="卡片内边距16px/Variant2">
            <div className="flex flex-col items-center justify-center size-full">
              <div className="content-stretch flex flex-col gap-[16px] items-center justify-center px-[3px] py-[8px] relative">
                <div className="bg-[#0a6ed1] content-stretch flex items-center justify-center p-[13px] relative rounded-[25px] shrink-0 size-[34px]">
                  <p className="font-['DM_Sans:Regular',sans-serif] font-normal leading-[22px] relative shrink-0 text-[20px] text-white whitespace-nowrap" style={{ fontVariationSettings: "'opsz' 14" }}>
                    1
                  </p>
                </div>
                <div className="content-stretch flex flex-col items-center relative shrink-0 w-full">
                  <p className="font-['ABeeZee:Regular',sans-serif] leading-[18px] not-italic relative shrink-0 text-[#202d35] text-[12px] whitespace-nowrap">133******3</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}