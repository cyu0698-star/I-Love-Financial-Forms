import clsx from "clsx";
import svgPaths from "./svg-gdhy5jfmpw";
import img2025120512405121 from "figma:asset/0fb7738e99e722ceb1abac61599257cef011512c.png";
import img202510141739511 from "figma:asset/34905ae2c93e0c0205acb1ef4d5ff892fbd77e03.png";
type DatabaseHelperProps = {
  additionalClassNames?: string;
};

function DatabaseHelper({ children, additionalClassNames = "" }: React.PropsWithChildren<DatabaseHelperProps>) {
  return (
    <div className={clsx("absolute", additionalClassNames)}>
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 19 10">
        {children}
      </svg>
    </div>
  );
}
type WrapperProps = {
  additionalClassNames?: string;
};

function Wrapper({ children, additionalClassNames = "" }: React.PropsWithChildren<WrapperProps>) {
  return (
    <div style={{ fontVariationSettings: "'opsz' 14" }} className={clsx("flex flex-col font-normal justify-center leading-[0] relative shrink-0 text-[20px] whitespace-nowrap", additionalClassNames)}>
      <p className="leading-[22px]">{children}</p>
    </div>
  );
}
type Frame1261153139HelperProps = {
  additionalClassNames?: string;
};

function Frame1261153139Helper({ children, additionalClassNames = "" }: React.PropsWithChildren<Frame1261153139HelperProps>) {
  return (
    <div className={clsx("absolute flex items-center justify-center", additionalClassNames)}>
      <div className="-rotate-90 flex-none h-0 w-[1.5px]">
        <div className="relative size-full">
          <div className="absolute inset-[-1px_-23.53%]">
            <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 6.25 2">
              {children}
            </svg>
          </div>
        </div>
      </div>
    </div>
  );
}
type HelperProps = {
  additionalClassNames?: string;
};

function Helper({ additionalClassNames = "" }: HelperProps) {
  return (
    <div className={clsx("absolute", additionalClassNames)}>
      <div className="absolute inset-[-2.96%_-3.33%]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16 17.875">
          <g id="Group 2516">
            <path d={svgPaths.p11a1bf80} id="Rectangle 4012" stroke="var(--stroke-0, #222222)" strokeLinecap="round" />
            <path d="M12.6875 0.5L12.6875 6.125" id="Vector 52" stroke="var(--stroke-0, #222222)" strokeLinecap="round" />
            <path d="M15.5 3.3125L9.87502 3.3125" id="Vector 53" stroke="var(--stroke-0, #222222)" strokeLinecap="round" />
            <path d={svgPaths.p17912980} id="Vector 60" stroke="var(--stroke-0, #222222)" strokeLinecap="round" />
            <path d="M4.25009 6.125L8.00007 6.125" id="Vector 61" stroke="var(--stroke-0, #222222)" strokeLinecap="round" />
            <path d={svgPaths.p3d59d7a0} id="Vector 62" stroke="var(--stroke-0, #222222)" strokeLinecap="round" />
          </g>
        </svg>
      </div>
    </div>
  );
}
type Text1Props = {
  text: string;
  additionalClassNames?: string;
};

function Text1({ text, additionalClassNames = "" }: Text1Props) {
  return (
    <div className={clsx("absolute content-stretch flex flex-col items-start justify-center", additionalClassNames)}>
      <Wrapper additionalClassNames="font-['DM_Sans:Regular','Noto_Sans_JP:Regular','Noto_Sans_SC:Regular',sans-serif] text-[#1f2d3d] text-center">{text}</Wrapper>
    </div>
  );
}
type TextProps = {
  text: string;
  additionalClassNames?: string;
};

function Text({ text, additionalClassNames = "" }: TextProps) {
  return (
    <div className={clsx("absolute content-stretch flex flex-col items-start justify-center", additionalClassNames)}>
      <Wrapper additionalClassNames="font-['DM_Sans:Regular','Noto_Sans_SC:Regular','Noto_Sans_JP:Regular',sans-serif] text-[#1f2d3d] text-center">{text}</Wrapper>
    </div>
  );
}
type ImageProps = {
  additionalClassNames?: string;
};

function Image({ additionalClassNames = "" }: ImageProps) {
  return (
    <div className={clsx("absolute inset-0 overflow-hidden rounded-[4px]", additionalClassNames)}>
      <img alt="" className="absolute left-0 max-w-none size-full top-0" src={img2025120512405121} />
    </div>
  );
}

function Icon() {
  return (
    <div className="absolute inset-[12.5%]">
      <div className="absolute inset-[-5.56%]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 20 20">
          <path d={svgPaths.p3144a680} id="Icon" stroke="var(--stroke-0, black)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" />
        </svg>
      </div>
    </div>
  );
}

function Component7Download() {
  return (
    <div className="absolute aspect-[24/24] left-[25.41%] overflow-clip right-[65.95%] top-[6px]">
      <Icon />
    </div>
  );
}
type Component1Props = {
  className?: string;
  property1?: "Group 2471" | "Group 2473" | "Group 2474" | "Variant4" | "Variant5" | "Variant6" | "Variant7";
};

function Component1({ className, property1 = "Group 2471" }: Component1Props) {
  if (property1 === "Variant5") {
    return (
      <div className={className || "bg-[#0a6ed1] h-[36px] relative rounded-[4px]"} data-name="Property 1=Variant5">
        <div className="flex flex-row items-center justify-center size-full">
          <div className="content-stretch flex gap-[10px] h-full items-center justify-center px-[10px] py-[8px] relative">
            <div className="relative shrink-0 size-[12px]" data-name="Export_light">
              <div className="absolute inset-[0_0_0.01%_0]">
                <div className="absolute inset-[-5.89%_-4.17%_-4.17%_-4.17%]">
                  <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 13 13.2063">
                    <g id="Group 2478">
                      <path d={svgPaths.p4ccf900} id="Vector 9" stroke="var(--stroke-0, white)" strokeLinecap="round" />
                      <path d={svgPaths.p1233fb50} id="Vector 114" stroke="var(--stroke-0, white)" strokeLinecap="round" />
                    </g>
                  </svg>
                </div>
              </div>
            </div>
            <Wrapper additionalClassNames="font-['DM_Sans:Regular','Noto_Sans_JP:Regular','Noto_Sans_SC:Regular',sans-serif] text-white">在你的电脑中选择文件</Wrapper>
          </div>
        </div>
      </div>
    );
  }
  if (property1 === "Variant7") {
    return (
      <div className={className || "bg-[#0a6ed1] h-[36px] relative rounded-[4px] w-[185px]"} data-name="Property 1=Variant7">
        <div className="flex flex-row items-center justify-center size-full">
          <div className="content-stretch flex items-center justify-center px-[10px] py-[8px] relative size-full">
            <Wrapper additionalClassNames="font-['DM_Sans:Regular','Noto_Sans_JP:Regular',sans-serif] text-white">生成文档</Wrapper>
          </div>
        </div>
      </div>
    );
  }
  if (property1 === "Variant6") {
    return (
      <div className={className || "bg-[#0a6ed1] h-[36px] relative rounded-[4px] w-[185px]"} data-name="Property 1=Variant6">
        <div className="flex flex-row items-center justify-center size-full">
          <div className="content-stretch flex gap-[10px] items-center justify-center px-[10px] py-[8px] relative size-full">
            <div className="relative shrink-0 size-[12px]" data-name="按钮 - 区块标题/Component 7/Variant7">
              <div className="absolute inset-[-4.17%]">
                <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 13.0014 13.0002">
                  <path d={svgPaths.p9bb9c00} id="Star 1" stroke="var(--stroke-2, white)" />
                </svg>
              </div>
            </div>
            <Wrapper additionalClassNames="font-['DM_Sans:Regular','Noto_Sans_JP:Regular','Noto_Sans_SC:Regular',sans-serif] text-white">免费试用</Wrapper>
          </div>
        </div>
      </div>
    );
  }
  if (property1 === "Group 2473") {
    return (
      <button className={className || "block cursor-pointer h-[28px] relative w-[185px]"} data-name="Property 1=Group 2473">
        <div className="absolute bg-[#0854a0] inset-0 rounded-[4px]" />
        <div className="absolute contents inset-[17.86%_25.95%_21.43%_25.41%]">
          <Component7Download />
          <div className="absolute flex flex-col font-['Inter:Regular',sans-serif] font-normal inset-[17.86%_25.95%_21.43%_38.38%] justify-center leading-[0] not-italic text-[14px] text-left text-white whitespace-nowrap">
            <p className="leading-[normal]">Download</p>
          </div>
        </div>
      </button>
    );
  }
  if (property1 === "Group 2474") {
    return (
      <div className={className || "h-[28px] relative w-[185px]"} data-name="Property 1=Group 2474">
        <div className="absolute bg-[#063a73] inset-0 rounded-[4px]" />
        <div className="absolute contents inset-[17.86%_25.95%_21.43%_25.41%]">
          <Component7Download />
          <div className="absolute flex flex-col font-['Inter:Regular',sans-serif] font-normal inset-[17.86%_25.95%_21.43%_38.38%] justify-center leading-[0] not-italic text-[14px] text-white whitespace-nowrap">
            <p className="leading-[normal]">Download</p>
          </div>
        </div>
      </div>
    );
  }
  if (property1 === "Variant4") {
    return (
      <div className={className || "bg-[#bfddf4] h-[28px] relative w-[185px]"} data-name="Property 1=Variant4">
        <div className="absolute bg-[#bfddf4] inset-0 rounded-[4px]" />
        <div className="absolute contents inset-[17.86%_25.95%_21.43%_25.41%]">
          <Component7Download />
          <div className="absolute flex flex-col font-['Inter:Regular',sans-serif] font-normal inset-[17.86%_25.95%_21.43%_38.38%] justify-center leading-[0] not-italic text-[#a0a6b0] text-[14px] whitespace-nowrap">
            <p className="leading-[normal]">Download</p>
          </div>
        </div>
      </div>
    );
  }
  return (
    <div className={className || "h-[28px] relative w-[185px]"} data-name="Property 1=Group 2471">
      <div className="absolute bg-[#0a6ed1] inset-0 rounded-[4px]" />
      <div className="absolute content-stretch flex gap-[8px] items-center left-[47px] top-[5px]">
        <div className="overflow-clip relative shrink-0 size-[16px]" data-name="download-01">
          <Icon />
        </div>
        <div className="flex flex-col font-['Inter:Regular',sans-serif] font-normal justify-center leading-[0] not-italic relative shrink-0 text-[14px] text-white whitespace-nowrap">
          <p className="leading-[normal]">Download</p>
        </div>
      </div>
    </div>
  );
}

function Folder({ className }: { className?: string }) {
  return (
    <div className={className || "relative size-[24px]"} data-name="Folder">
      <div className="absolute inset-[18.75%_18.75%_22.92%_18.75%]">
        <div className="absolute inset-[-3.57%_-3.33%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16 15.0005">
            <path d={svgPaths.p21e68a60} id="Rectangle 4017" stroke="var(--stroke-0, #222222)" strokeLinecap="round" />
          </svg>
        </div>
      </div>
    </div>
  );
}

export default function Component() {
  return (
    <div className="bg-[#f2f4f7] relative size-full" data-name="文档生成 与 文档汇总">
      <div className="absolute bg-[#fefefe] content-stretch flex flex-col h-[720px] items-start left-[105px] rounded-[16px] top-[183px] w-[633px]">
        <div aria-hidden="true" className="absolute border border-[#e5ecf5] border-solid inset-0 pointer-events-none rounded-[16px]" />
        <div className="bg-[#fefefe] h-[720px] relative rounded-[16px] shrink-0 w-full" data-name="Component 15">
          <div aria-hidden="true" className="absolute border border-[#e5ecf5] border-solid inset-0 pointer-events-none rounded-[16px]" />
          <div className="absolute bg-[rgba(242,244,247,0)] inset-0 rounded-tl-[8px] rounded-tr-[8px]" />
          <div className="absolute flex flex-col font-['Inter:Medium','Noto_Sans_SC:Medium','Noto_Sans_JP:Medium',sans-serif] font-medium inset-0 justify-center leading-[1.5] not-italic text-[16px] text-[rgba(0,0,0,0.8)] text-center tracking-[-0.176px]">
            <p className="mb-0">单个/多个表单上传区域</p>
            <p>doc/pdf/ jpg/xlsx</p>
          </div>
          <div className="absolute bg-[#fefefe] content-stretch flex flex-col inset-0 items-start rounded-[16px]">
            <div aria-hidden="true" className="absolute border border-[#e5ecf5] border-solid inset-0 pointer-events-none rounded-[16px]" />
            <div className="bg-white content-stretch flex flex-col gap-[22px] h-[721px] items-center justify-center py-[75px] relative rounded-[16px] shrink-0 w-[633px]">
              <div aria-hidden="true" className="absolute border-3 border-[rgba(178,171,171,0.22)] border-solid inset-0 pointer-events-none rounded-[16px]" />
              <div className="bg-white content-stretch flex flex-col items-center relative rounded-[8px] shrink-0">
                <div className="h-[431px] pointer-events-none relative rounded-[4px] shrink-0 w-[305px]" data-name="截屏2025-12-05 12.40.51 21">
                  <Image />
                  <div aria-hidden="true" className="absolute border border-[#b8c2cc] border-solid inset-[-1px] rounded-[5px]" />
                </div>
              </div>
              <div className="content-stretch flex flex-col gap-[22px] h-[160px] items-center relative shrink-0">
                <div className="content-stretch flex flex-[1_0_0] gap-[22px] items-center justify-center min-h-px min-w-px relative w-full">
                  <div className="h-[120px] pointer-events-none relative rounded-[4px] shrink-0 w-[85px]" data-name="截屏2025-12-05 12.40.51 21">
                    <Image />
                    <div aria-hidden="true" className="absolute border border-[#b8c2cc] border-dashed inset-[-1px] rounded-[5px]" />
                  </div>
                  <div className="h-[120px] relative rounded-[4px] shrink-0 w-[85px]">
                    <Image additionalClassNames="pointer-events-none" />
                    <div className="absolute h-[121px] left-0 pointer-events-none rounded-[4px] top-0 w-[86px]" data-name="截屏2025-12-05 12.40.51 21">
                      <div aria-hidden="true" className="absolute inset-0 rounded-[4px]">
                        <Image />
                        <div className="absolute bg-[rgba(0,0,0,0.3)] inset-0 rounded-[4px]" />
                      </div>
                      <div aria-hidden="true" className="absolute border border-[#0a6ed1] border-solid inset-[-1px] rounded-[5px]" />
                    </div>
                    <div className="absolute left-[26px] size-[34px] top-[43px]" data-name="Trash_light">
                      <Frame1261153139Helper additionalClassNames="inset-[47.92%_60.42%_39.58%_39.58%]">
                        <path d="M1 1L5.25 1" id="Vector 8" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeWidth="2" />
                      </Frame1261153139Helper>
                      <Frame1261153139Helper additionalClassNames="inset-[47.92%_39.58%_39.58%_60.42%]">
                        <path d="M1 1L5.25 1" id="Vector 9" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeWidth="2" />
                      </Frame1261153139Helper>
                      <div className="absolute inset-[-2.94%_0]">
                        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 34 36">
                          <g id="Group 2504">
                            <path d={svgPaths.pbe2dc00} id="Rectangle 41" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeWidth="2" />
                            <path d={svgPaths.p1c095d50} id="Ellipse 45" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeWidth="2" />
                          </g>
                        </svg>
                      </div>
                    </div>
                  </div>
                  <div className="grid-cols-[max-content] grid-rows-[max-content] inline-grid leading-[0] place-items-start relative shrink-0">
                    <div className="col-1 h-[120px] ml-0 mt-0 relative row-1 w-[85px]" data-name="File upload">
                      <div className="absolute bg-white border border-[#d0d5dd] border-dashed h-[120px] left-0 rounded-[8px] top-0 w-[85px]" data-name="_File upload base">
                        <div className="absolute left-[24px] size-[34px] top-[42px]">
                          <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 34 34">
                            <g id="Group 2505">
                              <line id="Line 94" stroke="var(--stroke-0, #344054)" strokeLinecap="round" strokeWidth="2" x1="1" x2="33" y1="16" y2="16" />
                              <line id="Line 95" stroke="var(--stroke-0, #344054)" strokeLinecap="round" strokeWidth="2" x1="18" x2="18" y1="1" y2="33" />
                            </g>
                          </svg>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <p className="font-['ABeeZee:Regular','Noto_Sans_JP:Regular','Noto_Sans_SC:Regular',sans-serif] leading-[0] relative shrink-0 text-[#1e1e1e] text-[0px] text-[12px] whitespace-nowrap" style={{ fontVariationSettings: "'wght' 400" }}>
                  <span className="leading-[18px]">{`温馨提示：普通用户只能上传三页文档！想要上传更多文档请开通 `}</span>
                  <span className="[text-decoration-skip-ink:none] decoration-solid leading-[18px] text-[#0a6ed1] underline" style={{ fontVariationSettings: "'wght' 400" }}>
                    高级会员
                  </span>
                  <span className="leading-[18px] text-[#0a6ed1]">{` `}</span>
                  <span className="leading-[18px]">。</span>
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div className="absolute h-[998px] left-[1423px] top-[13px] w-[14px]">
        <div className="absolute bg-[#f4f5f6] border border-[#d9d9d9] border-solid inset-0 rounded-[10px]" />
        <div className="absolute bg-[#b7b8b8] inset-[0_0_38.45%_0] rounded-[10px]" />
      </div>
      <div className="absolute bg-white border border-[#838383] border-solid h-[1024px] left-[423px] overflow-clip top-[1263px] w-[1440px]" data-name="Job Production">
        <div className="absolute h-[1024px] right-[1210px] top-[-1px] w-[229px]">
          <div className="absolute bg-[#f4f5f6] border border-[#d9d9d9] border-solid bottom-0 left-0 top-0 w-[1440px]" />
          <div className="absolute content-stretch flex flex-col items-start left-[15px] top-[146px] w-[150px]">
            <div className="content-stretch flex flex-col gap-[42px] items-start relative shrink-0 w-full">
              <div className="relative shrink-0">
                <div className="flex flex-row items-center size-full">
                  <div className="content-stretch flex gap-[16px] items-center relative">
                    <div className="h-[24px] relative shrink-0" data-name="Home">
                      <div className="flex flex-row items-center justify-center size-full">
                        <div className="content-stretch flex h-full items-center justify-center px-[5px] py-[2px] relative">
                          <div className="h-[19px] relative shrink-0 w-[16px]">
                            <div className="absolute inset-[-5.26%_-6.25%]">
                              <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 18.0003 21">
                                <g id="Group 2468">
                                  <path d={svgPaths.p32493370} id="Rectangle 1" stroke="var(--stroke-2, #33363F)" strokeWidth="2" />
                                  <path d={svgPaths.pa0ef080} id="Vector 3" stroke="var(--stroke-0, #33363F)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" />
                                </g>
                              </svg>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div className="flex flex-col font-['Inter:Bold',sans-serif] font-bold justify-center leading-[0] not-italic relative shrink-0 text-[18px] text-black whitespace-nowrap">
                      <p className="leading-[normal]">Home</p>
                    </div>
                  </div>
                </div>
              </div>
              <div className="content-stretch flex gap-[16px] items-center relative shrink-0">
                <div className="relative shrink-0 size-[24px]" data-name="comment">
                  <div className="absolute h-[19.15px] left-[4px] top-[5px] w-[19.786px]" data-name="Union">
                    <div className="absolute inset-[-5.22%_-5.05%_-5.23%_-5.05%]">
                      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 21.7861 21.1521">
                        <path d={svgPaths.p3defd200} fill="var(--stroke-0, #222222)" id="Union" />
                      </svg>
                    </div>
                  </div>
                  <div className="absolute inset-[41.67%_20.83%_58.33%_37.5%]">
                    <div className="absolute inset-[-1px_-10%]">
                      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 12 2">
                        <path d="M1 1H11" id="Vector 7" stroke="var(--stroke-0, #222222)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" />
                      </svg>
                    </div>
                  </div>
                  <div className="absolute inset-[62.5%_37.5%_37.5%_37.5%]">
                    <div className="absolute inset-[-1px_-16.67%]">
                      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 8 2">
                        <path d="M1 1H7" id="Vector 9" stroke="var(--stroke-0, #222222)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" />
                      </svg>
                    </div>
                  </div>
                </div>
                <div className="flex flex-col font-['Inter:Bold',sans-serif] font-bold justify-center leading-[0] not-italic relative shrink-0 text-[18px] text-black whitespace-nowrap">
                  <p className="leading-[normal]">Chat</p>
                </div>
              </div>
              <div className="content-stretch flex gap-[16px] items-center relative shrink-0 w-full">
                <div className="relative shrink-0 size-[24px]" data-name="File_dock">
                  <div className="absolute inset-[12.5%_8.33%_-4.17%_20.83%]">
                    <div className="absolute inset-[-4.55%_-5.88%]">
                      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 19.0004 24.0005">
                        <path d={svgPaths.p3b8492c0} id="Rectangle 1" stroke="var(--stroke-3, #33363F)" strokeWidth="2" />
                      </svg>
                    </div>
                  </div>
                  <div className="absolute inset-[62.5%_29.17%_37.5%_41.67%]">
                    <div className="absolute inset-[-1px_-14.29%]">
                      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 9 2">
                        <path d="M1 1H8" id="Vector 55" stroke="var(--stroke-0, #33363F)" strokeLinecap="round" strokeWidth="2" />
                      </svg>
                    </div>
                  </div>
                  <div className="absolute inset-[83.33%_37.5%_16.67%_41.67%]">
                    <div className="absolute inset-[-1px_-20%]">
                      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 7 2">
                        <path d="M1 1H6" id="Vector 58" stroke="var(--stroke-0, #33363F)" strokeLinecap="round" strokeWidth="2" />
                      </svg>
                    </div>
                  </div>
                  <div className="absolute inset-[12.5%_8.33%_58.33%_62.5%]">
                    <div className="absolute inset-[0_0_-14.29%_-14.29%]">
                      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 8.00001 8.00001">
                        <path d={svgPaths.p1bcfd00} id="Rectangle 2" stroke="var(--stroke-0, #33363F)" strokeWidth="2" />
                      </svg>
                    </div>
                  </div>
                </div>
                <div className="flex flex-col font-['Inter:Bold',sans-serif] font-bold justify-center leading-[0] not-italic relative shrink-0 text-[18px] text-black whitespace-nowrap">
                  <p className="leading-[normal]">Library</p>
                </div>
              </div>
              <div className="content-stretch flex gap-[16px] items-start relative shrink-0 w-full">
                <div className="relative shrink-0 size-[24px]" data-name="Database">
                  <div className="absolute inset-[16.67%_8.33%_54.17%_20.83%]">
                    <div className="absolute inset-[-14.29%_-5.88%]">
                      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 19 9">
                        <ellipse cx="9.5" cy="4.5" id="Ellipse 109" rx="8.5" ry="3.5" stroke="var(--stroke-0, #33363F)" strokeWidth="2" />
                      </svg>
                    </div>
                  </div>
                  <div className="absolute inset-[62.5%_8.33%_4.17%_20.83%]">
                    <DatabaseHelper additionalClassNames="inset-[-12.5%_-5.88%]">
                      <path d={svgPaths.peb01480} id="Ellipse 110" stroke="var(--stroke-0, #33363F)" strokeLinecap="square" strokeWidth="2" />
                    </DatabaseHelper>
                  </div>
                  <div className="absolute inset-[33.33%_8.33%_29.17%_20.83%]">
                    <DatabaseHelper additionalClassNames="inset-[0_-5.88%_-11.11%_-5.88%]">
                      <path d={svgPaths.pccabc00} id="Ellipse 111" stroke="var(--stroke-0, #33363F)" strokeWidth="2" />
                    </DatabaseHelper>
                  </div>
                </div>
                <div className="flex flex-col font-['Inter:Bold',sans-serif] font-bold justify-center leading-[0] not-italic relative shrink-0 text-[18px] text-black w-[105px]">
                  <p className="leading-[normal] whitespace-pre-wrap">{`Company‘s  Analyse`}</p>
                </div>
              </div>
            </div>
          </div>
          <div className="absolute contents left-[15px] top-[36px]">
            <div className="absolute content-stretch flex items-center justify-between left-[15px] top-[36px] w-[196px]">
              <div className="grid-cols-[max-content] grid-rows-[max-content] inline-grid leading-[0] place-items-start relative shrink-0">
                <div className="col-1 ml-[3.02px] mt-0 relative row-1 size-[28.966px]">
                  <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 28.9655 28.9655">
                    <circle cx="14.4828" cy="14.4828" fill="var(--fill-0, #838383)" id="Ellipse 49" r="14.4828" />
                  </svg>
                </div>
                <div className="col-1 flex flex-col font-['Inter:Regular',sans-serif] font-normal h-[10.259px] justify-center ml-0 mt-[9.05px] not-italic relative row-1 text-[14px] text-black text-center w-[35px]">
                  <p className="leading-[normal]">Logo</p>
                </div>
              </div>
              <div className="relative shrink-0">
                <div className="flex flex-row items-center size-full">
                  <div className="content-stretch flex items-center relative">
                    <div className="content-stretch flex items-center justify-center overflow-clip px-[3px] py-[6px] relative shrink-0" data-name="lucide:sidebar-close">
                      <div className="relative shrink-0 size-[20px]" data-name="Group">
                        <div className="absolute inset-[-5%]">
                          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 22 22">
                            <g id="Group">
                              <path d={svgPaths.p3511c000} id="Vector" stroke="var(--stroke-0, #8F8F8F)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" />
                              <path d={svgPaths.p28ea85c0} id="Vector_2" stroke="var(--stroke-0, #8F8F8F)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" />
                            </g>
                          </svg>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div className="absolute content-stretch flex gap-[16px] items-center left-[15px] top-[975px]">
            <div className="relative shrink-0 size-[36px]">
              <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 36 36">
                <g id="Group 2379">
                  <circle cx="18" cy="18" fill="var(--fill-0, #D9D9D9)" id="Ellipse 31" r="18" />
                  <circle cx="17.6721" cy="11.7818" fill="var(--fill-0, #262628)" id="Ellipse 28" r="5.89091" />
                  <g id="Mask group">
                    <mask height="36" id="mask0_1_1064" maskUnits="userSpaceOnUse" style={{ maskType: "alpha" }} width="36" x="0" y="0">
                      <circle cx="18" cy="18" fill="var(--fill-0, #D9D9D9)" id="Ellipse 30" r="18" />
                    </mask>
                    <g mask="url(#mask0_1_1064)">
                      <ellipse cx="17.673" cy="31.091" fill="var(--fill-0, #262628)" id="Ellipse 29" rx="11.1273" ry="11.4545" />
                    </g>
                  </g>
                </g>
              </svg>
            </div>
            <div className="flex flex-col font-['Inter:Bold',sans-serif] font-bold justify-center leading-[0] not-italic relative shrink-0 text-[18px] text-black whitespace-nowrap">
              <p className="leading-[normal]">Yuqian Cheng</p>
            </div>
          </div>
        </div>
        <div className="-translate-y-1/2 absolute bg-[#fcfcfc] content-stretch flex h-[998px] items-start left-[228px] px-[26px] py-[28px] rounded-[12px] top-1/2 w-[1190px]">
          <div aria-hidden="true" className="absolute border border-[#d9d9d9] border-solid inset-0 pointer-events-none rounded-[12px]" />
          <div className="flex flex-col font-['Arial:Bold',sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[32px] text-black whitespace-nowrap">
            <p className="leading-[normal]">{`Title 1 -- 48 `}</p>
          </div>
        </div>
        <div className="absolute contents right-[2px] top-[12px]">
          <div className="absolute bg-[#f4f5f6] border border-[#d9d9d9] border-solid bottom-[13px] h-[998px] right-[3px] rounded-[10px] w-[7px]" />
          <div className="absolute bg-[#b7b8b8] h-[614.264px] right-[3px] rounded-[10px] top-[13px] w-[7px]" />
        </div>
        <div className="absolute content-stretch flex gap-[16px] items-start left-[329px] top-[128px] w-[700px]">
          <div className="h-[30px] relative shrink-0 w-[31px]" data-name="截屏2025-10-14 17.39.51 1">
            <img alt="" className="absolute inset-0 max-w-none object-cover pointer-events-none size-full" src={img202510141739511} />
          </div>
          <div className="content-stretch flex flex-col font-['Inter:Regular',sans-serif] font-normal gap-[24px] items-start leading-[0] not-italic relative shrink-0 text-black w-[660px]">
            <div className="flex flex-col h-[27px] justify-center relative shrink-0 text-[14px] text-right w-[109px]">
              <p className="leading-[normal]">2.03 PM, 15 Nov</p>
            </div>
            <div className="flex flex-col justify-center relative shrink-0 text-[18px] w-[660px]">
              <p className="leading-[normal]">Hi! What can I do for you?</p>
            </div>
          </div>
        </div>
        <div className="absolute content-stretch flex items-center justify-end left-[228px] top-[-1px] w-[800px]">
          <div className="content-stretch flex gap-[8px] items-center relative shrink-0">
            <div className="relative shrink-0 size-[24px]" data-name="clear">
              <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
                <g>
                  <path clipRule="evenodd" d={svgPaths.p1cdf4e00} fill="var(--fill-0, black)" fillRule="evenodd" id="icon" />
                  <path d={svgPaths.pe537b00} fill="var(--fill-0, black)" id="Star 1" />
                  <path d={svgPaths.p232d2b00} fill="var(--fill-0, black)" id="Star 2" />
                </g>
              </svg>
            </div>
            <div className="flex flex-col font-['Inter:Medium',sans-serif] font-medium justify-center leading-[0] not-italic relative shrink-0 text-[16px] text-black whitespace-nowrap">
              <p className="leading-[normal]">New dialog</p>
            </div>
          </div>
        </div>
        <div className="absolute left-[228px] top-[35px]" data-name="Input">
          <div className="flex flex-col items-center size-full">
            <div className="content-stretch flex flex-col gap-[4px] items-center relative">
              <div className="relative rounded-[8px] shrink-0 w-[800px]" data-name="Input-case">
                <div className="content-stretch flex flex-col items-start overflow-clip px-[16px] py-[12px] relative rounded-[inherit] w-full">
                  <div className="content-stretch flex gap-[8px] items-center relative shrink-0 w-full" data-name="Content">
                    <div className="relative shrink-0 size-[20px]" data-name="attatchment-01">
                      <div className="absolute flex inset-[6.36%_1.07%_-0.29%_5%] items-center justify-center">
                        <div className="-rotate-45 flex-none h-[10.281px] w-[21.6px]">
                          <div className="relative size-full" data-name="XMLID_6_">
                            <div className="absolute inset-[-8.75%_-4.17%]">
                              <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 19.5 10.0674">
                                <path d={svgPaths.p1399d700} id="XMLID_6_" stroke="var(--stroke-0, #919191)" strokeLinecap="round" strokeWidth="1.5" />
                              </svg>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div className="flex flex-[1_0_0] flex-col font-['Inter:Regular',sans-serif] font-normal justify-center leading-[0] min-h-px min-w-px not-italic relative text-[16px] text-black">
                      <p>
                        <span className="leading-[normal]">{`Send me prompt and request `}</span>
                        <span className="font-['Inter:Bold',sans-serif] font-bold leading-[normal] not-italic">ai chat</span>
                      </p>
                    </div>
                    <div className="relative shrink-0 size-[20px]" data-name="microphone-01">
                      <div className="absolute inset-[10%_18.32%]" data-name="Icon">
                        <div className="absolute inset-[-4.69%_-5.92%]">
                          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 14.1704 17.5">
                            <path d={svgPaths.p332ff900} id="Icon" stroke="var(--stroke-0, #919191)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
                          </svg>
                        </div>
                      </div>
                    </div>
                    <div className="relative shrink-0 size-[20px]" data-name="telegram-fill">
                      <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 20 20">
                        <g id="telegram-fill">
                          <path d={svgPaths.p3db98af0} fill="var(--fill-0, black)" id="Vector" />
                        </g>
                      </svg>
                    </div>
                  </div>
                </div>
                <div aria-hidden="true" className="absolute border border-[#e7e7e7] border-solid inset-0 pointer-events-none rounded-[8px]" />
              </div>
            </div>
          </div>
        </div>
      </div>
      <div className="absolute bg-[#fdffff] h-[1024px] right-[1359px] top-0 w-[81px]" data-name="sidebar">
        <div className="flex flex-col items-center size-full">
          <div className="content-stretch flex flex-col items-center justify-between p-[24px] relative size-full">
            <div className="h-[102px] relative shrink-0 w-[67px]">
              <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 67 102">
                <g id="Frame 1261153161">
                  <path d={svgPaths.p45f1300} fill="var(--fill-0, #0A6ED1)" id="Vector 15" />
                  <path d="M0 78H67" id="Vector 2802" stroke="var(--stroke-0, #EBEBEB)" />
                </g>
              </svg>
            </div>
            <div className="content-stretch flex flex-col gap-[32px] items-center relative shrink-0 w-[52px]">
              <div className="bg-[#f5f9ff] content-stretch flex flex-col gap-[16px] items-center justify-center p-[8px] relative rounded-[4px] shrink-0">
                <div className="relative shrink-0 size-[34px]" data-name="File_dock_light">
                  <div className="absolute inset-[0_5.23%_0_5.88%]">
                    <div className="absolute inset-[-2.21%_-2.48%]">
                      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 31.7224 35.5">
                        <g id="Group 2516">
                          <path d={svgPaths.pcf6ec00} id="Rectangle 4012" stroke="var(--stroke-0, #0A6ED1)" strokeLinecap="round" strokeWidth="1.5" />
                          <path d={svgPaths.p102a6600} id="Vector 52" stroke="var(--stroke-0, #0A6ED1)" strokeLinecap="round" strokeWidth="1.5" />
                          <path d={svgPaths.p21818b00} id="Vector 53" stroke="var(--stroke-0, #0A6ED1)" strokeLinecap="round" strokeWidth="1.5" />
                          <path d={svgPaths.p20f87780} id="Vector 60" stroke="var(--stroke-0, #0A6ED1)" strokeLinecap="round" strokeWidth="1.5" />
                          <path d={svgPaths.p37fe3be0} id="Vector 61" stroke="var(--stroke-0, #0A6ED1)" strokeLinecap="round" strokeWidth="1.5" />
                          <path d={svgPaths.pdeca900} id="Vector 62" stroke="var(--stroke-0, #0A6ED1)" strokeLinecap="round" strokeWidth="1.5" />
                        </g>
                      </svg>
                    </div>
                  </div>
                </div>
                <p className="font-['ABeeZee:Italic','Noto_Sans_JP:Regular',sans-serif] italic leading-[20px] relative shrink-0 text-[#0a6ed1] text-[13px] text-center whitespace-nowrap" style={{ fontVariationSettings: "'wght' 400" }}>
                  文档生成
                </p>
              </div>
              <div className="content-stretch flex flex-col gap-[16px] items-center relative shrink-0 w-[34px]">
                <div className="aspect-[24/24] relative shrink-0 w-full" data-name="Basket_alt_3_light">
                  <div className="absolute inset-[2.94%_0_0_0]">
                    <div className="absolute inset-[-2.27%_0_0_-2.21%]">
                      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 34.7502 33.75">
                        <g id="Group 2515">
                          <path d={svgPaths.p3a8d2e00} id="Vector" stroke="var(--stroke-0, #475E75)" strokeLinecap="round" strokeWidth="1.5" />
                          <path d={svgPaths.p13f53800} id="Rectangle 41" stroke="var(--stroke-0, #475E75)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
                          <path d={svgPaths.p3c579d00} id="Vector 339" stroke="var(--stroke-0, #475E75)" strokeLinecap="round" strokeWidth="1.5" />
                          <ellipse cx="27.7501" cy="31.75" fill="var(--fill-0, #475E75)" id="Ellipse 167" rx="2.00001" ry="1.99997" />
                          <ellipse cx="11.7502" cy="31.75" fill="var(--fill-0, #475E75)" id="Ellipse 168" rx="2.00001" ry="1.99997" />
                        </g>
                      </svg>
                    </div>
                  </div>
                </div>
                <div className="flex flex-col font-['ABeeZee:Italic','Noto_Sans_JP:Regular','Noto_Sans_SC:Regular',sans-serif] italic justify-center leading-[0] relative shrink-0 text-[#475e75] text-[13px] text-center w-full" style={{ fontVariationSettings: "'wght' 400" }}>
                  <p className="leading-[20px]">充值</p>
                </div>
              </div>
            </div>
            <div className="relative rounded-[4px] shrink-0" data-name="卡片内边距16px/Variant2">
              <div className="flex flex-col items-center justify-center size-full">
                <div className="content-stretch flex flex-col gap-[16px] items-center justify-center px-[3px] py-[8px] relative">
                  <div className="bg-[#0a6ed1] content-stretch flex items-center justify-center p-[13px] relative rounded-[25px] shrink-0 size-[34px]">
                    <p className="font-['DM_Sans:Regular',sans-serif] font-normal leading-[22px] relative shrink-0 text-[20px] text-white whitespace-nowrap" style={{ fontVariationSettings: "'opsz' 14" }}>
                      1
                    </p>
                  </div>
                  <div className="content-stretch flex flex-col items-center relative shrink-0 w-full">
                    <p className="font-['ABeeZee:Regular',sans-serif] leading-[18px] not-italic relative shrink-0 text-[#202d35] text-[12px] whitespace-nowrap">133******3</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div className="-translate-y-1/2 absolute flex flex-col font-['Arial:Bold','Noto_Sans_JP:Bold','Noto_Sans_SC:Bold',sans-serif] h-[53px] justify-center leading-[0] left-[105px] text-[40px] text-black top-[66.5px] w-[260px]" style={{ fontVariationSettings: "'wght' 700" }}>
        <p className="leading-[normal]">上传与识别</p>
      </div>
      <div className="-translate-y-1/2 absolute flex flex-col font-['DM_Sans:Regular','Noto_Sans_JP:Regular','Noto_Sans_SC:Regular',sans-serif] font-normal h-[31px] justify-center leading-[0] left-[105px] text-[#1f2d3d] text-[20px] top-[117.5px] w-[577px]" style={{ fontVariationSettings: "'opsz' 14" }}>
        <p className="leading-[22px]">将上传的文件匹配合适模版，生成标准化财务文件。</p>
      </div>
      <div className="absolute bg-white h-[64px] left-[105px] rounded-[16px] top-[932px] w-[1242px]">
        <div aria-hidden="true" className="absolute border-3 border-[rgba(178,171,171,0.22)] border-solid inset-0 pointer-events-none rounded-[16px]" />
        <div className="flex flex-row items-center size-full">
          <div className="content-stretch flex items-center justify-between leading-[0] px-[66px] py-[74px] relative size-full">
            <div className="flex flex-col font-['DM_Sans:Regular','Noto_Sans_JP:Regular','Noto_Sans_SC:Regular',sans-serif] font-normal justify-center relative shrink-0 text-[#1f2d3d] text-[20px] text-center whitespace-nowrap" style={{ fontVariationSettings: "'opsz' 14" }}>
              <p className="leading-[22px]">当前状态：已上传3个文档</p>
            </div>
            <div className="grid-cols-[max-content] grid-rows-[max-content] inline-grid place-items-start relative shrink-0">
              <div className="col-1 flex flex-col font-['DM_Sans:Regular','Noto_Sans_JP:Regular','Noto_Sans_SC:Regular',sans-serif] font-normal justify-center ml-0 mt-[7px] relative row-1 text-[#1f2d3d] text-[20px] text-center whitespace-nowrap" style={{ fontVariationSettings: "'opsz' 14" }}>
                <p className="leading-[22px]">下一步：选择模版进行生成</p>
              </div>
              <div className="bg-[#919191] col-1 content-stretch flex h-[36px] items-center justify-center ml-[280px] mt-0 relative rounded-[10px] row-1 shadow-[0px_1px_3px_0px_rgba(0,0,0,0.1),0px_1px_2px_0px_rgba(0,0,0,0.1)] w-[185px]" data-name="Component 7">
                <Wrapper additionalClassNames="font-['DM_Sans:Regular','Noto_Sans_JP:Regular',sans-serif] text-white">开始生成</Wrapper>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div className="absolute contents left-[779px] top-[183px]">
        <div className="absolute bg-white border-3 border-[rgba(178,171,171,0.22)] border-solid h-[720px] left-[779px] rounded-[16px] top-[183px] w-[568px]" />
        <div className="absolute content-stretch flex flex-col gap-[8px] items-start left-[822px] top-[237px] w-[508px]">
          <p className="font-['DM_Sans:Bold','Noto_Sans_JP:Bold','Noto_Sans_SC:Bold',sans-serif] font-bold leading-[24px] relative shrink-0 text-[#101828] text-[22px] w-full" style={{ fontVariationSettings: "'opsz' 14" }}>
            模版选择
          </p>
          <p className="font-['ABeeZee:Regular','Noto_Sans_JP:Regular','Noto_Sans_SC:Regular',sans-serif] leading-[18px] relative shrink-0 text-[#344054] text-[12px] w-full" style={{ fontVariationSettings: "'wght' 400" }}>
            每次最多可上传一个文件，单个文件大小上限为50 MB。
          </p>
        </div>
        <p className="absolute font-['DM_Sans:Bold','Noto_Sans_SC:Bold','Noto_Sans_JP:Bold',sans-serif] font-bold leading-[24px] left-[822px] text-[#101828] text-[22px] top-[343px] whitespace-nowrap" style={{ fontVariationSettings: "'opsz' 14" }}>
          销售业务
        </p>
        <div className="absolute bg-[rgba(217,217,217,0)] border border-[#c9cdd4] border-solid h-[66px] left-[820px] rounded-[5px] top-[390px] w-[213px]" />
        <div className="absolute bg-[rgba(217,217,217,0)] border border-[#c9cdd4] border-solid h-[66px] left-[1077px] rounded-[5px] top-[390px] w-[213px]" />
        <Folder className="absolute left-[838px] size-[24px] top-[408px]" />
        <Folder className="absolute left-[1095px] size-[24px] top-[408px]" />
        <Text text="送货单" additionalClassNames="left-[880px] top-[409px]" />
        <div className="absolute content-stretch flex flex-col items-start justify-center left-[1137px] top-[409px]">
          <Wrapper additionalClassNames="font-['DM_Sans:Regular','Noto_Sans_SC:Regular','Noto_Sans_KR:Regular',sans-serif] text-[#1f2d3d] text-center">对账单</Wrapper>
        </div>
        <div className="absolute bg-[rgba(217,217,217,0)] border border-[#c9cdd4] border-solid h-[66px] left-[822px] rounded-[5px] top-[504px] w-[213px]" />
        <div className="absolute bg-[rgba(217,217,217,0)] border border-[#c9cdd4] border-solid h-[66px] left-[1076px] rounded-[5px] top-[504px] w-[213px]" />
        <Folder className="absolute left-[840px] size-[24px] top-[522px]" />
        <Text text="采购单" additionalClassNames="left-[882px] top-[523px]" />
        <Text1 text="上传新模版" additionalClassNames="left-[1136px] top-[523px]" />
        <Helper additionalClassNames="inset-[51.37%_22.57%_46.98%_76.39%]" />
        <p className="absolute font-['DM_Sans:Bold','Noto_Sans_SC:Bold',sans-serif] font-bold leading-[24px] left-[824px] text-[#101828] text-[22px] top-[618px] whitespace-nowrap" style={{ fontVariationSettings: "'opsz' 14" }}>
          财务业务
        </p>
        <div className="absolute bg-[rgba(217,217,217,0)] border border-[#c9cdd4] border-solid h-[66px] left-[822px] rounded-[5px] top-[665px] w-[213px]" />
        <div className="absolute bg-[rgba(217,217,217,0)] border border-[#c9cdd4] border-solid h-[66px] left-[1079px] rounded-[5px] top-[665px] w-[213px]" />
        <Folder className="absolute left-[840px] size-[24px] top-[683px]" />
        <Folder className="absolute left-[1097px] size-[24px] top-[683px]" />
        <div className="absolute content-stretch flex flex-col items-start justify-center left-[882px] top-[684px]">
          <Wrapper additionalClassNames="font-['DM_Sans:Regular','Noto_Sans_KR:Regular','Noto_Sans_SC:Regular','Noto_Sans_JP:Regular',sans-serif] text-[#1f2d3d] text-center">流水对账</Wrapper>
        </div>
        <Text text="支付清单" additionalClassNames="left-[1139px] top-[684px]" />
        <div className="absolute bg-[#f5f9ff] border border-[#9daac1] border-solid h-[66px] left-[822px] rounded-[5px] top-[775px] w-[213px]" />
        <Text1 text="上传新模版" additionalClassNames="left-[882px] top-[794px]" />
        <Helper additionalClassNames="inset-[77.83%_40.21%_20.52%_58.75%]" />
      </div>
      <Component1 className="absolute bg-[#0a6ed1] h-[36px] left-[1129px] rounded-[4px] top-[40px] w-[185px]" property1="Variant6" />
    </div>
  );
}