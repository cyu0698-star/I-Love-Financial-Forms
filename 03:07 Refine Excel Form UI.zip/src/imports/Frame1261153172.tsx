import clsx from "clsx";
import svgPaths from "./svg-93aoxqw88r";
import imgFrame1261153172 from "figma:asset/0fb7738e99e722ceb1abac61599257cef011512c.png";
import imgFrame1261153173 from "figma:asset/14eea5e08583b4a4335db2517629d4f259db18e4.png";
type Frame1261153172Helper1Props = {
  additionalClassNames?: string;
};

function Frame1261153172Helper1({ children, additionalClassNames = "" }: React.PropsWithChildren<Frame1261153172Helper1Props>) {
  return (
    <div className={clsx("absolute flex items-center justify-center", additionalClassNames)}>
      <div className="-rotate-90 flex-none h-0 w-[1.5px]">
        <div className="relative size-full">
          <div className="absolute inset-[-1px_-12.5%]">
            <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 10 2">
              {children}
            </svg>
          </div>
        </div>
      </div>
    </div>
  );
}
type Frame1261153172HelperProps = {
  additionalClassNames?: string;
};

function Frame1261153172Helper({ additionalClassNames = "" }: Frame1261153172HelperProps) {
  return (
    <div className={clsx("absolute flex h-[24.327px] items-center justify-center top-[146.17px] w-[24.279px]", additionalClassNames)}>
      <div className="-scale-y-100 flex-none">
        <div className="bg-white h-[24.327px] w-[24.279px]" />
      </div>
    </div>
  );
}

export default function Frame() {
  return (
    <div className="bg-white relative rounded-[16px] size-full">
      <div aria-hidden="true" className="absolute border border-[#c9cdd4] border-solid inset-0 pointer-events-none rounded-[16px]" />
      <div className="content-stretch flex flex-col gap-[32px] items-start p-[24px] relative size-full">
        <div className="content-stretch flex flex-col gap-[24px] items-start relative shrink-0 w-full">
          <div className="content-stretch flex flex-col gap-[8px] items-start relative shrink-0 w-full">
            <p className="font-['DM_Sans:Bold','Noto_Sans_JP:Bold','Noto_Sans_SC:Bold',sans-serif] font-bold leading-[24px] relative shrink-0 text-[#101828] text-[22px] w-full" style={{ fontVariationSettings: "'opsz' 14" }}>
              上传文件
            </p>
            <p className="font-['ABeeZee:Regular','Noto_Sans_JP:Regular','Noto_Sans_SC:Regular',sans-serif] leading-[18px] relative shrink-0 text-[#344054] text-[12px] w-full" style={{ fontVariationSettings: "'wght' 400" }}>
              每次最多可上传一个文件，单个文件大小上限为50 MB。
            </p>
          </div>
          <div className="content-stretch flex flex-col gap-[24px] items-center relative shrink-0 w-full">
            <div className="h-[302px] relative shrink-0 w-[214px]">
              <div className="absolute h-[301.328px] left-0 pointer-events-none rounded-[4px] top-0 w-[213px]" data-name="截屏2025-12-05 12.40.51 21">
                <div aria-hidden="true" className="absolute inset-0 rounded-[4px]">
                  <div className="absolute inset-0 overflow-hidden rounded-[4px]">
                    <img alt="" className="absolute left-0 max-w-none size-full top-0" src={imgFrame1261153172} />
                  </div>
                  <div className="absolute bg-[rgba(0,0,0,0.3)] inset-0 rounded-[4px]" />
                </div>
                <div aria-hidden="true" className="absolute border border-[#b8c2cc] border-solid inset-[-1px] rounded-[5px]" />
              </div>
              <div className="absolute contents left-[-147px] top-[0.67px]">
                <div className="absolute contents left-[-147px] top-[0.67px]">
                  <div className="absolute h-[300px] left-[-147px] pointer-events-none rounded-[4px] top-[0.67px] w-[508px]" data-name="截屏2025-12-05 12.40.05 2">
                    <div aria-hidden="true" className="absolute inset-0 rounded-[4px]">
                      <div className="absolute bg-white inset-0 rounded-[4px]" />
                      <div className="absolute inset-0 overflow-hidden rounded-[4px]">
                        <img alt="" className="absolute left-0 max-w-none size-full top-0" src={imgFrame1261153173} />
                      </div>
                    </div>
                    <div aria-hidden="true" className="absolute border-8 border-solid border-white inset-[-8px] rounded-[12px]" />
                  </div>
                  <div className="absolute contents left-[-113.85px] top-[120.04px]">
                    <div className="absolute bg-white h-[24.327px] left-[-30.74px] top-[120.04px] w-[65.368px]" />
                    <div className="absolute bg-white h-[24.327px] left-[35.56px] top-[120.04px] w-[155.949px]" />
                    <div className="absolute bg-white h-[24.327px] left-[197.11px] top-[120.04px] w-[24.279px]" />
                    <div className="absolute bg-white h-[24.327px] left-[227px] top-[120.04px] w-[24.279px]" />
                    <div className="absolute bg-white h-[24.327px] left-[256.88px] top-[120.04px] w-[24.279px]" />
                    <div className="absolute bg-white h-[24.327px] left-[297.03px] top-[120.04px] w-[24.279px]" />
                    <div className="absolute contents left-[-113.85px] top-[146.17px]">
                      <div className="absolute flex h-[24.327px] items-center justify-center left-[-30.74px] top-[146.17px] w-[65.368px]">
                        <div className="-scale-y-100 flex-none">
                          <div className="bg-white h-[24.327px] w-[65.368px]" />
                        </div>
                      </div>
                      <div className="absolute flex h-[24.327px] items-center justify-center left-[-113.85px] top-[154.28px] w-[79.375px]">
                        <div className="-scale-y-100 flex-none">
                          <div className="bg-white h-[24.327px] w-[79.375px]" />
                        </div>
                      </div>
                      <div className="absolute flex h-[24.327px] items-center justify-center left-[35.56px] top-[146.17px] w-[155.949px]">
                        <div className="-scale-y-100 flex-none">
                          <div className="bg-white h-[24.327px] w-[155.949px]" />
                        </div>
                      </div>
                      <Frame1261153172Helper additionalClassNames="left-[197.11px]" />
                      <Frame1261153172Helper additionalClassNames="left-[227px]" />
                      <Frame1261153172Helper additionalClassNames="left-[256.88px]" />
                      <Frame1261153172Helper additionalClassNames="left-[297.03px]" />
                    </div>
                  </div>
                </div>
              </div>
              <div className="absolute contents left-[-147px] top-[0.67px]">
                <div className="absolute contents left-[-147px] top-[0.67px]">
                  <div className="absolute bg-[rgba(0,0,0,0.1)] h-[300px] left-[-147px] rounded-[4px] top-[0.67px] w-[508px]" data-name="截屏2025-12-05 12.40.05 2">
                    <div aria-hidden="true" className="absolute border-8 border-solid border-white inset-[-8px] pointer-events-none rounded-[12px]" />
                  </div>
                </div>
              </div>
              <div className="absolute left-[74px] size-[64px] top-[118.67px]" data-name="Trash_light">
                <Frame1261153172Helper1 additionalClassNames="inset-[47.92%_60.42%_39.58%_39.58%]">
                  <path d="M1 1L9 1" id="Vector 8" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeWidth="2" />
                </Frame1261153172Helper1>
                <Frame1261153172Helper1 additionalClassNames="inset-[47.92%_39.58%_39.58%_60.42%]">
                  <path d="M1 1L9 1" id="Vector 9" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeWidth="2" />
                </Frame1261153172Helper1>
                <div className="absolute inset-[-1.56%_0]">
                  <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 64 66">
                    <g id="Group 2504">
                      <path d={svgPaths.pb1ffd00} id="Rectangle 41" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeWidth="2" />
                      <path d={svgPaths.p18ad9500} id="Ellipse 45" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeWidth="2" />
                    </g>
                  </svg>
                </div>
              </div>
            </div>
            <div className="bg-[#0a6ed1] relative rounded-[4px] shrink-0" data-name="Component 7">
              <div className="flex flex-row items-center justify-center size-full">
                <div className="content-stretch flex gap-[10px] items-center justify-center p-[12px] relative">
                  <div className="flex flex-col font-['DM_Sans:Regular','Noto_Sans_JP:Regular','Noto_Sans_SC:Regular',sans-serif] font-normal justify-center leading-[0] relative shrink-0 text-[20px] text-white whitespace-nowrap" style={{ fontVariationSettings: "'opsz' 14" }}>
                    <p className="leading-[22px]">确认</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div className="absolute bg-white right-[16px] rounded-[8px] size-[36px] top-[16px]" data-name="Buttons/Button">
          <div className="flex flex-row items-center justify-center overflow-clip rounded-[inherit] size-full">
            <div className="content-stretch flex items-center justify-center p-[8px] relative size-full">
              <div className="flex-[1_0_0] h-full min-h-px min-w-px overflow-clip relative" data-name="x-close">
                <div className="absolute inset-1/4" data-name="Icon">
                  <div className="absolute inset-[-8.33%]">
                    <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 11.6667 11.6667">
                      <path d={svgPaths.p3f40eb80} id="Icon" stroke="var(--stroke-0, #344054)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.66667" />
                    </svg>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}