import clsx from "clsx";
import svgPaths from "./svg-xyeye8urs8";
import img2025120512405121 from "figma:asset/0fb7738e99e722ceb1abac61599257cef011512c.png";
import img202510141739511 from "figma:asset/34905ae2c93e0c0205acb1ef4d5ff892fbd77e03.png";
type Wrapper7Props = {
  additionalClassNames?: string;
};

function Wrapper7({ children, additionalClassNames = "" }: React.PropsWithChildren<Wrapper7Props>) {
  return (
    <div style={{ fontVariationSettings: "'opsz' 14" }} className={clsx("flex flex-col font-normal justify-center leading-[0] relative shrink-0 text-[20px] whitespace-nowrap", additionalClassNames)}>
      <p className="leading-[22px]">{children}</p>
    </div>
  );
}
type ContainerProps = {
  additionalClassNames?: string;
};

function Container({ children, additionalClassNames = "" }: React.PropsWithChildren<ContainerProps>) {
  return (
    <div className={clsx("h-[100px] relative", additionalClassNames)}>
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col gap-[4px] items-start relative size-full">{children}</div>
    </div>
  );
}
type Wrapper6Props = {
  additionalClassNames?: string;
};

function Wrapper6({ children, additionalClassNames = "" }: React.PropsWithChildren<Wrapper6Props>) {
  return (
    <div className={clsx("size-[16px]", additionalClassNames)}>
      <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16 16">
        {children}
      </svg>
    </div>
  );
}

function Wrapper5({ children }: React.PropsWithChildren<{}>) {
  return (
    <div className="relative shrink-0 size-[24px]">
      <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        {children}
      </svg>
    </div>
  );
}
type DatabaseHelperProps = {
  additionalClassNames?: string;
};

function DatabaseHelper({ children, additionalClassNames = "" }: React.PropsWithChildren<DatabaseHelperProps>) {
  return (
    <div className={clsx("absolute", additionalClassNames)}>
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 19 10">
        {children}
      </svg>
    </div>
  );
}
type Wrapper4Props = {
  additionalClassNames?: string;
};

function Wrapper4({ children, additionalClassNames = "" }: React.PropsWithChildren<Wrapper4Props>) {
  return (
    <div className={additionalClassNames}>
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">{children}</div>
    </div>
  );
}
type Wrapper3Props = {
  additionalClassNames?: string;
};

function Wrapper3({ children, additionalClassNames = "" }: React.PropsWithChildren<Wrapper3Props>) {
  return <Wrapper4 additionalClassNames={clsx("flex-[1_0_0] min-h-px min-w-px relative", additionalClassNames)}>{children}</Wrapper4>;
}
type Wrapper2Props = {
  additionalClassNames?: string;
};

function Wrapper2({ children, additionalClassNames = "" }: React.PropsWithChildren<Wrapper2Props>) {
  return <Wrapper4 additionalClassNames={clsx("relative shrink-0", additionalClassNames)}>{children}</Wrapper4>;
}

function Wrapper1({ children }: React.PropsWithChildren<{}>) {
  return (
    <div className="flex-[1_0_0] h-[16.5px] min-h-px min-w-px relative">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid overflow-clip relative rounded-[inherit] size-full">{children}</div>
    </div>
  );
}

function Wrapper({ children }: React.PropsWithChildren<{}>) {
  return (
    <div className="bg-white relative rounded-[9.9px] shrink-0 w-full">
      <div aria-hidden="true" className="absolute border border-[#eaecf0] border-solid inset-0 pointer-events-none rounded-[9.9px] shadow-[0px_0.825px_2.475px_0px_rgba(16,24,40,0.1),0px_0.825px_1.65px_0px_rgba(16,24,40,0.06)]" />
      <div className="flex flex-row items-center size-full">
        <div className="content-stretch flex gap-[16.5px] items-center p-[16.5px] relative w-full">{children}</div>
      </div>
    </div>
  );
}

function Span({ children }: React.PropsWithChildren<{}>) {
  return (
    <Wrapper1>
      <p className="absolute font-['Inter:Medium','Noto_Sans_JP:Medium','Noto_Sans_SC:Medium',sans-serif] font-medium leading-[16.5px] left-0 not-italic text-[#101828] text-[11px] top-[0.5px] tracking-[0.0645px] whitespace-nowrap">{children}</p>
    </Wrapper1>
  );
}
type HelperProps = {
  text: string;
  text1: string;
};

function Helper({ text, text1 }: HelperProps) {
  return (
    <div style={{ fontVariationSettings: "'opsz' 14" }} className="flex flex-col font-['DM_Sans:Regular','Noto_Sans_JP:Regular','Noto_Sans_SC:Regular',sans-serif] font-normal justify-center leading-[0] relative shrink-0 text-[#1f2d3d] text-[20px] text-center whitespace-nowrap">
      <p>
        <span className="font-['DM_Sans:Regular','Noto_Sans_JP:Regular','Noto_Sans_SC:Regular',sans-serif] font-normal leading-[22px]" style={{ fontVariationSettings: "'opsz' 14" }}>
          {text}
        </span>
        <span className="leading-[22px]">{text1}</span>
      </p>
    </div>
  );
}

function Corner() {
  return (
    <div className="absolute inset-[0_0_62.5%_62.5%]">
      <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 15.75 15.75">
        <path d="M0 15.75H15.75L0 0V15.75Z" fill="var(--fill-0, #BDBDBD)" id="Corner" />
      </svg>
    </div>
  );
}
type SpanText6Props = {
  text: string;
  additionalClassNames?: string;
};

function SpanText6({ text, additionalClassNames = "" }: SpanText6Props) {
  return (
    <Wrapper4 additionalClassNames={clsx("h-[16.5px] relative shrink-0", additionalClassNames)}>
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[16.5px] left-0 not-italic text-[#0a6ed1] text-[11px] top-[0.5px] tracking-[0.0645px] whitespace-nowrap">{text}</p>
    </Wrapper4>
  );
}
type SpanText5Props = {
  text: string;
  additionalClassNames?: string;
};

function SpanText5({ text, additionalClassNames = "" }: SpanText5Props) {
  return (
    <Wrapper4 additionalClassNames={clsx("h-[16.5px] relative shrink-0", additionalClassNames)}>
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[16.5px] left-0 not-italic text-[#344054] text-[11px] top-[0.5px] tracking-[0.0645px] whitespace-nowrap">{text}</p>
    </Wrapper4>
  );
}
type SpanText4Props = {
  text: string;
};

function SpanText4({ text }: SpanText4Props) {
  return (
    <Wrapper2 additionalClassNames="h-[16.5px] w-[9.68px]">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[16.5px] left-0 not-italic text-[#667085] text-[11px] top-[0.5px] tracking-[0.0645px] whitespace-nowrap">{text}</p>
    </Wrapper2>
  );
}
type SvgProps = {
  text: string;
  text1: string;
};

function Svg({ text, text1 }: SvgProps) {
  return (
    <div className="h-[72px] overflow-clip relative shrink-0 w-full">
      <div className="absolute inset-[3.33%]" data-name="Vector">
        <div className="absolute inset-[-1.34%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 69 69">
            <path d={svgPaths.p2a9e5100} id="Vector" stroke="var(--stroke-0, #C41E24)" strokeWidth="1.8" />
          </svg>
        </div>
      </div>
      <div className="absolute inset-[8.33%]" data-name="Vector">
        <div className="absolute inset-[-0.5%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 60.6 60.6">
            <path d={svgPaths.p17fa5280} id="Vector" stroke="var(--stroke-0, #C41E24)" strokeWidth="0.6" />
          </svg>
        </div>
      </div>
      <div className="absolute inset-[23.33%_30.83%_40%_30.83%]" data-name="Vector">
        <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 27.6 26.4">
          <path d={svgPaths.p3d45ed40} fill="var(--fill-0, #C41E24)" id="Vector" />
        </svg>
      </div>
      <p className="absolute bottom-[98.61%] font-['Inter:Regular',sans-serif] font-normal leading-[normal] left-0 not-italic right-full text-[#c41e24] text-[6px] top-[-8.33%] whitespace-nowrap">{text}</p>
      <p className="absolute font-['Inter:Regular','Noto_Sans_JP:Regular',sans-serif] font-normal inset-[71.67%_45.28%_22.78%_43.61%] leading-[normal] not-italic text-[#c41e24] text-[3.6px] text-center whitespace-nowrap">{text1}</p>
    </div>
  );
}
type PTextProps = {
  text: string;
};

function PText({ text }: PTextProps) {
  return (
    <div className="absolute h-[16.5px] left-0 top-0 w-[88px]">
      <p className="absolute font-['Inter:Regular','Noto_Sans_JP:Regular','Noto_Sans_SC:Regular',sans-serif] font-normal leading-[16.5px] left-0 not-italic text-[#344054] text-[11px] top-[0.5px] tracking-[0.0645px] whitespace-nowrap">{text}</p>
    </div>
  );
}
type SpanText3Props = {
  text: string;
};

function SpanText3({ text }: SpanText3Props) {
  return (
    <Wrapper1>
      <p className="absolute font-['Inter:Medium',sans-serif] font-medium leading-[16.5px] left-0 not-italic text-[#101828] text-[11px] top-[0.5px] tracking-[0.0645px] whitespace-nowrap">{text}</p>
    </Wrapper1>
  );
}
type SpanText2Props = {
  text: string;
  additionalClassNames?: string;
};

function SpanText2({ text, additionalClassNames = "" }: SpanText2Props) {
  return (
    <div className={clsx("absolute content-stretch flex h-[26px] items-center px-[6px] py-[2px] rounded-[4px] top-0", additionalClassNames)}>
      <p className="font-['Inter:Regular',sans-serif] font-normal leading-[22px] not-italic relative shrink-0 text-[#1d2939] text-[12px] whitespace-nowrap">{text}</p>
    </div>
  );
}
type SpanText1Props = {
  text: string;
};

function SpanText1({ text }: SpanText1Props) {
  return (
    <div className="absolute h-[22px] left-0 top-[2px] w-[60px]">
      <p className="absolute font-['Inter:Regular','Noto_Sans_JP:Regular','Noto_Sans_SC:Regular',sans-serif] font-normal leading-[22px] left-0 not-italic text-[#6b7b8d] text-[12px] top-px whitespace-nowrap">{text}</p>
    </div>
  );
}
type SpanTextProps = {
  text: string;
  additionalClassNames?: string;
};

function SpanText({ text, additionalClassNames = "" }: SpanTextProps) {
  return (
    <div className={clsx("absolute content-stretch flex h-[48px] items-center px-[6px] py-[2px] rounded-[4px] top-0", additionalClassNames)}>
      <p className="font-['Inter:Regular','Noto_Sans_JP:Regular','Noto_Sans_SC:Regular',sans-serif] font-normal leading-[22px] not-italic relative shrink-0 text-[#1d2939] text-[12px] whitespace-nowrap">{text}</p>
    </div>
  );
}
type ButtonProps = {
  additionalClassNames?: string;
};

function Button({ additionalClassNames = "" }: ButtonProps) {
  return (
    <div className={clsx("absolute h-[100px] rounded-[8px] top-0 w-[72px]", additionalClassNames)}>
      <div className="content-stretch flex flex-col items-start overflow-clip p-px relative rounded-[inherit] size-full">
        <ImgImage additionalClassNames="h-[98px]" />
      </div>
      <div aria-hidden="true" className="absolute border border-[#b8c2cc] border-solid inset-0 pointer-events-none rounded-[8px]" />
    </div>
  );
}
type ImgImageProps = {
  additionalClassNames?: string;
};

function ImgImage({ additionalClassNames = "" }: ImgImageProps) {
  return (
    <div className={clsx("relative shrink-0 w-full", additionalClassNames)}>
      <img alt="" className="absolute inset-0 max-w-none object-cover pointer-events-none size-full" src={img2025120512405121} />
    </div>
  );
}

export default function Component() {
  return (
    <div className="bg-[#f2f4f7] relative size-full" data-name="文档生成 与 文档汇总">
      <div className="absolute bg-[#fefefe] content-stretch flex flex-col h-[720px] items-start left-[105px] rounded-[16px] top-[182px] w-[633px]">
        <div aria-hidden="true" className="absolute border border-[#e5ecf5] border-solid inset-0 pointer-events-none rounded-[16px]" />
        <div className="bg-white content-stretch flex flex-col gap-[20px] h-[720px] items-center justify-center p-[2px] relative rounded-[16px] shrink-0 w-full" data-name="Container">
          <div aria-hidden="true" className="absolute border-2 border-[rgba(178,171,171,0.18)] border-solid inset-0 pointer-events-none rounded-[16px]" />
          <div className="bg-white relative rounded-[8px] shrink-0">
            <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-center relative">
              <div className="h-[431px] pointer-events-none relative rounded-[4px] shrink-0 w-[305px]" data-name="截屏2025-12-05 12.40.51 21">
                <div className="absolute inset-0 overflow-hidden rounded-[4px]">
                  <img alt="" className="absolute left-0 max-w-none size-full top-0" src={img2025120512405121} />
                </div>
                <div aria-hidden="true" className="absolute border border-[#b8c2cc] border-solid inset-[-1px] rounded-[5px]" />
              </div>
            </div>
          </div>
          <Wrapper2 additionalClassNames="h-[100px] w-[336px]">
            <div className="absolute content-stretch flex h-[100px] items-center justify-center left-[264px] p-px rounded-[10px] top-0 w-[72px]" data-name="button">
              <div aria-hidden="true" className="absolute border border-[#d0d5dd] border-solid inset-0 pointer-events-none rounded-[10px]" />
              <Wrapper5>
                <g id="Plus">
                  <path d="M5 12H19" id="Vector" stroke="var(--stroke-0, #667085)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" />
                  <path d="M12 5V19" id="Vector_2" stroke="var(--stroke-0, #667085)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" />
                </g>
              </Wrapper5>
            </div>
            <Button additionalClassNames="left-0" />
            <div className="absolute bg-[rgba(255,255,255,0)] content-stretch flex flex-col h-[100px] items-start left-[88px] overflow-clip rounded-[8px] shadow-[0px_0px_0px_2px_#0a6ed1,0px_4px_6px_-1px_rgba(0,0,0,0.1),0px_2px_4px_-2px_rgba(0,0,0,0.1)] top-0 w-[72px]" data-name="button">
              <ImgImage additionalClassNames="h-[100px]" />
            </div>
            <Button additionalClassNames="left-[176px]" />
          </Wrapper2>
          <Wrapper2 additionalClassNames="h-[36px] w-[303px]">
            <p className="absolute font-['Inter:Regular','Noto_Sans_JP:Regular','Noto_Sans_SC:Regular',sans-serif] font-normal leading-[0] left-0 not-italic text-[#667085] text-[12px] top-px w-[300px]">
              <span className="leading-[18px]">{`温馨提示：普通用户只能上传三页文档！想要上传更多文档请开通 `}</span>
              <span className="[text-decoration-skip-ink:none] decoration-solid leading-[18px] text-[#0a6ed1] underline">高级会员</span>
              <span className="leading-[18px]">。</span>
            </p>
          </Wrapper2>
        </div>
      </div>
      <div className="absolute h-[998px] left-[1423px] top-[13px] w-[14px]">
        <div className="absolute bg-[#f4f5f6] border border-[#d9d9d9] border-solid inset-0 rounded-[10px]" />
        <div className="absolute bg-[#b7b8b8] inset-[0_0_38.45%_0] rounded-[10px]" />
      </div>
      <div className="absolute bg-white border border-[#838383] border-solid h-[1024px] left-[423px] overflow-clip top-[1263px] w-[1440px]" data-name="Job Production">
        <div className="absolute h-[1024px] right-[1210px] top-[-1px] w-[229px]">
          <div className="absolute bg-[#f4f5f6] border border-[#d9d9d9] border-solid bottom-0 left-0 top-0 w-[1440px]" />
          <div className="absolute content-stretch flex flex-col items-start left-[15px] top-[146px] w-[150px]">
            <div className="content-stretch flex flex-col gap-[42px] items-start relative shrink-0 w-full">
              <div className="relative shrink-0">
                <div className="flex flex-row items-center size-full">
                  <div className="content-stretch flex gap-[16px] items-center relative">
                    <div className="h-[24px] relative shrink-0" data-name="Home">
                      <div className="flex flex-row items-center justify-center size-full">
                        <div className="content-stretch flex h-full items-center justify-center px-[5px] py-[2px] relative">
                          <div className="h-[19px] relative shrink-0 w-[16px]">
                            <div className="absolute inset-[-5.26%_-6.25%]">
                              <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 18.0003 21">
                                <g id="Group 2468">
                                  <path d={svgPaths.p32493370} id="Rectangle 1" stroke="var(--stroke-2, #33363F)" strokeWidth="2" />
                                  <path d={svgPaths.pa0ef080} id="Vector 3" stroke="var(--stroke-0, #33363F)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" />
                                </g>
                              </svg>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div className="flex flex-col font-['Inter:Bold',sans-serif] font-bold justify-center leading-[0] not-italic relative shrink-0 text-[18px] text-black whitespace-nowrap">
                      <p className="leading-[normal]">Home</p>
                    </div>
                  </div>
                </div>
              </div>
              <div className="content-stretch flex gap-[16px] items-center relative shrink-0">
                <div className="relative shrink-0 size-[24px]" data-name="comment">
                  <div className="absolute h-[19.15px] left-[4px] top-[5px] w-[19.786px]" data-name="Union">
                    <div className="absolute inset-[-5.22%_-5.05%_-5.23%_-5.05%]">
                      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 21.7861 21.1521">
                        <path d={svgPaths.p3defd200} fill="var(--stroke-0, #222222)" id="Union" />
                      </svg>
                    </div>
                  </div>
                  <div className="absolute inset-[41.67%_20.83%_58.33%_37.5%]">
                    <div className="absolute inset-[-1px_-10%]">
                      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 12 2">
                        <path d="M1 1H11" id="Vector 7" stroke="var(--stroke-0, #222222)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" />
                      </svg>
                    </div>
                  </div>
                  <div className="absolute inset-[62.5%_37.5%_37.5%_37.5%]">
                    <div className="absolute inset-[-1px_-16.67%]">
                      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 8 2">
                        <path d="M1 1H7" id="Vector 9" stroke="var(--stroke-0, #222222)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" />
                      </svg>
                    </div>
                  </div>
                </div>
                <div className="flex flex-col font-['Inter:Bold',sans-serif] font-bold justify-center leading-[0] not-italic relative shrink-0 text-[18px] text-black whitespace-nowrap">
                  <p className="leading-[normal]">Chat</p>
                </div>
              </div>
              <div className="content-stretch flex gap-[16px] items-center relative shrink-0 w-full">
                <div className="relative shrink-0 size-[24px]" data-name="File_dock">
                  <div className="absolute inset-[12.5%_8.33%_-4.17%_20.83%]">
                    <div className="absolute inset-[-4.55%_-5.88%]">
                      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 19.0004 24.0005">
                        <path d={svgPaths.p3b8492c0} id="Rectangle 1" stroke="var(--stroke-3, #33363F)" strokeWidth="2" />
                      </svg>
                    </div>
                  </div>
                  <div className="absolute inset-[62.5%_29.17%_37.5%_41.67%]">
                    <div className="absolute inset-[-1px_-14.29%]">
                      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 9 2">
                        <path d="M1 1H8" id="Vector 55" stroke="var(--stroke-0, #33363F)" strokeLinecap="round" strokeWidth="2" />
                      </svg>
                    </div>
                  </div>
                  <div className="absolute inset-[83.33%_37.5%_16.67%_41.67%]">
                    <div className="absolute inset-[-1px_-20%]">
                      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 7 2">
                        <path d="M1 1H6" id="Vector 58" stroke="var(--stroke-0, #33363F)" strokeLinecap="round" strokeWidth="2" />
                      </svg>
                    </div>
                  </div>
                  <div className="absolute inset-[12.5%_8.33%_58.33%_62.5%]">
                    <div className="absolute inset-[0_0_-14.29%_-14.29%]">
                      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 8.00001 8.00001">
                        <path d={svgPaths.p1bcfd00} id="Rectangle 2" stroke="var(--stroke-0, #33363F)" strokeWidth="2" />
                      </svg>
                    </div>
                  </div>
                </div>
                <div className="flex flex-col font-['Inter:Bold',sans-serif] font-bold justify-center leading-[0] not-italic relative shrink-0 text-[18px] text-black whitespace-nowrap">
                  <p className="leading-[normal]">Library</p>
                </div>
              </div>
              <div className="content-stretch flex gap-[16px] items-start relative shrink-0 w-full">
                <div className="relative shrink-0 size-[24px]" data-name="Database">
                  <div className="absolute inset-[16.67%_8.33%_54.17%_20.83%]">
                    <div className="absolute inset-[-14.29%_-5.88%]">
                      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 19 9">
                        <ellipse cx="9.5" cy="4.5" id="Ellipse 109" rx="8.5" ry="3.5" stroke="var(--stroke-0, #33363F)" strokeWidth="2" />
                      </svg>
                    </div>
                  </div>
                  <div className="absolute inset-[62.5%_8.33%_4.17%_20.83%]">
                    <DatabaseHelper additionalClassNames="inset-[-12.5%_-5.88%]">
                      <path d={svgPaths.peb01480} id="Ellipse 110" stroke="var(--stroke-0, #33363F)" strokeLinecap="square" strokeWidth="2" />
                    </DatabaseHelper>
                  </div>
                  <div className="absolute inset-[33.33%_8.33%_29.17%_20.83%]">
                    <DatabaseHelper additionalClassNames="inset-[0_-5.88%_-11.11%_-5.88%]">
                      <path d={svgPaths.pccabc00} id="Ellipse 111" stroke="var(--stroke-0, #33363F)" strokeWidth="2" />
                    </DatabaseHelper>
                  </div>
                </div>
                <div className="flex flex-col font-['Inter:Bold',sans-serif] font-bold justify-center leading-[0] not-italic relative shrink-0 text-[18px] text-black w-[105px]">
                  <p className="leading-[normal] whitespace-pre-wrap">{`Company‘s  Analyse`}</p>
                </div>
              </div>
            </div>
          </div>
          <div className="absolute contents left-[15px] top-[36px]">
            <div className="absolute content-stretch flex items-center justify-between left-[15px] top-[36px] w-[196px]">
              <div className="grid-cols-[max-content] grid-rows-[max-content] inline-grid leading-[0] place-items-start relative shrink-0">
                <div className="col-1 ml-[3.02px] mt-0 relative row-1 size-[28.966px]">
                  <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 28.9655 28.9655">
                    <circle cx="14.4828" cy="14.4828" fill="var(--fill-0, #838383)" id="Ellipse 49" r="14.4828" />
                  </svg>
                </div>
                <div className="col-1 flex flex-col font-['Inter:Regular',sans-serif] font-normal h-[10.259px] justify-center ml-0 mt-[9.05px] not-italic relative row-1 text-[14px] text-black text-center w-[35px]">
                  <p className="leading-[normal]">Logo</p>
                </div>
              </div>
              <div className="relative shrink-0">
                <div className="flex flex-row items-center size-full">
                  <div className="content-stretch flex items-center relative">
                    <div className="content-stretch flex items-center justify-center overflow-clip px-[3px] py-[6px] relative shrink-0" data-name="lucide:sidebar-close">
                      <div className="relative shrink-0 size-[20px]" data-name="Group">
                        <div className="absolute inset-[-5%]">
                          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 22 22">
                            <g id="Group">
                              <path d={svgPaths.p3511c000} id="Vector" stroke="var(--stroke-0, #8F8F8F)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" />
                              <path d={svgPaths.p28ea85c0} id="Vector_2" stroke="var(--stroke-0, #8F8F8F)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" />
                            </g>
                          </svg>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div className="absolute content-stretch flex gap-[16px] items-center left-[15px] top-[975px]">
            <div className="relative shrink-0 size-[36px]">
              <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 36 36">
                <g id="Group 2379">
                  <circle cx="18" cy="18" fill="var(--fill-0, #D9D9D9)" id="Ellipse 31" r="18" />
                  <circle cx="17.6721" cy="11.7818" fill="var(--fill-0, #262628)" id="Ellipse 28" r="5.89091" />
                  <g id="Mask group">
                    <mask height="36" id="mask0_1_1064" maskUnits="userSpaceOnUse" style={{ maskType: "alpha" }} width="36" x="0" y="0">
                      <circle cx="18" cy="18" fill="var(--fill-0, #D9D9D9)" id="Ellipse 30" r="18" />
                    </mask>
                    <g mask="url(#mask0_1_1064)">
                      <ellipse cx="17.673" cy="31.091" fill="var(--fill-0, #262628)" id="Ellipse 29" rx="11.1273" ry="11.4545" />
                    </g>
                  </g>
                </g>
              </svg>
            </div>
            <div className="flex flex-col font-['Inter:Bold',sans-serif] font-bold justify-center leading-[0] not-italic relative shrink-0 text-[18px] text-black whitespace-nowrap">
              <p className="leading-[normal]">Yuqian Cheng</p>
            </div>
          </div>
        </div>
        <div className="-translate-y-1/2 absolute bg-[#fcfcfc] content-stretch flex h-[998px] items-start left-[228px] px-[26px] py-[28px] rounded-[12px] top-1/2 w-[1190px]">
          <div aria-hidden="true" className="absolute border border-[#d9d9d9] border-solid inset-0 pointer-events-none rounded-[12px]" />
          <div className="flex flex-col font-['Arial:Bold',sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[32px] text-black whitespace-nowrap">
            <p className="leading-[normal]">{`Title 1 -- 48 `}</p>
          </div>
        </div>
        <div className="absolute contents right-[2px] top-[12px]">
          <div className="absolute bg-[#f4f5f6] border border-[#d9d9d9] border-solid bottom-[13px] h-[998px] right-[3px] rounded-[10px] w-[7px]" />
          <div className="absolute bg-[#b7b8b8] h-[614.264px] right-[3px] rounded-[10px] top-[13px] w-[7px]" />
        </div>
        <div className="absolute content-stretch flex gap-[16px] items-start left-[329px] top-[128px] w-[700px]">
          <div className="h-[30px] relative shrink-0 w-[31px]" data-name="截屏2025-10-14 17.39.51 1">
            <img alt="" className="absolute inset-0 max-w-none object-cover pointer-events-none size-full" src={img202510141739511} />
          </div>
          <div className="content-stretch flex flex-col font-['Inter:Regular',sans-serif] font-normal gap-[24px] items-start leading-[0] not-italic relative shrink-0 text-black w-[660px]">
            <div className="flex flex-col h-[27px] justify-center relative shrink-0 text-[14px] text-right w-[109px]">
              <p className="leading-[normal]">2.03 PM, 15 Nov</p>
            </div>
            <div className="flex flex-col justify-center relative shrink-0 text-[18px] w-[660px]">
              <p className="leading-[normal]">Hi! What can I do for you?</p>
            </div>
          </div>
        </div>
        <div className="absolute content-stretch flex items-center justify-end left-[228px] top-[-1px] w-[800px]">
          <div className="content-stretch flex gap-[8px] items-center relative shrink-0">
            <Wrapper5>
              <g>
                <path clipRule="evenodd" d={svgPaths.p1cdf4e00} fill="var(--fill-0, black)" fillRule="evenodd" id="icon" />
                <path d={svgPaths.pe537b00} fill="var(--fill-0, black)" id="Star 1" />
                <path d={svgPaths.p232d2b00} fill="var(--fill-0, black)" id="Star 2" />
              </g>
            </Wrapper5>
            <div className="flex flex-col font-['Inter:Medium',sans-serif] font-medium justify-center leading-[0] not-italic relative shrink-0 text-[16px] text-black whitespace-nowrap">
              <p className="leading-[normal]">New dialog</p>
            </div>
          </div>
        </div>
        <div className="absolute left-[228px] top-[35px]" data-name="Input">
          <div className="flex flex-col items-center size-full">
            <div className="content-stretch flex flex-col gap-[4px] items-center relative">
              <div className="relative rounded-[8px] shrink-0 w-[800px]" data-name="Input-case">
                <div className="content-stretch flex flex-col items-start overflow-clip px-[16px] py-[12px] relative rounded-[inherit] w-full">
                  <div className="content-stretch flex gap-[8px] items-center relative shrink-0 w-full" data-name="Content">
                    <div className="relative shrink-0 size-[20px]" data-name="attatchment-01">
                      <div className="absolute flex inset-[6.36%_1.07%_-0.29%_5%] items-center justify-center">
                        <div className="-rotate-45 flex-none h-[10.281px] w-[21.6px]">
                          <div className="relative size-full" data-name="XMLID_6_">
                            <div className="absolute inset-[-8.75%_-4.17%]">
                              <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 19.5 10.0674">
                                <path d={svgPaths.p1399d700} id="XMLID_6_" stroke="var(--stroke-0, #919191)" strokeLinecap="round" strokeWidth="1.5" />
                              </svg>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div className="flex flex-[1_0_0] flex-col font-['Inter:Regular',sans-serif] font-normal justify-center leading-[0] min-h-px min-w-px not-italic relative text-[16px] text-black">
                      <p>
                        <span className="leading-[normal]">{`Send me prompt and request `}</span>
                        <span className="font-['Inter:Bold',sans-serif] font-bold leading-[normal] not-italic">ai chat</span>
                      </p>
                    </div>
                    <div className="relative shrink-0 size-[20px]" data-name="microphone-01">
                      <div className="absolute inset-[10%_18.32%]" data-name="Icon">
                        <div className="absolute inset-[-4.69%_-5.92%]">
                          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 14.1704 17.5">
                            <path d={svgPaths.p332ff900} id="Icon" stroke="var(--stroke-0, #919191)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
                          </svg>
                        </div>
                      </div>
                    </div>
                    <div className="relative shrink-0 size-[20px]" data-name="telegram-fill">
                      <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 20 20">
                        <g id="telegram-fill">
                          <path d={svgPaths.p3db98af0} fill="var(--fill-0, black)" id="Vector" />
                        </g>
                      </svg>
                    </div>
                  </div>
                </div>
                <div aria-hidden="true" className="absolute border border-[#e7e7e7] border-solid inset-0 pointer-events-none rounded-[8px]" />
              </div>
            </div>
          </div>
        </div>
      </div>
      <div className="absolute bg-[#fdffff] h-[1024px] right-[1359px] top-0 w-[81px]" data-name="sidebar">
        <div className="flex flex-col items-center size-full">
          <div className="content-stretch flex flex-col items-center justify-between p-[24px] relative size-full">
            <div className="h-[102px] relative shrink-0 w-[67px]">
              <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 67 102">
                <g id="Frame 1261153161">
                  <path d={svgPaths.p45f1300} fill="var(--fill-0, #0A6ED1)" id="Vector 15" />
                  <path d="M0 78H67" id="Vector 2802" stroke="var(--stroke-0, #EBEBEB)" />
                </g>
              </svg>
            </div>
            <div className="content-stretch flex flex-col gap-[32px] items-center relative shrink-0 w-[52px]">
              <div className="bg-[#f5f9ff] content-stretch flex flex-col gap-[16px] items-center justify-center p-[8px] relative rounded-[4px] shrink-0">
                <div className="relative shrink-0 size-[34px]" data-name="File_dock_light">
                  <div className="absolute inset-[0_5.23%_0_5.88%]">
                    <div className="absolute inset-[-2.21%_-2.48%]">
                      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 31.7224 35.5">
                        <g id="Group 2516">
                          <path d={svgPaths.pcf6ec00} id="Rectangle 4012" stroke="var(--stroke-0, #0A6ED1)" strokeLinecap="round" strokeWidth="1.5" />
                          <path d={svgPaths.p102a6600} id="Vector 52" stroke="var(--stroke-0, #0A6ED1)" strokeLinecap="round" strokeWidth="1.5" />
                          <path d={svgPaths.p21818b00} id="Vector 53" stroke="var(--stroke-0, #0A6ED1)" strokeLinecap="round" strokeWidth="1.5" />
                          <path d={svgPaths.p20f87780} id="Vector 60" stroke="var(--stroke-0, #0A6ED1)" strokeLinecap="round" strokeWidth="1.5" />
                          <path d={svgPaths.p37fe3be0} id="Vector 61" stroke="var(--stroke-0, #0A6ED1)" strokeLinecap="round" strokeWidth="1.5" />
                          <path d={svgPaths.pdeca900} id="Vector 62" stroke="var(--stroke-0, #0A6ED1)" strokeLinecap="round" strokeWidth="1.5" />
                        </g>
                      </svg>
                    </div>
                  </div>
                </div>
                <p className="font-['ABeeZee:Italic','Noto_Sans_JP:Regular',sans-serif] italic leading-[20px] relative shrink-0 text-[#0a6ed1] text-[13px] text-center whitespace-nowrap" style={{ fontVariationSettings: "'wght' 400" }}>
                  文档生成
                </p>
              </div>
              <div className="content-stretch flex flex-col gap-[16px] items-center relative shrink-0 w-[34px]">
                <div className="aspect-[24/24] relative shrink-0 w-full" data-name="Basket_alt_3_light">
                  <div className="absolute inset-[2.94%_0_0_0]">
                    <div className="absolute inset-[-2.27%_0_0_-2.21%]">
                      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 34.7502 33.75">
                        <g id="Group 2515">
                          <path d={svgPaths.p3a8d2e00} id="Vector" stroke="var(--stroke-0, #475E75)" strokeLinecap="round" strokeWidth="1.5" />
                          <path d={svgPaths.p13f53800} id="Rectangle 41" stroke="var(--stroke-0, #475E75)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
                          <path d={svgPaths.p3c579d00} id="Vector 339" stroke="var(--stroke-0, #475E75)" strokeLinecap="round" strokeWidth="1.5" />
                          <ellipse cx="27.7501" cy="31.75" fill="var(--fill-0, #475E75)" id="Ellipse 167" rx="2.00001" ry="1.99997" />
                          <ellipse cx="11.7502" cy="31.75" fill="var(--fill-0, #475E75)" id="Ellipse 168" rx="2.00001" ry="1.99997" />
                        </g>
                      </svg>
                    </div>
                  </div>
                </div>
                <div className="flex flex-col font-['ABeeZee:Italic','Noto_Sans_JP:Regular','Noto_Sans_SC:Regular',sans-serif] italic justify-center leading-[0] relative shrink-0 text-[#475e75] text-[13px] text-center w-full" style={{ fontVariationSettings: "'wght' 400" }}>
                  <p className="leading-[20px]">充值</p>
                </div>
              </div>
            </div>
            <div className="relative rounded-[4px] shrink-0" data-name="卡片内边距16px/Variant2">
              <div className="flex flex-col items-center justify-center size-full">
                <div className="content-stretch flex flex-col gap-[16px] items-center justify-center px-[3px] py-[8px] relative">
                  <div className="bg-[#0a6ed1] content-stretch flex items-center justify-center p-[13px] relative rounded-[25px] shrink-0 size-[34px]">
                    <p className="font-['DM_Sans:Regular',sans-serif] font-normal leading-[22px] relative shrink-0 text-[20px] text-white whitespace-nowrap" style={{ fontVariationSettings: "'opsz' 14" }}>
                      1
                    </p>
                  </div>
                  <div className="content-stretch flex flex-col items-center relative shrink-0 w-full">
                    <p className="font-['ABeeZee:Regular',sans-serif] leading-[18px] not-italic relative shrink-0 text-[#202d35] text-[12px] whitespace-nowrap">133******3</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div className="-translate-y-1/2 absolute flex flex-col font-['Arial:Bold','Noto_Sans_JP:Bold','Noto_Sans_SC:Bold',sans-serif] h-[53px] justify-center leading-[0] left-[105px] text-[40px] text-black top-[66.5px] w-[260px]" style={{ fontVariationSettings: "'wght' 700" }}>
        <p className="leading-[normal]">上传与识别</p>
      </div>
      <div className="-translate-y-1/2 absolute flex flex-col font-['DM_Sans:Regular','Noto_Sans_JP:Regular','Noto_Sans_SC:Regular',sans-serif] font-normal h-[31px] justify-center leading-[0] left-[105px] text-[#1f2d3d] text-[20px] top-[117.5px] w-[577px]" style={{ fontVariationSettings: "'opsz' 14" }}>
        <p className="leading-[22px]">将上传的文件匹配合适模版，生成标准化财务文件。</p>
      </div>
      <div className="absolute bg-white h-[64px] left-[102px] rounded-[16px] top-[932px] w-[1245px]">
        <div aria-hidden="true" className="absolute border-3 border-[rgba(178,171,171,0.22)] border-solid inset-0 pointer-events-none rounded-[16px]" />
        <div className="flex flex-row items-center size-full">
          <div className="content-stretch flex items-center justify-between px-[66px] py-[74px] relative size-full">
            <div className="content-stretch flex gap-[8px] h-[22.5px] items-center relative shrink-0 w-[166px]" data-name="Container">
              <div className="bg-[#12b76a] rounded-[16777200px] shrink-0 size-[8px]" data-name="Container" />
              <Wrapper3 additionalClassNames="h-[22.5px]">
                <p className="absolute font-['Inter:Regular','Noto_Sans_JP:Regular','Noto_Sans_SC:Regular',sans-serif] font-normal leading-[0] left-0 not-italic text-[#344054] text-[15px] top-[-0.5px] tracking-[-0.2344px] whitespace-nowrap">
                  <span className="leading-[22.5px]">当前状态：</span>
                  <span className="leading-[22.5px] text-[#101828]">已生成文档</span>
                </p>
              </Wrapper3>
            </div>
            <div className="grid-cols-[max-content] grid-rows-[max-content] inline-grid leading-[0] place-items-start relative shrink-0">
              <p className="col-1 font-['Inter:Regular','Noto_Sans_JP:Regular','Noto_Sans_SC:Regular',sans-serif] font-normal leading-[22.5px] ml-0 mt-[9.25px] not-italic relative row-1 text-[#1f2d3d] text-[15px] tracking-[-0.2344px] whitespace-nowrap">下一步：点击下载</p>
              <div className="bg-[#0a6ed1] col-1 h-[42.5px] ml-[155px] mt-0 relative rounded-[10px] row-1 shadow-[0px_1px_3px_0px_rgba(0,0,0,0.1),0px_1px_2px_0px_rgba(0,0,0,0.1)] w-[147px]" data-name="button">
                <Wrapper6 additionalClassNames="absolute left-[24px] top-[13.25px]">
                  <g id="Download">
                    <path d={svgPaths.p23ad1400} id="Vector" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
                    <path d={svgPaths.p19411800} id="Vector_2" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
                    <path d="M8 10V2" id="Vector_3" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
                  </g>
                </Wrapper6>
                <p className="-translate-x-1/2 absolute font-['Inter:Medium','Noto_Sans_JP:Medium','Noto_Sans_SC:Medium',sans-serif] font-medium leading-[22.5px] left-[85.5px] not-italic text-[15px] text-center text-white top-[9.5px] tracking-[-0.2344px] whitespace-nowrap">确认并下载</p>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div className="absolute bg-white h-[720px] left-[779px] rounded-[16px] top-[182px] w-[568px]" data-name="Container">
        <div className="content-stretch flex flex-col items-start overflow-clip p-px relative rounded-[inherit] size-full">
          <div className="h-[116.5px] relative shrink-0 w-[538px]" data-name="Container">
            <div aria-hidden="true" className="absolute border-[#f0f2f5] border-b border-solid inset-0 pointer-events-none" />
            <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
              <div className="absolute content-stretch flex h-[51px] items-start justify-between left-[24px] top-[20px] w-[490px]" data-name="Container">
                <Wrapper3 additionalClassNames="h-[51px]">
                  <div className="absolute content-stretch flex gap-[8px] h-[25.5px] items-center left-0 top-0 w-[438px]" data-name="Container">
                    <div className="bg-[#0a6ed1] h-[20px] rounded-[16777200px] shrink-0 w-[4px]" data-name="Container" />
                    <Wrapper2 additionalClassNames="h-[25.5px] w-[235.203px]">
                      <p className="absolute font-['Inter:Medium','Noto_Sans_JP:Medium','Noto_Sans_KR:Medium','Noto_Sans_SC:Medium',sans-serif] font-medium leading-[25.5px] left-0 not-italic text-[#101828] text-[17px] top-[0.5px] tracking-[-0.6316px] whitespace-nowrap">修改表单信息已完成！ 请核对</p>
                    </Wrapper2>
                  </div>
                  <div className="absolute h-[19.5px] left-[12px] top-[31.5px] w-[426px]" data-name="p">
                    <p className="absolute font-['Inter:Regular','Noto_Sans_JP:Regular','Noto_Sans_SC:Regular',sans-serif] font-normal leading-[19.5px] left-0 not-italic text-[#667085] text-[12px] top-[0.5px] whitespace-nowrap">点击蓝色空格修改信息，确认无误后便可下载文件。</p>
                  </div>
                </Wrapper3>
                <div className="bg-[#f0f7ff] relative rounded-[14px] shrink-0 size-[40px]" data-name="button">
                  <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-center justify-center relative size-full">
                    <div className="relative shrink-0 size-[18px]" data-name="Trash2">
                      <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 18 18">
                        <g id="Trash2">
                          <path d="M2.25 4.5H15.75" id="Vector" stroke="var(--stroke-0, #0A6ED1)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
                          <path d={svgPaths.p1af4f180} id="Vector_2" stroke="var(--stroke-0, #0A6ED1)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
                          <path d={svgPaths.p25aaaf00} id="Vector_3" stroke="var(--stroke-0, #0A6ED1)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
                          <path d="M7.5 8.25V12.75" id="Vector_4" stroke="var(--stroke-0, #0A6ED1)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
                          <path d="M10.5 8.25V12.75" id="Vector_5" stroke="var(--stroke-0, #0A6ED1)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
                        </g>
                      </svg>
                    </div>
                  </div>
                </div>
              </div>
              <div className="absolute content-stretch flex gap-[6px] h-[16.5px] items-center left-[36px] top-[83px] w-[478px]" data-name="Container">
                <div className="relative shrink-0 size-[14px]" data-name="AlertTriangle">
                  <div className="bg-clip-padding border-0 border-[transparent] border-solid overflow-clip relative rounded-[inherit] size-full">
                    <div className="absolute bg-[#0a6ed1] inset-[21.4%_21.47%_21.46%_21.39%] rounded-[16777200px]" data-name="Container" />
                  </div>
                </div>
                <Wrapper2 additionalClassNames="h-[16.5px] w-[124.32px]">
                  <div className="absolute bg-[#eef4ff] content-stretch flex h-[15px] items-start left-0 px-[4px] py-px rounded-[4px] top-[0.5px] w-[52px]" data-name="Text">
                    <p className="font-['Inter:Regular','Noto_Sans_SC:Regular','Noto_Sans_JP:Regular',sans-serif] font-normal leading-[16.5px] not-italic relative shrink-0 text-[#0a6ed1] text-[11px] tracking-[0.0645px] whitespace-nowrap">蓝色区域</p>
                  </div>
                  <p className="absolute font-['Inter:Regular','Noto_Sans_JP:Regular','Noto_Sans_KR:Regular',sans-serif] font-normal leading-[0] left-[52px] not-italic text-[#d97706] text-[11px] top-[0.5px] tracking-[0.0645px] whitespace-nowrap">
                    <span className="leading-[16.5px]">{` `}</span>
                    <span className="leading-[16.5px] text-[#0a6ed1]">已修改</span>
                    <span className="leading-[16.5px]">{` `}</span>
                    <span className="leading-[16.5px] text-[#667085]">并核对</span>
                  </p>
                </Wrapper2>
              </div>
            </div>
          </div>
          <div className="flex-[1_0_0] min-h-px min-w-px relative w-[567px]" data-name="Container">
            <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start overflow-clip px-[16px] relative rounded-[inherit] size-full">
              <div className="bg-white h-[660px] relative rounded-[14px] shrink-0 w-full" data-name="Container">
                <div className="overflow-clip rounded-[inherit] size-full">
                  <div className="content-stretch flex flex-col items-start p-px relative size-full">
                    <div className="h-[148.5px] relative shrink-0 w-full" data-name="Container">
                      <div aria-hidden="true" className="absolute border-[#d0d5dd] border-b border-solid inset-0 pointer-events-none" />
                      <div className="absolute h-[27px] left-[24px] top-[20px] w-[441px]" data-name="h4">
                        <p className="-translate-x-1/2 absolute font-['Inter:Medium','Noto_Sans_JP:Medium','Noto_Sans_SC:Medium',sans-serif] font-medium leading-[27px] left-[220.5px] not-italic text-[#101828] text-[18px] text-center top-[0.5px] tracking-[1.5605px] whitespace-nowrap">惠州市罗丰实业有限公司</p>
                      </div>
                      <div className="absolute content-stretch flex flex-col gap-[2px] h-[42px] items-start left-[24px] top-[55px] w-[441px]" data-name="Container">
                        <div className="h-[20px] relative shrink-0 w-full" data-name="p">
                          <p className="-translate-x-1/2 absolute font-['Inter:Regular','Noto_Sans_JP:Regular','Noto_Sans_SC:Regular',sans-serif] font-normal leading-[20px] left-[220.41px] not-italic text-[#667085] text-[11px] text-center top-[0.5px] tracking-[0.0645px] whitespace-nowrap">地址：广东省惠州市惠阳区秋长镇白石村大湖组88号</p>
                        </div>
                        <div className="h-[20px] relative shrink-0 w-full" data-name="p">
                          <p className="-translate-x-1/2 absolute font-['Inter:Regular','Noto_Sans_SC:Regular','Noto_Sans_JP:Regular',sans-serif] font-normal leading-[20px] left-[220.72px] not-italic text-[#667085] text-[11px] text-center top-[0.5px] tracking-[0.0645px] whitespace-nowrap">电话：0752-3731609 传真：7160373 手机：13902477013</p>
                        </div>
                      </div>
                      <div className="absolute content-stretch flex gap-[12px] h-[22.5px] items-center justify-center left-[24px] top-[109px] w-[441px]" data-name="Container">
                        <div className="bg-[#d0d5dd] flex-[1_0_0] h-px min-h-px min-w-px" data-name="Container" />
                        <Wrapper2 additionalClassNames="h-[22.5px] w-[100.969px]">
                          <p className="-translate-x-1/2 absolute font-['Inter:Regular','Noto_Sans_JP:Regular','Noto_Sans_SC:Regular',sans-serif] font-normal leading-[22.5px] left-[50.5px] not-italic text-[#1d2939] text-[15px] text-center top-[-0.5px] tracking-[7.7656px] whitespace-nowrap">送 货 单</p>
                        </Wrapper2>
                        <div className="bg-[#d0d5dd] flex-[1_0_0] h-px min-h-px min-w-px" data-name="Container" />
                      </div>
                    </div>
                    <div className="h-[125px] relative shrink-0 w-full" data-name="Container">
                      <div aria-hidden="true" className="absolute border-[#e5ecf5] border-b border-solid inset-0 pointer-events-none" />
                      <div className="content-stretch flex flex-col items-start pb-px pt-[12px] px-[20px] relative size-full">
                        <div className="content-stretch flex h-[100px] items-start justify-between relative shrink-0 w-full" data-name="Container">
                          <Container additionalClassNames="flex-[1_0_0] min-h-px min-w-px">
                            <div className="h-[48px] relative shrink-0 w-full" data-name="Container">
                              <div className="absolute h-[22px] left-0 top-[2px] w-[42.75px]" data-name="span">
                                <p className="absolute font-['Inter:Regular','Noto_Sans_JP:Regular','Noto_Sans_SC:Regular',sans-serif] font-normal leading-[22px] left-0 not-italic text-[#6b7b8d] text-[12px] top-px whitespace-pre">{`客  户：`}</p>
                              </div>
                              <SpanText text="保利(南宫)管乐制品(广州）有限公司" additionalClassNames="left-[42.75px] w-[203.523px]" />
                            </div>
                            <div className="h-[48px] relative shrink-0 w-full" data-name="Container">
                              <SpanText1 text="客户地址：" />
                              <SpanText text="广东省清远平丹原县义获镇登塔村" additionalClassNames="left-[60px] w-[186.273px]" />
                            </div>
                          </Container>
                          <Container additionalClassNames="shrink-0 w-[182.727px]">
                            <div className="h-[26px] relative shrink-0 w-full" data-name="Container">
                              <SpanText1 text="送货单号：" />
                              <SpanText2 text="LF202500003" additionalClassNames="left-[60px] w-[106.789px]" />
                            </div>
                            <div className="h-[26px] relative shrink-0 w-full" data-name="Container">
                              <div className="absolute h-[22px] left-0 top-[2px] w-[42.75px]" data-name="span">
                                <p className="absolute font-['Inter:Regular','Noto_Sans_SC:Regular','Noto_Sans_JP:Regular',sans-serif] font-normal leading-[22px] left-0 not-italic text-[#6b7b8d] text-[12px] top-px whitespace-pre">{`电  话：`}</p>
                              </div>
                              <SpanText2 text="0580 0775 7699999" additionalClassNames="left-[42.75px] w-[143.977px]" />
                            </div>
                            <div className="h-[26px] relative shrink-0 w-full" data-name="Container">
                              <div className="absolute h-[22px] left-0 top-[2px] w-[42.75px]" data-name="span">
                                <p className="absolute font-['Inter:Regular','Noto_Sans_JP:Regular',sans-serif] font-normal leading-[22px] left-0 not-italic text-[#6b7b8d] text-[12px] top-px whitespace-pre">{`日  期：`}</p>
                              </div>
                              <div className="absolute content-stretch flex h-[26px] items-center left-[42.75px] px-[6px] py-[2px] rounded-[4px] top-0 w-[104.555px]" data-name="span">
                                <p className="font-['Inter:Regular','Noto_Sans_JP:Regular',sans-serif] font-normal leading-[22px] not-italic relative shrink-0 text-[#1d2939] text-[12px] whitespace-nowrap">2025年1月3日</p>
                              </div>
                            </div>
                          </Container>
                        </div>
                      </div>
                    </div>
                    <div className="h-[223.5px] overflow-clip relative shrink-0 w-full" data-name="Container">
                      <div className="absolute h-[175px] left-[-343px] top-0 w-[877.375px]" data-name="table">
                        <div className="absolute h-[40.5px] left-0 top-0 w-[877.375px]" data-name="thead">
                          <div className="absolute bg-[#fafbfc] border-[#d0d5dd] border-b border-solid h-[40.5px] left-0 top-0 w-[877.375px]" data-name="tr">
                            <div className="absolute border-[#e5ecf5] border-r border-solid h-[40.5px] left-0 top-0 w-[38.5px]" data-name="th">
                              <p className="-translate-x-1/2 absolute font-['Inter:Bold','Noto_Sans_JP:Bold',sans-serif] font-bold leading-[16.5px] left-[19.5px] not-italic text-[#344054] text-[11px] text-center top-[12.25px] tracking-[0.0645px] whitespace-nowrap">序号</p>
                            </div>
                            <div className="absolute border-[#e5ecf5] border-r border-solid h-[40.5px] left-[38.5px] top-0 w-[130.445px]" data-name="th">
                              <p className="-translate-x-1/2 absolute font-['Inter:Bold','Noto_Sans_SC:Bold','Noto_Sans_JP:Bold',sans-serif] font-bold leading-[16.5px] left-[64.72px] not-italic text-[#344054] text-[11px] text-center top-[12.25px] tracking-[0.0645px] whitespace-nowrap">订单号</p>
                            </div>
                            <div className="absolute border-[#e5ecf5] border-r border-solid h-[40.5px] left-[168.95px] top-0 w-[104.234px]" data-name="th">
                              <p className="-translate-x-1/2 absolute font-['Inter:Bold','Noto_Sans_JP:Bold','Noto_Sans_SC:Bold',sans-serif] font-bold leading-[16.5px] left-[52.62px] not-italic text-[#344054] text-[11px] text-center top-[12.25px] tracking-[0.0645px] whitespace-nowrap">物料代码</p>
                            </div>
                            <div className="absolute border-[#e5ecf5] border-r border-solid h-[40.5px] left-[273.18px] top-0 w-[288.969px]" data-name="th">
                              <p className="-translate-x-1/2 absolute font-['Inter:Bold','Noto_Sans_SC:Bold','Noto_Sans_JP:Bold',sans-serif] font-bold leading-[16.5px] left-[144.98px] not-italic text-[#344054] text-[11px] text-center top-[12.25px] tracking-[0.0645px] whitespace-nowrap">产品名称</p>
                            </div>
                            <div className="absolute border-[#e5ecf5] border-r border-solid h-[40.5px] left-[562.15px] top-0 w-[50.227px]" data-name="th">
                              <p className="-translate-x-1/2 absolute font-['Inter:Bold','Noto_Sans_SC:Bold','Noto_Sans_JP:Bold',sans-serif] font-bold leading-[16.5px] left-[25.61px] not-italic text-[#344054] text-[11px] text-center top-[12.25px] tracking-[0.0645px] whitespace-nowrap">单位</p>
                            </div>
                            <div className="absolute border-[#e5ecf5] border-r border-solid h-[40.5px] left-[612.38px] top-0 w-[49.047px]" data-name="th">
                              <p className="-translate-x-1/2 absolute font-['Inter:Bold','Noto_Sans_JP:Bold',sans-serif] font-bold leading-[16.5px] left-[25.02px] not-italic text-[#344054] text-[11px] text-center top-[12.25px] tracking-[0.0645px] whitespace-nowrap">数量</p>
                            </div>
                            <div className="absolute border-[#e5ecf5] border-r border-solid h-[40.5px] left-[661.42px] top-0 w-[66.266px]" data-name="th">
                              <p className="-translate-x-1/2 absolute font-['Inter:Bold','Noto_Sans_SC:Bold','Noto_Sans_JP:Bold',sans-serif] font-bold leading-[16.5px] left-[33.63px] not-italic text-[#344054] text-[11px] text-center top-[12.25px] tracking-[0.0645px] whitespace-nowrap">单价</p>
                            </div>
                            <div className="absolute border-[#e5ecf5] border-r border-solid h-[40.5px] left-[727.69px] top-0 w-[90.188px]" data-name="th">
                              <p className="-translate-x-1/2 absolute font-['Inter:Bold','Noto_Sans_SC:Bold',sans-serif] font-bold leading-[16.5px] left-[45.59px] not-italic text-[#344054] text-[11px] text-center top-[12.25px] tracking-[0.0645px] whitespace-nowrap">总额</p>
                            </div>
                            <div className="absolute border-[#e5ecf5] border-r border-solid h-[40.5px] left-[817.88px] top-0 w-[39px]" data-name="th">
                              <p className="-translate-x-1/2 absolute font-['Inter:Bold','Noto_Sans_SC:Bold','Noto_Sans_JP:Bold',sans-serif] font-bold leading-[16.5px] left-[20px] not-italic text-[#344054] text-[11px] text-center top-[12.25px] tracking-[0.0645px] whitespace-nowrap">备注</p>
                            </div>
                            <div className="absolute border-[#e5ecf5] border-l border-solid h-[40.5px] left-[856.88px] top-0 w-[20.5px]" data-name="th">
                              <div className="absolute bg-[#f0f7ff] content-stretch flex items-center justify-center left-[-0.5px] rounded-[4px] size-[20px] top-[10px]" data-name="button">
                                <div className="relative shrink-0 size-[12px]" data-name="Plus">
                                  <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 12 12">
                                    <g id="Plus">
                                      <path d="M2.5 6H9.5" id="Vector" stroke="var(--stroke-0, #0A6ED1)" strokeLinecap="round" strokeLinejoin="round" />
                                      <path d="M6 2.5V9.5" id="Vector_2" stroke="var(--stroke-0, #0A6ED1)" strokeLinecap="round" strokeLinejoin="round" />
                                    </g>
                                  </svg>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                        <div className="absolute h-[134px] left-0 top-[40.5px] w-[877.375px]" data-name="tbody">
                          <div className="absolute border-[#e5ecf5] border-b border-solid h-[33.5px] left-0 top-0 w-[877.375px]" data-name="tr">
                            <div className="absolute border-[#e5ecf5] border-r border-solid h-[33.5px] left-0 top-0 w-[38.5px]" data-name="td">
                              <div className="absolute h-[24.5px] left-[4px] rounded-[4px] top-[4.5px] w-[30px]" data-name="button">
                                <p className="-translate-x-1/2 absolute font-['Inter:Medium',sans-serif] font-medium leading-[16.5px] left-[15.32px] not-italic text-[#98a2b3] text-[11px] text-center top-[4.5px] tracking-[0.0645px] whitespace-nowrap">1</p>
                              </div>
                            </div>
                            <div className="absolute border-[#e5ecf5] border-r border-solid h-[33.5px] left-[38.5px] top-0 w-[130.445px]" data-name="td">
                              <div className="absolute content-stretch flex h-[24.5px] items-center left-[4.5px] pl-[6px] pr-[20px] rounded-[4px] top-[4.5px] w-[121.445px]" data-name="button">
                                <SpanText3 text="&nbsp;" />
                              </div>
                            </div>
                            <div className="absolute border-[#e5ecf5] border-r border-solid h-[33.5px] left-[168.95px] top-0 w-[104.234px]" data-name="td">
                              <div className="absolute content-stretch flex h-[24.5px] items-center left-[4.5px] pl-[7px] pr-[21px] py-px rounded-[4px] top-[4.5px] w-[95.234px]" data-name="button">
                                <div aria-hidden="true" className="absolute border border-[#0a6ed1] border-solid inset-0 pointer-events-none rounded-[4px]" />
                                <SpanText3 text="9150072702" />
                              </div>
                            </div>
                            <div className="absolute border-[#e5ecf5] border-r border-solid h-[33.5px] left-[273.18px] top-0 w-[288.969px]" data-name="td">
                              <div className="absolute content-stretch flex h-[24.5px] items-center left-[4.5px] pl-[7px] pr-[21px] py-px rounded-[4px] top-[4.5px] w-[279.969px]" data-name="button">
                                <div aria-hidden="true" className="absolute border border-[#0a6ed1] border-solid inset-0 pointer-events-none rounded-[4px]" />
                                <Span>管乐, 拉杆柜组7 组合(包括：Eyba*25mm, Ty...)</Span>
                              </div>
                            </div>
                            <div className="absolute border-[#e5ecf5] border-r border-solid h-[33.5px] left-[562.15px] top-0 w-[50.227px]" data-name="td">
                              <div className="absolute bg-[#eef4ff] content-stretch flex h-[24.5px] items-center left-[4.5px] pl-[6px] pr-[20px] rounded-[4px] top-[4.5px] w-[41.227px]" data-name="button">
                                <SpanText3 text="PC" />
                              </div>
                            </div>
                            <div className="absolute border-[#e5ecf5] border-r border-solid h-[33.5px] left-[612.38px] top-0 w-[49.047px]" data-name="td">
                              <div className="absolute bg-[#eef4ff] content-stretch flex h-[24.5px] items-center left-[4.5px] pl-[6px] pr-[20px] rounded-[4px] top-[4.5px] w-[40.047px]" data-name="button">
                                <SpanText3 text="20" />
                              </div>
                            </div>
                            <div className="absolute border-[#e5ecf5] border-r border-solid h-[33.5px] left-[661.42px] top-0 w-[66.266px]" data-name="td">
                              <div className="absolute bg-[#eef4ff] content-stretch flex h-[24.5px] items-center left-[4.5px] pl-[6px] pr-[20px] rounded-[4px] top-[4.5px] w-[57.266px]" data-name="button">
                                <SpanText3 text="30.00" />
                              </div>
                            </div>
                            <div className="absolute border-[#e5ecf5] border-r border-solid h-[33.5px] left-[727.69px] top-0 w-[90.188px]" data-name="td">
                              <div className="absolute bg-[#eef4ff] content-stretch flex h-[24.5px] items-center left-[4.5px] pl-[6px] pr-[20px] rounded-[4px] top-[4.5px] w-[81.188px]" data-name="button">
                                <SpanText3 text="12500000" />
                              </div>
                            </div>
                            <div className="absolute border-[#e5ecf5] border-r border-solid h-[33.5px] left-[817.88px] top-0 w-[39px]" data-name="td">
                              <div className="absolute content-stretch flex h-[24.5px] items-center left-[4.5px] pl-[6px] pr-[20px] rounded-[4px] top-[4.5px] w-[30px]" data-name="button">
                                <SpanText3 text="&nbsp;" />
                              </div>
                            </div>
                            <div className="absolute border-[#e5ecf5] border-l border-solid h-[33.5px] left-[856.88px] top-0 w-[20.5px]" data-name="td" />
                          </div>
                          <div className="absolute border-[#e5ecf5] border-b border-solid h-[33.5px] left-0 top-[33.5px] w-[877.375px]" data-name="tr">
                            <div className="absolute border-[#e5ecf5] border-r border-solid h-[33.5px] left-0 top-0 w-[38.5px]" data-name="td">
                              <div className="absolute h-[24.5px] left-[4px] rounded-[4px] top-[4.5px] w-[30px]" data-name="button">
                                <p className="-translate-x-1/2 absolute font-['Inter:Medium',sans-serif] font-medium leading-[16.5px] left-[15.07px] not-italic text-[#98a2b3] text-[11px] text-center top-[4.5px] tracking-[0.0645px] whitespace-nowrap">2</p>
                              </div>
                            </div>
                            <div className="absolute border-[#e5ecf5] border-r border-solid h-[33.5px] left-[38.5px] top-0 w-[130.445px]" data-name="td">
                              <div className="absolute content-stretch flex h-[24.5px] items-center left-[4.5px] pl-[7px] pr-[21px] py-px rounded-[4px] top-[4.5px] w-[121.445px]" data-name="button">
                                <div aria-hidden="true" className="absolute border border-[#0a6ed1] border-solid inset-0 pointer-events-none rounded-[4px]" />
                                <SpanText3 text="ZADM450061625" />
                              </div>
                            </div>
                            <div className="absolute border-[#e5ecf5] border-r border-solid h-[33.5px] left-[168.95px] top-0 w-[104.234px]" data-name="td">
                              <div className="absolute content-stretch flex h-[24.5px] items-center left-[4.5px] pl-[7px] pr-[21px] py-px rounded-[4px] top-[4.5px] w-[95.234px]" data-name="button">
                                <div aria-hidden="true" className="absolute border border-[#0a6ed1] border-solid inset-0 pointer-events-none rounded-[4px]" />
                                <SpanText3 text="9150060470" />
                              </div>
                            </div>
                            <div className="absolute border-[#e5ecf5] border-r border-solid h-[33.5px] left-[273.18px] top-0 w-[288.969px]" data-name="td">
                              <div className="absolute content-stretch flex h-[24.5px] items-center left-[4.5px] pl-[7px] pr-[21px] py-px rounded-[4px] top-[4.5px] w-[279.969px]" data-name="button">
                                <div aria-hidden="true" className="absolute border border-[#0a6ed1] border-solid inset-0 pointer-events-none rounded-[4px]" />
                                <Span>{`管乐, 拉杆柜组(批, M3.5.X28,B10" 24 五金柜机...)`}</Span>
                              </div>
                            </div>
                            <div className="absolute border-[#e5ecf5] border-r border-solid h-[33.5px] left-[562.15px] top-0 w-[50.227px]" data-name="td">
                              <div className="absolute bg-[#eef4ff] content-stretch flex h-[24.5px] items-center left-[4.5px] pl-[6px] pr-[20px] rounded-[4px] top-[4.5px] w-[41.227px]" data-name="button">
                                <SpanText3 text="PC" />
                              </div>
                            </div>
                            <div className="absolute border-[#e5ecf5] border-r border-solid h-[33.5px] left-[612.38px] top-0 w-[49.047px]" data-name="td">
                              <div className="absolute bg-[#eef4ff] content-stretch flex h-[24.5px] items-center left-[4.5px] pl-[6px] pr-[20px] rounded-[4px] top-[4.5px] w-[40.047px]" data-name="button">
                                <SpanText3 text="20" />
                              </div>
                            </div>
                            <div className="absolute border-[#e5ecf5] border-r border-solid h-[33.5px] left-[661.42px] top-0 w-[66.266px]" data-name="td">
                              <div className="absolute bg-[#eef4ff] content-stretch flex h-[24.5px] items-center left-[4.5px] pl-[6px] pr-[20px] rounded-[4px] top-[4.5px] w-[57.266px]" data-name="button">
                                <SpanText3 text="8.80" />
                              </div>
                            </div>
                            <div className="absolute border-[#e5ecf5] border-r border-solid h-[33.5px] left-[727.69px] top-0 w-[90.188px]" data-name="td">
                              <div className="absolute bg-[#eef4ff] content-stretch flex h-[24.5px] items-center left-[4.5px] pl-[6px] pr-[20px] rounded-[4px] top-[4.5px] w-[81.188px]" data-name="button">
                                <SpanText3 text="13260.00" />
                              </div>
                            </div>
                            <div className="absolute border-[#e5ecf5] border-r border-solid h-[33.5px] left-[817.88px] top-0 w-[39px]" data-name="td">
                              <div className="absolute content-stretch flex h-[24.5px] items-center left-[4.5px] pl-[6px] pr-[20px] rounded-[4px] top-[4.5px] w-[30px]" data-name="button">
                                <SpanText3 text="&nbsp;" />
                              </div>
                            </div>
                            <div className="absolute border-[#e5ecf5] border-l border-solid h-[33.5px] left-[856.88px] top-0 w-[20.5px]" data-name="td" />
                          </div>
                          <div className="absolute border-[#e5ecf5] border-b border-solid h-[33.5px] left-0 top-[67px] w-[877.375px]" data-name="tr">
                            <div className="absolute border-[#e5ecf5] border-r border-solid h-[33.5px] left-0 top-0 w-[38.5px]" data-name="td">
                              <div className="absolute h-[24.5px] left-[4px] rounded-[4px] top-[4.5px] w-[30px]" data-name="button">
                                <p className="-translate-x-1/2 absolute font-['Inter:Medium',sans-serif] font-medium leading-[16.5px] left-[15.44px] not-italic text-[#98a2b3] text-[11px] text-center top-[4.5px] tracking-[0.0645px] whitespace-nowrap">3</p>
                              </div>
                            </div>
                            <div className="absolute border-[#e5ecf5] border-r border-solid h-[33.5px] left-[38.5px] top-0 w-[130.445px]" data-name="td">
                              <div className="absolute content-stretch flex h-[24.5px] items-center left-[4.5px] pl-[6px] pr-[20px] rounded-[4px] top-[4.5px] w-[121.445px]" data-name="button">
                                <SpanText3 text="&nbsp;" />
                              </div>
                            </div>
                            <div className="absolute border-[#e5ecf5] border-r border-solid h-[33.5px] left-[168.95px] top-0 w-[104.234px]" data-name="td">
                              <div className="absolute content-stretch flex h-[24.5px] items-center left-[4.5px] pl-[6px] pr-[20px] rounded-[4px] top-[4.5px] w-[95.234px]" data-name="button">
                                <SpanText3 text="&nbsp;" />
                              </div>
                            </div>
                            <div className="absolute border-[#e5ecf5] border-r border-solid h-[33.5px] left-[273.18px] top-0 w-[288.969px]" data-name="td">
                              <div className="absolute content-stretch flex h-[24.5px] items-center left-[4.5px] pl-[6px] pr-[20px] rounded-[4px] top-[4.5px] w-[279.969px]" data-name="button">
                                <SpanText3 text="&nbsp;" />
                              </div>
                            </div>
                            <div className="absolute border-[#e5ecf5] border-r border-solid h-[33.5px] left-[562.15px] top-0 w-[50.227px]" data-name="td">
                              <div className="absolute content-stretch flex h-[24.5px] items-center left-[4.5px] pl-[6px] pr-[20px] rounded-[4px] top-[4.5px] w-[41.227px]" data-name="button">
                                <SpanText3 text="&nbsp;" />
                              </div>
                            </div>
                            <div className="absolute border-[#e5ecf5] border-r border-solid h-[33.5px] left-[612.38px] top-0 w-[49.047px]" data-name="td">
                              <div className="absolute content-stretch flex h-[24.5px] items-center left-[4.5px] pl-[6px] pr-[20px] rounded-[4px] top-[4.5px] w-[40.047px]" data-name="button">
                                <SpanText3 text="&nbsp;" />
                              </div>
                            </div>
                            <div className="absolute border-[#e5ecf5] border-r border-solid h-[33.5px] left-[661.42px] top-0 w-[66.266px]" data-name="td">
                              <div className="absolute content-stretch flex h-[24.5px] items-center left-[4.5px] pl-[6px] pr-[20px] rounded-[4px] top-[4.5px] w-[57.266px]" data-name="button">
                                <SpanText3 text="&nbsp;" />
                              </div>
                            </div>
                            <div className="absolute border-[#e5ecf5] border-r border-solid h-[33.5px] left-[727.69px] top-0 w-[90.188px]" data-name="td">
                              <div className="absolute content-stretch flex h-[24.5px] items-center left-[4.5px] pl-[6px] pr-[20px] rounded-[4px] top-[4.5px] w-[81.188px]" data-name="button">
                                <SpanText3 text="&nbsp;" />
                              </div>
                            </div>
                            <div className="absolute border-[#e5ecf5] border-r border-solid h-[33.5px] left-[817.88px] top-0 w-[39px]" data-name="td">
                              <div className="absolute content-stretch flex h-[24.5px] items-center left-[4.5px] pl-[6px] pr-[20px] rounded-[4px] top-[4.5px] w-[30px]" data-name="button">
                                <SpanText3 text="&nbsp;" />
                              </div>
                            </div>
                            <div className="absolute border-[#e5ecf5] border-l border-solid h-[33.5px] left-[856.88px] top-0 w-[20.5px]" data-name="td" />
                          </div>
                          <div className="absolute border-[#e5ecf5] border-b border-solid h-[33.5px] left-0 top-[100.5px] w-[877.375px]" data-name="tr">
                            <div className="absolute border-[#e5ecf5] border-r border-solid h-[33.5px] left-0 top-0 w-[38.5px]" data-name="td">
                              <div className="absolute h-[24.5px] left-[4px] rounded-[4px] top-[4.5px] w-[30px]" data-name="button">
                                <p className="-translate-x-1/2 absolute font-['Inter:Medium',sans-serif] font-medium leading-[16.5px] left-[15.34px] not-italic text-[#98a2b3] text-[11px] text-center top-[4.5px] tracking-[0.0645px] whitespace-nowrap">4</p>
                              </div>
                            </div>
                            <div className="absolute border-[#e5ecf5] border-r border-solid h-[33.5px] left-[38.5px] top-0 w-[130.445px]" data-name="td">
                              <div className="absolute content-stretch flex h-[24.5px] items-center left-[4.5px] pl-[6px] pr-[20px] rounded-[4px] top-[4.5px] w-[121.445px]" data-name="button">
                                <SpanText3 text="&nbsp;" />
                              </div>
                            </div>
                            <div className="absolute border-[#e5ecf5] border-r border-solid h-[33.5px] left-[168.95px] top-0 w-[104.234px]" data-name="td">
                              <div className="absolute content-stretch flex h-[24.5px] items-center left-[4.5px] pl-[6px] pr-[20px] rounded-[4px] top-[4.5px] w-[95.234px]" data-name="button">
                                <SpanText3 text="&nbsp;" />
                              </div>
                            </div>
                            <div className="absolute border-[#e5ecf5] border-r border-solid h-[33.5px] left-[273.18px] top-0 w-[288.969px]" data-name="td">
                              <div className="absolute content-stretch flex h-[24.5px] items-center left-[4.5px] pl-[6px] pr-[20px] rounded-[4px] top-[4.5px] w-[279.969px]" data-name="button">
                                <SpanText3 text="&nbsp;" />
                              </div>
                            </div>
                            <div className="absolute border-[#e5ecf5] border-r border-solid h-[33.5px] left-[562.15px] top-0 w-[50.227px]" data-name="td">
                              <div className="absolute content-stretch flex h-[24.5px] items-center left-[4.5px] pl-[6px] pr-[20px] rounded-[4px] top-[4.5px] w-[41.227px]" data-name="button">
                                <SpanText3 text="&nbsp;" />
                              </div>
                            </div>
                            <div className="absolute border-[#e5ecf5] border-r border-solid h-[33.5px] left-[612.38px] top-0 w-[49.047px]" data-name="td">
                              <div className="absolute content-stretch flex h-[24.5px] items-center left-[4.5px] pl-[6px] pr-[20px] rounded-[4px] top-[4.5px] w-[40.047px]" data-name="button">
                                <SpanText3 text="&nbsp;" />
                              </div>
                            </div>
                            <div className="absolute border-[#e5ecf5] border-r border-solid h-[33.5px] left-[661.42px] top-0 w-[66.266px]" data-name="td">
                              <div className="absolute content-stretch flex h-[24.5px] items-center left-[4.5px] pl-[6px] pr-[20px] rounded-[4px] top-[4.5px] w-[57.266px]" data-name="button">
                                <SpanText3 text="&nbsp;" />
                              </div>
                            </div>
                            <div className="absolute border-[#e5ecf5] border-r border-solid h-[33.5px] left-[727.69px] top-0 w-[90.188px]" data-name="td">
                              <div className="absolute content-stretch flex h-[24.5px] items-center left-[4.5px] pl-[6px] pr-[20px] rounded-[4px] top-[4.5px] w-[81.188px]" data-name="button">
                                <SpanText3 text="&nbsp;" />
                              </div>
                            </div>
                            <div className="absolute border-[#e5ecf5] border-r border-solid h-[33.5px] left-[817.88px] top-0 w-[39px]" data-name="td">
                              <div className="absolute content-stretch flex h-[24.5px] items-center left-[4.5px] pl-[6px] pr-[20px] rounded-[4px] top-[4.5px] w-[30px]" data-name="button">
                                <SpanText3 text="&nbsp;" />
                              </div>
                            </div>
                            <div className="absolute border-[#e5ecf5] border-l border-solid h-[33.5px] left-[856.88px] top-0 w-[20.5px]" data-name="td" />
                          </div>
                        </div>
                      </div>
                      <div className="absolute border-[#e5ecf5] border-b border-solid h-[33.5px] left-0 top-[175px] w-[489px]" data-name="button">
                        <div className="absolute left-[218px] size-[14px] top-[9.25px]" data-name="Plus">
                          <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 14 14">
                            <g id="Plus">
                              <path d="M2.91667 7H11.0833" id="Vector" stroke="var(--stroke-0, #0A6ED1)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.16667" />
                              <path d="M7 2.91667V11.0833" id="Vector_2" stroke="var(--stroke-0, #0A6ED1)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.16667" />
                            </g>
                          </svg>
                        </div>
                        <p className="-translate-x-1/2 absolute font-['Inter:Medium','Noto_Sans_JP:Medium',sans-serif] font-medium leading-[16.5px] left-[254px] not-italic text-[#0a6ed1] text-[11px] text-center top-[8.5px] tracking-[0.0645px] whitespace-nowrap">新增行</p>
                      </div>
                    </div>
                    <div className="h-[161.5px] relative shrink-0 w-full" data-name="Container">
                      <div aria-hidden="true" className="absolute border-[#d0d5dd] border-solid border-t inset-0 pointer-events-none" />
                      <div className="content-stretch flex flex-col gap-[16px] items-start pt-[13px] px-[20px] relative size-full">
                        <div className="h-[20px] relative shrink-0 w-full" data-name="p">
                          <p className="absolute font-['Inter:Regular','Noto_Sans_JP:Regular','Noto_Sans_SC:Regular','Noto_Sans_KR:Regular',sans-serif] font-normal leading-[20px] left-0 not-italic text-[#6b7b8d] text-[11px] top-[0.5px] tracking-[0.0645px] whitespace-nowrap">注：以上货品请核对清楚，如有问题请于收货后3日内通知。</p>
                        </div>
                        <div className="content-stretch flex h-[92.5px] items-end justify-between relative shrink-0 w-full" data-name="Container">
                          <Wrapper2 additionalClassNames="h-[92.5px] w-[88px]">
                            <PText text="送货方签名盖章：" />
                            <div className="absolute content-stretch flex flex-col items-start left-0 size-[72px] top-[20.5px]" data-name="Container">
                              <Svg text="&nbsp;" text1="印章" />
                            </div>
                          </Wrapper2>
                          <Wrapper2 additionalClassNames="h-[92.5px] w-[88px]">
                            <PText text="收货方签名盖章：" />
                            <div className="absolute content-stretch flex flex-col items-start left-[16px] size-[72px] top-[20.5px]" data-name="Container">
                              <Svg text="&nbsp;" text1="印章" />
                            </div>
                          </Wrapper2>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div aria-hidden="true" className="absolute border border-[#e5ecf5] border-solid inset-0 pointer-events-none rounded-[14px] shadow-[0px_1px_3px_0px_rgba(0,0,0,0.04)]" />
              </div>
            </div>
          </div>
          <div className="bg-[#fafbfc] h-[86px] relative shrink-0 w-[567px]" data-name="Container">
            <div aria-hidden="true" className="absolute border-[#f0f2f5] border-solid border-t inset-0 pointer-events-none" />
            <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col gap-[8px] items-start pt-[13px] px-[20px] relative size-full">
              <div className="content-stretch flex gap-[8px] h-[18px] items-center relative shrink-0 w-full" data-name="Container">
                <Wrapper6 additionalClassNames="relative shrink-0">
                  <g clipPath="url(#clip0_48_3005)" id="CheckCircle2">
                    <path d={svgPaths.p39ee6532} id="Vector" stroke="var(--stroke-0, #12B76A)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
                    <path d={svgPaths.p17134c00} id="Vector_2" stroke="var(--stroke-0, #12B76A)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
                  </g>
                  <defs>
                    <clipPath id="clip0_48_3005">
                      <rect fill="white" height="16" width="16" />
                    </clipPath>
                  </defs>
                </Wrapper6>
                <Wrapper2 additionalClassNames="h-[18px] w-[100.664px]">
                  <p className="absolute font-['Inter:Regular','Noto_Sans_JP:Regular','Noto_Sans_SC:Regular',sans-serif] font-normal leading-[0] left-0 not-italic text-[#344054] text-[12px] top-px whitespace-nowrap">
                    <span className="leading-[18px]">{`AI 已识别 `}</span>
                    <span className="leading-[18px] text-[#0a6ed1]">2</span>
                    <span className="leading-[18px]">{` 项产品`}</span>
                  </p>
                </Wrapper2>
              </div>
              <div className="bg-gradient-to-b from-[#f0f7ff] h-[34.5px] relative rounded-[10px] shrink-0 to-[#e8f1fc] w-full" data-name="Container">
                <div aria-hidden="true" className="absolute border border-[#d0e2f7] border-solid inset-0 pointer-events-none rounded-[10px]" />
                <div className="flex flex-row items-center size-full">
                  <div className="content-stretch flex gap-[12px] items-center px-[13px] py-px relative size-full">
                    <Wrapper2 additionalClassNames="h-[16.5px] w-[22px]">
                      <p className="absolute font-['Inter:Regular','Noto_Sans_JP:Regular','Noto_Sans_SC:Regular',sans-serif] font-normal leading-[16.5px] left-0 not-italic text-[#0a6ed1] text-[11px] top-[0.5px] tracking-[0.0645px] whitespace-nowrap">合计</p>
                    </Wrapper2>
                    <div className="flex-[1_0_0] h-[16.5px] min-h-px min-w-px relative" data-name="Container">
                      <div className="flex flex-row items-center size-full">
                        <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-center justify-between pr-[0.008px] relative size-full">
                          <SpanText4 text="—" />
                          <Wrapper2 additionalClassNames="h-[16.5px] w-[42.867px]">
                            <p className="absolute font-['Inter:Regular','Noto_Sans_SC:Regular','Noto_Sans_JP:Regular',sans-serif] font-normal leading-[16.5px] left-0 not-italic text-[#344054] text-[11px] top-[0.5px] tracking-[0.0645px] whitespace-nowrap">2 项产品</p>
                          </Wrapper2>
                          <SpanText5 text="PC" additionalClassNames="w-[14.992px]" />
                          <SpanText6 text="40" additionalClassNames="w-[14.141px]" />
                          <SpanText5 text="38.80" additionalClassNames="w-[30.719px]" />
                          <SpanText6 text="12513260.00" additionalClassNames="w-[68.086px]" />
                          <SpanText4 text="—" />
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div aria-hidden="true" className="absolute border border-[#e5ecf5] border-solid inset-0 pointer-events-none rounded-[16px] shadow-[0px_1px_3px_0px_rgba(0,0,0,0.1),0px_1px_2px_-1px_rgba(0,0,0,0.1)]" />
      </div>
      <div className="absolute bg-[rgba(157,200,244,0.56)] left-[1296px] rounded-[10px] size-[51px] top-[59px]" data-name="Back">
        <div className="absolute bottom-1/4 flex items-center justify-center left-[16.67%] right-[16.67%] top-[20.83%]">
          <div className="-scale-y-100 flex-none h-[22.75px] w-[28px]">
            <div className="relative size-full">
              <div className="absolute inset-[-3.62%_-2.94%_-2.56%_-4.16%]">
                <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 36.4142 29.3321">
                  <path d={svgPaths.p1f574d00} fill="var(--stroke-0, #4282EC)" id="Vector 10" />
                </svg>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div className="absolute bg-[rgba(0,0,0,0)] h-[1024px] left-[81px] top-0 w-[1331px]" />
      <div className="absolute bg-white content-stretch flex flex-col gap-[32px] items-start left-[452px] p-[24px] rounded-[16px] top-[233px] w-[556px]">
        <div aria-hidden="true" className="absolute border border-[#c9cdd4] border-solid inset-0 pointer-events-none rounded-[16px]" />
        <div className="content-stretch flex flex-col gap-[24px] items-start relative shrink-0 w-full">
          <div className="content-stretch flex flex-col gap-[8px] items-start relative shrink-0 w-full">
            <p className="font-['DM_Sans:Bold','Noto_Sans_JP:Bold','Noto_Sans_SC:Bold',sans-serif] font-bold leading-[24px] relative shrink-0 text-[#101828] text-[22px] w-full" style={{ fontVariationSettings: "'opsz' 14" }}>
              下载文件
            </p>
          </div>
          <div className="content-stretch flex flex-col gap-[24px] items-center relative shrink-0 w-full">
            <div className="h-[382px] relative rounded-[4px] shrink-0 w-full">
              <div className="absolute content-stretch flex flex-col gap-[19.8px] h-[382px] items-center left-0 p-[16.5px] rounded-[4px] top-0 w-[508px]">
                <div aria-hidden="true" className="absolute border-[#d0d5dd] border-[1.65px] border-solid inset-0 pointer-events-none rounded-[4px] shadow-[0px_4.4px_48.4px_0px_rgba(0,0,0,0.1)]" />
                <Wrapper>
                  <div className="relative rounded-[1px] shrink-0 size-[42px]" data-name="Filetype Icon">
                    <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 42 42">
                      <path d={svgPaths.p11e98800} fill="var(--fill-0, #F2F2F2)" id="Page" />
                    </svg>
                    <Corner />
                    <div className="absolute bg-[#ef4444] bottom-[9.38%] left-[6.25%] right-[6.25%] rounded-[1.1px] top-1/2" data-name="Container">
                      <div className="absolute inset-[21.15%_16.84%]" data-name="-">
                        <div className="absolute inset-[-2.96%_-1.2%]">
                          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24.9553 10.4271">
                            <g id="-">
                              <path d={svgPaths.p3d53c000} fill="var(--fill-0, white)" />
                              <path d={svgPaths.p2c323200} fill="var(--fill-0, white)" />
                              <path d={svgPaths.p17178c0} fill="var(--fill-0, white)" />
                              <path d={svgPaths.p3d53c000} stroke="var(--stroke-0, white)" strokeWidth="0.583334" />
                              <path d={svgPaths.p2c323200} stroke="var(--stroke-0, white)" strokeWidth="0.583334" />
                              <path d={svgPaths.p17178c0} stroke="var(--stroke-0, white)" strokeWidth="0.583334" />
                            </g>
                          </svg>
                        </div>
                      </div>
                    </div>
                  </div>
                  <Helper text="AI生成的报价单" text1=".pdf" />
                  <Wrapper7 additionalClassNames="font-['DM_Sans:Regular',sans-serif] text-[#0a6ed1] text-center">2.4 MB</Wrapper7>
                </Wrapper>
                <Wrapper>
                  <div className="relative rounded-[1.333px] shrink-0 size-[42px]" data-name="Filetype Icon">
                    <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 42 42">
                      <path d={svgPaths.p20bfc200} fill="var(--fill-0, #F2F2F2)" id="Page" />
                    </svg>
                    <Corner />
                    <div className="absolute bg-[#3b82f6] bottom-[9.38%] left-[6.25%] right-[6.25%] rounded-[1.333px] top-1/2" data-name="Container">
                      <div className="absolute inset-[21.15%_16.4%]" data-name="-">
                        <div className="absolute inset-[-2.96%_-1.18%]">
                          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 25.2758 10.4271">
                            <g id="-">
                              <path d={svgPaths.p230be180} fill="var(--fill-0, white)" />
                              <path d={svgPaths.p190f7980} fill="var(--fill-0, white)" />
                              <path d={svgPaths.p30759af0} fill="var(--fill-0, white)" />
                              <path d={svgPaths.p230be180} stroke="var(--stroke-0, white)" strokeWidth="0.583334" />
                              <path d={svgPaths.p190f7980} stroke="var(--stroke-0, white)" strokeWidth="0.583334" />
                              <path d={svgPaths.p30759af0} stroke="var(--stroke-0, white)" strokeWidth="0.583334" />
                            </g>
                          </svg>
                        </div>
                      </div>
                    </div>
                  </div>
                  <Helper text="AI生成的报价单" text1=".jpg" />
                  <Wrapper7 additionalClassNames="font-['DM_Sans:Regular',sans-serif] text-[#0a6ed1] text-center">0.4 MB</Wrapper7>
                </Wrapper>
              </div>
            </div>
            <div className="bg-[#0a6ed1] relative rounded-[4px] shrink-0 w-full" data-name="Component 7">
              <div className="flex flex-row items-center justify-center size-full">
                <div className="content-stretch flex gap-[10px] items-center justify-center p-[12px] relative w-full">
                  <div className="relative shrink-0 size-[12px]" data-name="Export_light">
                    <div className="absolute inset-[0_0_0.01%_0]">
                      <div className="absolute inset-[-4.17%]">
                        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 13 12.9992">
                          <g id="Group 2478">
                            <path d={svgPaths.p227af200} id="Vector 9" stroke="var(--stroke-0, white)" strokeLinecap="round" />
                            <path d={svgPaths.p35ee1d80} id="Vector 114" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" />
                          </g>
                        </svg>
                      </div>
                    </div>
                  </div>
                  <Wrapper7 additionalClassNames="font-['DM_Sans:Regular','Noto_Sans_JP:Regular','Noto_Sans_SC:Regular',sans-serif] text-white">下载文件</Wrapper7>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div className="absolute bg-white right-[16px] rounded-[8px] size-[36px] top-[16px]" data-name="Buttons/Button">
          <div className="flex flex-row items-center justify-center overflow-clip rounded-[inherit] size-full">
            <div className="content-stretch flex items-center justify-center p-[8px] relative size-full">
              <div className="flex-[1_0_0] h-full min-h-px min-w-px overflow-clip relative" data-name="x-close">
                <div className="absolute inset-1/4" data-name="Icon">
                  <div className="absolute inset-[-8.33%]">
                    <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 11.6667 11.6667">
                      <path d={svgPaths.p3f40eb80} id="Icon" stroke="var(--stroke-0, #344054)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.66667" />
                    </svg>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}