import svgPaths from "./svg-toxuphypl4";

export default function Frame() {
  return (
    <div className="bg-white relative rounded-[16px] size-full">
      <div aria-hidden="true" className="absolute border border-[#c9cdd4] border-solid inset-0 pointer-events-none rounded-[16px]" />
      <div className="content-stretch flex flex-col gap-[32px] items-start p-[24px] relative size-full">
        <div className="content-stretch flex flex-col gap-[24px] items-start relative shrink-0 w-full">
          <div className="content-stretch flex flex-col gap-[8px] items-start relative shrink-0 w-full">
            <p className="font-['DM_Sans:Bold','Noto_Sans_JP:Bold','Noto_Sans_SC:Bold',sans-serif] font-bold leading-[24px] relative shrink-0 text-[#101828] text-[22px] w-full" style={{ fontVariationSettings: "'opsz' 14" }}>
              上传文件
            </p>
            <p className="font-['ABeeZee:Regular','Noto_Sans_JP:Regular','Noto_Sans_SC:Regular',sans-serif] leading-[18px] relative shrink-0 text-[#344054] text-[12px] w-full" style={{ fontVariationSettings: "'wght' 400" }}>
              每次最多可上传一个文件，单个文件大小上限为50 MB。
            </p>
          </div>
          <div className="h-[300px] relative shrink-0 w-full" data-name="File upload">
            <div className="content-stretch flex flex-col items-start relative size-full">
              <div className="bg-white flex-[1_0_0] min-h-px min-w-px relative rounded-[8px] w-full" data-name="_File upload base">
                <div aria-hidden="true" className="absolute border border-[#d0d5dd] border-dashed inset-0 pointer-events-none rounded-[8px]" />
                <div className="flex flex-col items-center justify-center size-full">
                  <div className="content-stretch flex flex-col items-center justify-center px-[24px] py-[16px] relative size-full">
                    <div className="content-stretch flex flex-col gap-[12px] items-center relative shrink-0 w-full" data-name="Content">
                      <div className="relative rounded-[8px] shrink-0 size-[40px]" data-name="Featured icon">
                        <div aria-hidden="true" className="absolute border border-[#eaecf0] border-solid inset-0 pointer-events-none rounded-[8px]" />
                        <div className="absolute left-[10px] overflow-clip size-[20px] top-[10px]" data-name="upload-cloud-02">
                          <div className="absolute inset-[12.5%_8.33%]" data-name="Icon">
                            <div className="absolute inset-[-5.56%_-5%]">
                              <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 18.3333 16.6667">
                                <path d={svgPaths.p6318e80} id="Icon" stroke="var(--stroke-0, #344054)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.66667" />
                              </svg>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div className="content-stretch flex flex-col gap-[4px] items-center relative shrink-0 w-full" data-name="Text and supporting text">
                        <div className="content-stretch flex gap-[4px] items-start justify-center relative shrink-0 w-full" data-name="Action">
                          <div className="relative shrink-0" data-name="Buttons/Button">
                            <div className="flex flex-row items-center justify-center overflow-clip rounded-[inherit] size-full">
                              <div className="content-stretch flex gap-[6px] items-center justify-center relative">
                                <p className="font-['DM_Sans:Regular','Noto_Sans_JP:Regular','Noto_Sans_SC:Regular',sans-serif] font-normal leading-[22px] relative shrink-0 text-[#0a6ed1] text-[20px] whitespace-nowrap" style={{ fontVariationSettings: "'opsz' 14" }}>
                                  点击上传
                                </p>
                              </div>
                            </div>
                          </div>
                          <p className="font-['DM_Sans:Regular','Noto_Sans_JP:Regular','Noto_Sans_SC:Regular',sans-serif] font-normal leading-[22px] relative shrink-0 text-[#475467] text-[20px] whitespace-nowrap" style={{ fontVariationSettings: "'opsz' 14" }}>
                            或者拖拽到这里
                          </p>
                        </div>
                        <p className="font-['ABeeZee:Regular',sans-serif] leading-[0] not-italic relative shrink-0 text-[#475467] text-[0px] text-[12px] text-center w-full">
                          <span className="leading-[18px]">doc/pdf/ jpg/xlsx</span>
                          <span className="leading-[18px]">{` (max. 800x400px)`}</span>
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div className="absolute bg-white right-[16px] rounded-[8px] size-[36px] top-[16px]" data-name="Buttons/Button">
          <div className="flex flex-row items-center justify-center overflow-clip rounded-[inherit] size-full">
            <div className="content-stretch flex items-center justify-center p-[8px] relative size-full">
              <div className="flex-[1_0_0] h-full min-h-px min-w-px overflow-clip relative" data-name="x-close">
                <div className="absolute inset-1/4" data-name="Icon">
                  <div className="absolute inset-[-8.33%]">
                    <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 11.6667 11.6667">
                      <path d={svgPaths.p3f40eb80} id="Icon" stroke="var(--stroke-0, #344054)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.66667" />
                    </svg>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}