import img2025120512405121 from "figma:asset/0fb7738e99e722ceb1abac61599257cef011512c.png";
import { Plus, Trash2 } from "lucide-react";

export function DocumentPreview() {
  return (
    <div className="bg-white rounded-2xl border border-[#e5ecf5] flex flex-col items-center justify-center p-8 h-full min-h-0">
      {/* Main document preview */}
      <div className="flex-1 flex items-center justify-center w-full min-h-0 mb-5">
        <div className="relative rounded-lg border border-[#d0d5dd] overflow-hidden shadow-sm max-h-full">
          <img
            src={img2025120512405121}
            alt="Document preview"
            className="max-h-[420px] w-auto object-contain"
          />
        </div>
      </div>

      {/* Thumbnail strip */}
      <div className="flex gap-4 items-center mb-4">
        {/* Thumbnail 1 */}
        <div className="w-[80px] h-[110px] rounded-lg border border-dashed border-[#b8c2cc] overflow-hidden cursor-pointer hover:border-[#0a6ed1] transition-colors">
          <img
            src={img2025120512405121}
            alt="Thumbnail 1"
            className="w-full h-full object-cover opacity-70"
          />
        </div>
        {/* Thumbnail 2 - selected */}
        <div className="w-[80px] h-[110px] rounded-lg border-2 border-[#0a6ed1] overflow-hidden relative cursor-pointer shadow-md">
          <img
            src={img2025120512405121}
            alt="Thumbnail 2"
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-black/20 flex items-center justify-center">
            <Trash2 className="w-5 h-5 text-white" />
          </div>
        </div>
        {/* Thumbnail 3 */}
        <div className="w-[80px] h-[110px] rounded-lg border border-dashed border-[#b8c2cc] overflow-hidden cursor-pointer hover:border-[#0a6ed1] transition-colors">
          <img
            src={img2025120512405121}
            alt="Thumbnail 3"
            className="w-full h-full object-cover opacity-70"
          />
        </div>
        {/* Add button */}
        <div className="w-[80px] h-[110px] rounded-lg border border-dashed border-[#d0d5dd] flex items-center justify-center cursor-pointer hover:border-[#0a6ed1] hover:bg-[#f5f9ff] transition-all">
          <Plus className="w-7 h-7 text-[#667085]" />
        </div>
      </div>

      {/* Tip */}
      <p className="text-[12px] text-[#475467]">
        温馨提示：普通用户只能上传三页文档！想要上传更多文档请开通{" "}
        <span className="text-[#0a6ed1] underline cursor-pointer hover:text-[#084ea0]">
          高级会员
        </span>
        。
      </p>
    </div>
  );
}
