import { useState, useRef } from "react";
import { Plus, Trash2, X, Upload } from "lucide-react";
import img2025120512405121 from "figma:asset/0fb7738e99e722ceb1abac61599257cef011512c.png";

type ThumbFlowStep = "zoom" | "upload" | "confirm";

export function UploadPanel() {
  const [selectedThumb, setSelectedThumb] = useState<number | null>(null);

  // Thumbnail flow: zoom → upload → confirm
  const [thumbFlow, setThumbFlow] = useState<{ index: number; step: ThumbFlowStep } | null>(null);
  const [thumbImages, setThumbImages] = useState<(string | null)[]>([null, null, null]);
  const [pendingImage, setPendingImage] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const getThumbSrc = (i: number) => thumbImages[i] || img2025120512405121;

  const handleThumbClick = (i: number) => {
    setThumbFlow({ index: i, step: "zoom" });
  };

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file && thumbFlow) {
      const reader = new FileReader();
      reader.onload = (ev) => {
        setPendingImage(ev.target?.result as string);
        setThumbFlow({ ...thumbFlow, step: "confirm" });
      };
      reader.readAsDataURL(file);
    }
  };

  const handleConfirm = () => {
    if (thumbFlow && pendingImage) {
      const newImages = [...thumbImages];
      newImages[thumbFlow.index] = pendingImage;
      setThumbImages(newImages);
      setPendingImage(null);
      setThumbFlow(null);
    }
  };

  const handleCloseFlow = () => {
    setThumbFlow(null);
    setPendingImage(null);
  };

  return (
    <div className="flex-1 min-w-0 bg-white rounded-2xl border-2 border-[rgba(178,171,171,0.18)] flex flex-col items-center justify-center p-8 gap-5">
      {/* Main preview */}
      <div className="w-full max-w-[320px] aspect-[305/431] rounded-lg border border-[#d0d5dd] overflow-hidden shadow-sm">
        <img
          src={selectedThumb !== null ? getThumbSrc(selectedThumb) : img2025120512405121}
          alt="采购订单预览"
          className="w-full h-full object-cover"
        />
      </div>

      {/* Thumbnails - Req 5: clicking opens zoom view */}
      <div className="flex items-center gap-4">
        {[0, 1, 2].map((i) => {
          const isSelected = selectedThumb === i;
          return (
            <button
              key={i}
              onClick={() => {
                setSelectedThumb(isSelected ? null : i);
                handleThumbClick(i);
              }}
              className={`group/thumb relative w-[72px] h-[100px] rounded-md overflow-hidden transition-all ${
                isSelected
                  ? "ring-2 ring-[#0a6ed1] shadow-md"
                  : "border border-dashed border-[#b8c2cc] hover:border-[#0a6ed1]/40"
              }`}
            >
              <img
                src={getThumbSrc(i)}
                alt=""
                className="w-full h-full object-cover"
              />
              {isSelected && (
                <div className="absolute inset-0 bg-black/25 flex items-center justify-center opacity-0 group-hover/thumb:opacity-100 transition-opacity">
                  <Trash2 className="w-5 h-5 text-white" />
                </div>
              )}
            </button>
          );
        })}
        {/* Req 4: Removed vector icon, simple dashed add button */}
        <button className="w-[72px] h-[100px] rounded-lg border-2 border-dashed border-[#d0d5dd] flex items-center justify-center hover:border-[#0a6ed1]/50 hover:bg-[#f8faff] transition-colors">
          <Plus className="w-6 h-6 text-[#98a2b3]" />
        </button>
      </div>

      {/* Tip */}
      <p className="text-[12px] text-[#667085]">
        温馨提示：普通用户只能上传三页文档！想要上传更多文档请开通{" "}
        <span className="text-[#0a6ed1] underline cursor-pointer hover:text-[#0858b0]">
          高级会员
        </span>
        。
      </p>

      {/* ── Thumbnail Flow Modal ── */}
      {thumbFlow && (
        <div className="fixed inset-0 z-50 flex items-center justify-center">
          <div className="absolute inset-0 bg-black/30 backdrop-blur-[2px]" onClick={handleCloseFlow} />
          <div className="relative z-10 bg-white rounded-2xl shadow-xl w-[480px] overflow-hidden">
            {/* Header */}
            <div className="flex items-center justify-between px-6 pt-6 pb-3">
              <div>
                <h2 className="text-[22px] text-[#101828]">
                  {thumbFlow.step === "zoom" ? "上传文件" : thumbFlow.step === "upload" ? "上传文件" : "上传文件"}
                </h2>
                <p className="text-[12px] text-[#344054] mt-1">每次最多可上传一个文件，单个文件大小上限为50 MB。</p>
              </div>
              <button onClick={handleCloseFlow} className="w-9 h-9 rounded-lg hover:bg-[#f2f4f7] flex items-center justify-center">
                <X className="w-5 h-5 text-[#344054]" />
              </button>
            </div>

            {/* Step: Zoom */}
            {thumbFlow.step === "zoom" && (
              <div className="px-6 pb-6 flex flex-col items-center gap-4">
                <div className="w-full max-w-[320px] aspect-[305/431] rounded-lg border border-[#d0d5dd] overflow-hidden bg-[#fafbfc]">
                  <img
                    src={getThumbSrc(thumbFlow.index)}
                    alt="放大预览"
                    className="w-full h-full object-contain"
                  />
                </div>
                <button
                  onClick={() => setThumbFlow({ ...thumbFlow, step: "upload" })}
                  className="w-full py-3 bg-[#0a6ed1] hover:bg-[#0858b0] text-white rounded-xl text-[15px] transition-colors"
                >
                  更换图片
                </button>
              </div>
            )}

            {/* Step: Upload (图四 style - no cloud icon per Req 4) */}
            {thumbFlow.step === "upload" && (
              <div className="px-6 pb-6">
                <div
                  onClick={() => fileInputRef.current?.click()}
                  className="h-[240px] border-2 border-dashed border-[#d0d5dd] rounded-lg flex flex-col items-center justify-center gap-3 cursor-pointer hover:border-[#0a6ed1]/50 hover:bg-[#f8faff] transition-colors"
                >
                  <div className="text-center">
                    <p className="text-[20px]">
                      <span className="text-[#0a6ed1]">点击上传</span>
                      <span className="text-[#475467]"> 或者拖拽到这里</span>
                    </p>
                    <p className="text-[12px] text-[#475467] mt-2">doc/pdf/jpg/xlsx (max. 800x400px)</p>
                  </div>
                </div>
                <input
                  ref={fileInputRef}
                  type="file"
                  accept="image/*,.pdf,.doc,.docx,.xlsx"
                  className="hidden"
                  onChange={handleFileSelect}
                />
              </div>
            )}

            {/* Step: Confirm (图五 style) */}
            {thumbFlow.step === "confirm" && pendingImage && (
              <div className="px-6 pb-6 flex flex-col items-center gap-6">
                <div className="w-[214px] h-[302px] rounded-md overflow-hidden border border-[#b8c2cc] relative">
                  <img src={pendingImage} alt="预览" className="w-full h-full object-cover" />
                  <div className="absolute inset-0 bg-black/10 rounded-md" />
                </div>
                <button
                  onClick={handleConfirm}
                  className="px-12 py-3 bg-[#0a6ed1] hover:bg-[#0858b0] text-white rounded-md text-[20px] transition-colors"
                >
                  确认
                </button>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
