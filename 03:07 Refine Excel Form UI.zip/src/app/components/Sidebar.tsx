import svgPaths from "../../imports/svg-4dhgyxt7jf";

export function Sidebar() {
  return (
    <aside className="w-[115px] bg-[#fdffff] border-r border-[#ebebeb] flex flex-col shrink-0">
      <div className="flex flex-col items-center justify-between p-6 h-full">
        {/* Top: Heart logo */}
        <div className="h-[102px] relative w-[67px] shrink-0">
          <svg
            className="block w-full h-full"
            fill="none"
            preserveAspectRatio="none"
            viewBox="0 0 67 102"
          >
            <path d={svgPaths.p45f1300} fill="#0A6ED1" />
            <path d="M0 78H67" stroke="#EBEBEB" />
          </svg>
        </div>

        {/* Middle: Nav icons */}
        <div className="flex flex-col gap-8 items-center">
          {/* 文档生成 - active */}
          <div className="bg-[#f5f9ff] flex flex-col gap-4 items-center justify-center p-2 rounded">
            <div className="relative w-[34px] h-[34px]">
              <svg
                className="block w-full h-full"
                fill="none"
                viewBox="0 0 31.7224 35.5"
                style={{ overflow: "visible" }}
              >
                <path
                  d={svgPaths.pcf6ec00}
                  stroke="#0A6ED1"
                  strokeLinecap="round"
                  strokeWidth="1.5"
                />
                <path
                  d={svgPaths.p102a6600}
                  stroke="#0A6ED1"
                  strokeLinecap="round"
                  strokeWidth="1.5"
                />
                <path
                  d={svgPaths.p21818b00}
                  stroke="#0A6ED1"
                  strokeLinecap="round"
                  strokeWidth="1.5"
                />
                <path
                  d={svgPaths.p20f87780}
                  stroke="#0A6ED1"
                  strokeLinecap="round"
                  strokeWidth="1.5"
                />
                <path
                  d={svgPaths.p37fe3be0}
                  stroke="#0A6ED1"
                  strokeLinecap="round"
                  strokeWidth="1.5"
                />
                <path
                  d={svgPaths.pdeca900}
                  stroke="#0A6ED1"
                  strokeLinecap="round"
                  strokeWidth="1.5"
                />
              </svg>
            </div>
            <p className="text-[#0a6ed1] text-[13px] text-center whitespace-nowrap italic">
              文档生成
            </p>
          </div>

          {/* 充值 */}
          <div className="group/recharge flex flex-col gap-4 items-center justify-center p-2 rounded hover:bg-[#f5f9ff] transition-all cursor-pointer">
            <div className="relative w-[34px] h-[34px]">
              <svg
                className="block w-full h-full"
                fill="none"
                viewBox="0 0 34.7502 33.75"
                style={{ overflow: "visible" }}
              >
                <path
                  d={svgPaths.p3a8d2e00}
                  className="stroke-[#475E75] group-hover/recharge:stroke-[#0A6ED1] transition-colors"
                  strokeLinecap="round"
                  strokeWidth="1.5"
                />
                <path
                  d={svgPaths.p13f53800}
                  className="stroke-[#475E75] group-hover/recharge:stroke-[#0A6ED1] transition-colors"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth="1.5"
                />
                <path
                  d={svgPaths.p3c579d00}
                  className="stroke-[#475E75] group-hover/recharge:stroke-[#0A6ED1] transition-colors"
                  strokeLinecap="round"
                  strokeWidth="1.5"
                />
                <ellipse cx="27.7501" cy="31.75" className="fill-[#475E75] group-hover/recharge:fill-[#0A6ED1] transition-colors" rx="2.00001" ry="1.99997" />
                <ellipse cx="11.7502" cy="31.75" className="fill-[#475E75] group-hover/recharge:fill-[#0A6ED1] transition-colors" rx="2.00001" ry="1.99997" />
              </svg>
            </div>
            <p className="text-[#475e75] group-hover/recharge:text-[#0a6ed1] text-[13px] text-center whitespace-nowrap italic transition-colors">充值</p>
          </div>
        </div>

        {/* Bottom: User avatar */}
        <div className="flex flex-col items-center gap-4">
          <div className="w-[34px] h-[34px] bg-[#0a6ed1] rounded-full flex items-center justify-center">
            <span className="text-white text-[20px]" style={{ fontFamily: "'DM Sans', sans-serif" }}>
              1
            </span>
          </div>
          <p className="text-[#202d35] text-[12px] whitespace-nowrap">133******3</p>
        </div>
      </div>
    </aside>
  );
}