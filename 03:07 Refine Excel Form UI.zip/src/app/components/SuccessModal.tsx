import { Check } from "lucide-react";

interface SuccessModalProps {
  onClose: () => void;
}

export function SuccessModal({ onClose }: SuccessModalProps) {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center">
      {/* Backdrop */}
      <div className="absolute inset-0 bg-black/20 backdrop-blur-[1px]" />

      {/* Modal */}
      <div className="relative z-10 bg-white rounded-2xl shadow-xl w-[400px] px-10 pt-10 pb-8 flex flex-col items-center">
        {/* Checkmark icon */}
        <div className="w-12 h-12 rounded-full bg-[#f0f7ff] flex items-center justify-center mb-5">
          <Check className="w-7 h-7 text-[#0a6ed1]" strokeWidth={2.5} />
        </div>

        <h2 className="text-[22px] text-[#101828] tracking-[-0.3px] mb-2">下载成功！</h2>
        <p className="text-[14px] text-[#667085] mb-8">请在本地查看文件。</p>

        <button
          onClick={onClose}
          className="px-10 py-2.5 bg-[#0a6ed1] hover:bg-[#0858b0] text-white rounded-xl text-[15px] transition-colors shadow-sm"
        >
          好的
        </button>
      </div>
    </div>
  );
}
