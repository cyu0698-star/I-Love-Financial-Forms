import { useState } from "react";
import { X, Download, Check } from "lucide-react";

interface FileOption {
  id: string;
  label: string;
  filename: string;
  size: string;
  bgColor: string;
  textColor: string;
}

const fileOptions: FileOption[] = [
  { id: "pdf", label: "PDF", filename: "AI生成的报价单.pdf", size: "2.4 MB", bgColor: "bg-[#fef3f2]", textColor: "text-[#d92d20]" },
  { id: "jpg", label: "JPG", filename: "AI生成的报价单.jpg", size: "0.4 MB", bgColor: "bg-[#eff8ff]", textColor: "text-[#0a6ed1]" },
  { id: "excel", label: "Excel", filename: "AI生成的报价单.xlsx", size: "1.2 MB", bgColor: "bg-[#ecfdf3]", textColor: "text-[#027a48]" },
  { id: "doc", label: "DOC", filename: "AI生成的报价单.docx", size: "1.8 MB", bgColor: "bg-[#f4f3ff]", textColor: "text-[#5925dc]" },
];

/* ── Mini Company Stamp for Preview ── */
function MiniStamp({ name }: { name: string }) {
  return (
    <div className="relative w-[38px] h-[38px]">
      <svg viewBox="0 0 120 120" className="w-full h-full" style={{ filter: "opacity(0.7)" }}>
        <circle cx="60" cy="60" r="56" fill="none" stroke="#c41e24" strokeWidth="3" />
        <circle cx="60" cy="60" r="50" fill="none" stroke="#c41e24" strokeWidth="1" />
        <polygon points="60,28 65.5,45 83,45 69,55.5 74,72 60,62 46,72 51,55.5 37,45 54.5,45" fill="#c41e24" />
        <defs><path id={`mini-stamp-${name}`} d="M 60, 60 m -40, 0 a 40,40 0 1,1 80,0 a 40,40 0 1,1 -80,0" /></defs>
        <text fill="#c41e24" fontSize="10" letterSpacing="2"><textPath href={`#mini-stamp-${name}`} startOffset="5%">{name}</textPath></text>
        <text x="60" y="92" textAnchor="middle" fill="#c41e24" fontSize="6" letterSpacing="0.5">印章</text>
      </svg>
    </div>
  );
}

interface DownloadModalProps {
  onClose: () => void;
  onDownload: () => void;
}

export function DownloadModal({ onClose, onDownload }: DownloadModalProps) {
  const [selectedFiles, setSelectedFiles] = useState<Set<string>>(new Set());
  const [hoveredFile, setHoveredFile] = useState<string | null>(null);

  const toggleFile = (fileId: string) => {
    setSelectedFiles((prev) => {
      const next = new Set(prev);
      if (next.has(fileId)) {
        next.delete(fileId);
      } else {
        next.add(fileId);
      }
      return next;
    });
  };

  const showPreview = hoveredFile !== null || selectedFiles.size > 0;
  const selectedCount = selectedFiles.size;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center">
      {/* Backdrop */}
      <div className="absolute inset-0 bg-black/30 backdrop-blur-[2px]" onClick={onClose} />

      {/* Fixed-position container: modal on top, preview below */}
      <div className="relative z-10 flex flex-col items-center gap-4" style={{ height: "auto", maxHeight: "92vh" }}>
        {/* Modal Card — fixed height */}
        <div className="bg-white rounded-2xl shadow-xl w-[520px] flex flex-col" style={{ height: "420px" }}>
          {/* Header */}
          <div className="flex items-center justify-between px-8 pt-6 pb-3 shrink-0">
            <h2 className="text-[22px] text-[#101828] tracking-[-0.3px]">下载文件</h2>
            <button onClick={onClose} className="w-8 h-8 rounded-lg hover:bg-[#f2f4f7] flex items-center justify-center transition-colors">
              <X className="w-5 h-5 text-[#667085]" />
            </button>
          </div>

          {/* File list — scrollable area fills middle */}
          <div className="flex-1 px-8 pb-3 overflow-auto min-h-0">
            <div className="border border-[#e5ecf5] rounded-xl overflow-hidden">
              {fileOptions.map((file, idx) => {
                const isSelected = selectedFiles.has(file.id);
                const isLast = idx === fileOptions.length - 1;
                return (
                  <button
                    key={file.id}
                    onClick={() => toggleFile(file.id)}
                    onMouseEnter={() => setHoveredFile(file.id)}
                    onMouseLeave={() => setHoveredFile(null)}
                    className={`w-full flex items-center gap-3 px-4 py-3 text-left transition-all ${
                      !isLast ? "border-b border-[#e5ecf5]" : ""
                    } ${
                      isSelected
                        ? "bg-[#f0f7ff] ring-2 ring-inset ring-[#0a6ed1]"
                        : "hover:bg-[#fafbfc]"
                    } ${isSelected && isLast ? "rounded-b-xl" : ""} ${isSelected && idx === 0 ? "rounded-t-xl" : ""}`}
                  >
                    {/* Checkbox indicator */}
                    <div className={`w-5 h-5 rounded border-2 flex items-center justify-center shrink-0 transition-colors ${
                      isSelected ? "bg-[#0a6ed1] border-[#0a6ed1]" : "border-[#d0d5dd] bg-white"
                    }`}>
                      {isSelected && <Check className="w-3 h-3 text-white" strokeWidth={3} />}
                    </div>
                    <div className={`w-9 h-9 rounded-lg ${file.bgColor} flex items-center justify-center shrink-0`}>
                      <span className={`text-[10px] ${file.textColor}`} style={{ fontFamily: "monospace" }}>{file.label}</span>
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-[13px] text-[#101828] truncate">{file.filename}</p>
                    </div>
                    <span className="text-[12px] text-[#0a6ed1] shrink-0">{file.size}</span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Download button — always at bottom */}
          <div className="px-8 pb-6 pt-2 shrink-0">
            <button
              onClick={onDownload}
              disabled={selectedCount === 0}
              className={`w-full py-3 rounded-xl text-[15px] flex items-center justify-center gap-2 transition-colors shadow-sm ${
                selectedCount > 0
                  ? "bg-[#0a6ed1] hover:bg-[#0858b0] text-white"
                  : "bg-[#e5ecf5] text-[#98a2b3] cursor-not-allowed"
              }`}
            >
              <Download className="w-4 h-4" />
              {selectedCount > 1 ? `下载 ${selectedCount} 个文件` : "下载文件"}
            </button>
          </div>
        </div>

        {/* Preview Card — with stamps (Req 4 & 7) */}
        {showPreview && (
          <div className="bg-white rounded-xl shadow-xl w-[520px] overflow-hidden border border-[#e5ecf5] shrink-0">
            <div className="p-5 text-center">
              <h4 className="text-[13px] text-[#101828] tracking-[1px]">惠州市罗丰实业有限公司</h4>
              <div className="text-[8px] text-[#667085] mt-1 leading-[14px]">
                <p>地址：广东省惠州市惠阳区秋长镇白石村大湖组88号</p>
                <p>电话：0752-3731609 传真：7160373 手机：13902477013</p>
              </div>
              <div className="mt-2 mb-2 flex items-center justify-center gap-2">
                <div className="h-px flex-1 bg-[#d0d5dd]" />
                <span className="text-[10px] text-[#1d2939] tracking-[4px]">送 货 单</span>
                <div className="h-px flex-1 bg-[#d0d5dd]" />
              </div>

              {/* Mini meta */}
              <div className="flex justify-between text-[8px] text-[#667085] px-2 mb-2">
                <div className="text-left space-y-0.5">
                  <p>客 户：保利(南宫)管乐制品(广州）有限公司</p>
                  <p>客户地址：广东省清远平丹原县义获镇登塔村</p>
                </div>
                <div className="text-right space-y-0.5">
                  <p>送货单号：LF202500003</p>
                  <p>电话：0580 0775 7699999</p>
                  <p>日期：2025年1月3日</p>
                </div>
              </div>

              {/* Mini table */}
              <table className="w-full text-[8px] border-collapse border border-[#d0d5dd]">
                <thead>
                  <tr className="bg-[#f8f9fb]">
                    {["序号", "订单号", "物料代码", "产品名称", "单位", "数量", "单价", "总额", "备注"].map((h) => (
                      <th key={h} className="border border-[#d0d5dd] px-1 py-1 text-[#344054]">{h}</th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td className="border border-[#d0d5dd] px-1 py-1 text-center">1</td>
                    <td className="border border-[#d0d5dd] px-1 py-1"></td>
                    <td className="border border-[#d0d5dd] px-1 py-1">9150072702</td>
                    <td className="border border-[#d0d5dd] px-1 py-1 text-left">管乐,拉杆柜组7 组合(包括：Eyba*25mm, Ty...)</td>
                    <td className="border border-[#d0d5dd] px-1 py-1 text-center">PC</td>
                    <td className="border border-[#d0d5dd] px-1 py-1 text-center">20</td>
                    <td className="border border-[#d0d5dd] px-1 py-1 text-center">/</td>
                    <td className="border border-[#d0d5dd] px-1 py-1 text-center">/</td>
                    <td className="border border-[#d0d5dd] px-1 py-1"></td>
                  </tr>
                  <tr>
                    <td className="border border-[#d0d5dd] px-1 py-1 text-center">2</td>
                    <td className="border border-[#d0d5dd] px-1 py-1">ZADM450061625</td>
                    <td className="border border-[#d0d5dd] px-1 py-1">9150060470</td>
                    <td className="border border-[#d0d5dd] px-1 py-1 text-left">管乐,拉杆柜组(批,M3.5.X28,B10&quot; 24 五金柜机...)</td>
                    <td className="border border-[#d0d5dd] px-1 py-1 text-center">PC</td>
                    <td className="border border-[#d0d5dd] px-1 py-1 text-center">20</td>
                    <td className="border border-[#d0d5dd] px-1 py-1 text-center">/</td>
                    <td className="border border-[#d0d5dd] px-1 py-1 text-center">/</td>
                    <td className="border border-[#d0d5dd] px-1 py-1"></td>
                  </tr>
                  <tr><td className="border border-[#d0d5dd] px-1 py-1 text-center">3</td><td className="border border-[#d0d5dd] px-1 py-1" colSpan={8}></td></tr>
                  <tr><td className="border border-[#d0d5dd] px-1 py-1 text-center">4</td><td className="border border-[#d0d5dd] px-1 py-1" colSpan={8}></td></tr>
                </tbody>
              </table>

              <div className="mt-3 text-left">
                <p className="text-[7px] text-[#98a2b3]">注：以上货品请核对清楚，如有问题请于收货后3日内通知。</p>
                {/* Stamps on preview document */}
                <div className="flex justify-between items-end mt-2">
                  <div className="flex flex-col items-start gap-0.5">
                    <p className="text-[7px] text-[#667085]">送货方签名盖章：</p>
                    <MiniStamp name="惠州市罗丰实业有限公司" />
                  </div>
                  <div className="flex flex-col items-end gap-0.5">
                    <p className="text-[7px] text-[#667085]">收货方签名盖章：</p>
                    <MiniStamp name="保利(南宫)管乐制品(广州)有限公司" />
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
