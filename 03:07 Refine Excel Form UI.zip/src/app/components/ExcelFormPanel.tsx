import { useState, useRef, useEffect, useCallback } from "react";
import { AlertTriangle, CheckCircle2, Pencil, Trash2, Plus, Minus, Upload } from "lucide-react";

interface CellData {
  value: string;
  aiDetected: boolean;
}

interface ColDef {
  key: string;
  label: string;
  width: string;
}

const defaultColumns: ColDef[] = [
  { key: "序号", label: "序号", width: "w-[38px]" },
  { key: "订单号", label: "订单号", width: "w-[96px]" },
  { key: "物料代码", label: "物料代码", width: "w-[78px]" },
  { key: "产品名称", label: "产品名称", width: "min-w-[130px] flex-1" },
  { key: "单位", label: "单位", width: "w-[36px]" },
  { key: "数量", label: "数量", width: "w-[42px]" },
  { key: "单价", label: "单价", width: "w-[42px]" },
  { key: "总额", label: "总额", width: "w-[62px]" },
  { key: "备注", label: "备注", width: "w-[36px]" },
];

const mk = (v: string, ai = false): CellData => ({ value: v, aiDetected: ai });

interface RowMap {
  [key: string]: CellData;
}

interface FullRow {
  id: number;
  isAiDetected: boolean;
  cells: RowMap;
}

let nextRowId = 5;

const initialRows: FullRow[] = [
  {
    id: 1,
    isAiDetected: true,
    cells: {
      序号: mk("1"),
      订单号: mk(""),
      物料代码: mk("9150072702", true),
      产品名称: mk("管乐, 拉杆柜组7 组合(包括：Eyba*25mm, Ty...)", true),
      单位: mk("PC", true),
      数量: mk("20", true),
      单价: mk("30.00", true),
      总额: mk("12500000", true),
      备注: mk(""),
    },
  },
  {
    id: 2,
    isAiDetected: true,
    cells: {
      序号: mk("2"),
      订单号: mk("ZADM450061625", true),
      物料代码: mk("9150060470", true),
      产品名称: mk("管乐, 拉杆柜组(批, M3.5.X28,B10\" 24 五金柜机...)", true),
      单位: mk("PC", true),
      数量: mk("20", true),
      单价: mk("8.80", true),
      总额: mk("13260.00", true),
      备注: mk(""),
    },
  },
  {
    id: 3,
    isAiDetected: false,
    cells: {
      序号: mk("3"), 订单号: mk(""), 物料代码: mk(""), 产品名称: mk(""),
      单位: mk(""), 数量: mk(""), 单价: mk(""), 总额: mk(""), 备注: mk(""),
    },
  },
  {
    id: 4,
    isAiDetected: false,
    cells: {
      序号: mk("4"), 订单号: mk(""), 物料代码: mk(""), 产品名称: mk(""),
      单位: mk(""), 数量: mk(""), 单价: mk(""), 总额: mk(""), 备注: mk(""),
    },
  },
];

interface MetaField { label: string; value: string; }

const initialMetaLeft: MetaField[] = [
  { label: "客  户", value: "保利(南宫)管乐制品(广州）有限公司" },
  { label: "客户地址", value: "广东省清远平丹原县义获镇登塔村" },
];

const initialMetaRight: MetaField[] = [
  { label: "送货单号", value: "LF202500003" },
  { label: "电  话", value: "0580 0775 7699999" },
  { label: "日  期", value: "2025年1月3日" },
];

/* ── Inline Editable Field ── */
function InlineEditField({ label, value, onChange }: { label: string; value: string; onChange: (v: string) => void }) {
  const [editing, setEditing] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);
  useEffect(() => { if (editing && inputRef.current) { inputRef.current.focus(); inputRef.current.select(); } }, [editing]);
  const commit = useCallback(() => setEditing(false), []);

  return (
    <div className="flex items-baseline gap-1 leading-[22px]">
      <span className="text-[#6b7b8d] shrink-0 whitespace-pre">{label}：</span>
      {editing ? (
        <input ref={inputRef} className="flex-1 min-w-0 bg-white border border-[#0a6ed1] rounded px-1.5 py-0.5 text-[12px] text-[#101828] outline-none shadow-[0_0_0_2px_rgba(10,110,209,0.12)]"
          value={value} onChange={(e) => onChange(e.target.value)} onBlur={commit} onKeyDown={(e) => e.key === "Enter" && commit()} />
      ) : (
        <span onClick={() => setEditing(true)} className="text-[#1d2939] cursor-text rounded px-1.5 py-0.5 -mx-1 transition-colors hover:bg-[#eef4ff] group/meta inline-flex items-center gap-1">
          {value}
          <Pencil className="w-2.5 h-2.5 text-[#0a6ed1] opacity-0 group-hover/meta:opacity-100 transition-opacity inline-block shrink-0" />
        </span>
      )}
    </div>
  );
}

/* ── Editable Table Cell ── */
function EditableCell({ cell, onChange, isIndex, showDeleteRow, onDeleteRow }: {
  cell: CellData; onChange: (val: string) => void; isIndex?: boolean;
  showDeleteRow?: boolean; onDeleteRow?: () => void;
}) {
  const [editing, setEditing] = useState(false);

  if (editing) {
    return (
      <input autoFocus className="w-full bg-white border border-[#0a6ed1] rounded px-1.5 py-0.5 text-[11px] text-[#101828] outline-none shadow-[0_0_0_2px_rgba(10,110,209,0.15)]"
        value={cell.value} onChange={(e) => onChange(e.target.value)} onBlur={() => setEditing(false)} onKeyDown={(e) => e.key === "Enter" && setEditing(false)} />
    );
  }

  // Req 1: Only show blue bg if aiDetected AND not yet edited (value unchanged)
  const hasAiBg = cell.aiDetected && cell.value;
  const bgClass = hasAiBg ? "bg-[#eef4ff] hover:bg-[#dceaff]" : "bg-transparent hover:bg-[#f5f6f8]";

  // If this cell should show delete row button
  if (showDeleteRow) {
    return (
      <button
        onClick={onDeleteRow}
        className="w-full flex items-center justify-center min-h-[24px] opacity-0 group-hover/row:opacity-100 transition-opacity"
        title="减少行"
      >
        <Minus className="w-3.5 h-3.5 text-[#d92d20]" />
      </button>
    );
  }

  if (isIndex) {
    return (
      <button onClick={() => setEditing(true)} className={`w-full text-center ${bgClass} rounded px-1 py-1 text-[11px] text-[#98a2b3] transition-colors cursor-text min-h-[24px]`}>
        {cell.value}
      </button>
    );
  }

  return (
    <button onClick={() => setEditing(true)} className={`group/cell w-full text-left ${bgClass} rounded px-1.5 py-1 text-[11px] text-[#101828] transition-colors cursor-text flex items-center gap-1 min-h-[24px]`}>
      <span className="truncate flex-1">{cell.value || "\u00A0"}</span>
      <Pencil className="w-2.5 h-2.5 text-[#0a6ed1] opacity-0 group-hover/cell:opacity-100 transition-opacity shrink-0" />
    </button>
  );
}

/* ── Red Company Stamp ── */
function CompanyStamp({ companyName, customImage, onClick }: { companyName: string; customImage?: string | null; onClick?: () => void }) {
  return (
    <div className="relative w-[72px] h-[72px] cursor-pointer group/stamp" onClick={onClick} title="点击更换印章">
      {customImage ? (
        <img src={customImage} alt={companyName} className="w-full h-full object-contain rounded" />
      ) : (
        <svg viewBox="0 0 120 120" className="w-full h-full" style={{ filter: "opacity(0.75)" }}>
          <circle cx="60" cy="60" r="56" fill="none" stroke="#c41e24" strokeWidth="3" />
          <circle cx="60" cy="60" r="50" fill="none" stroke="#c41e24" strokeWidth="1" />
          <polygon points="60,28 65.5,45 83,45 69,55.5 74,72 60,62 46,72 51,55.5 37,45 54.5,45" fill="#c41e24" />
          <defs><path id={`stamp-path-${companyName}`} d="M 60, 60 m -40, 0 a 40,40 0 1,1 80,0 a 40,40 0 1,1 -80,0" /></defs>
          <text fill="#c41e24" fontSize="10" letterSpacing="2"><textPath href={`#stamp-path-${companyName}`} startOffset="5%">{companyName}</textPath></text>
          <text x="60" y="92" textAnchor="middle" fill="#c41e24" fontSize="6" letterSpacing="0.5">印章</text>
        </svg>
      )}
      {/* Hover overlay */}
      <div className="absolute inset-0 bg-black/20 rounded flex items-center justify-center opacity-0 group-hover/stamp:opacity-100 transition-opacity">
        <Upload className="w-4 h-4 text-white" />
      </div>
    </div>
  );
}

/* ── Stamp Upload Flow Modal ── */
type StampFlowStep = "preview" | "upload" | "confirm";

function StampUploadFlow({ stampName, currentImage, onClose, onReplace }: {
  stampName: string; currentImage?: string | null; onClose: () => void; onReplace: (img: string) => void;
}) {
  const [flowStep, setFlowStep] = useState<StampFlowStep>("preview");
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [previewImg, setPreviewImg] = useState<string | null>(null);

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (ev) => {
        setPreviewImg(ev.target?.result as string);
        setFlowStep("confirm");
      };
      reader.readAsDataURL(file);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center">
      <div className="absolute inset-0 bg-black/30 backdrop-blur-[2px]" onClick={onClose} />
      <div className="relative z-10 bg-white rounded-2xl shadow-xl w-[480px] overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between px-6 pt-6 pb-3">
          <h2 className="text-[22px] text-[#101828]">
            {flowStep === "preview" ? "查看印章" : flowStep === "upload" ? "上传文件" : "确认更换"}
          </h2>
          <button onClick={onClose} className="w-8 h-8 rounded-lg hover:bg-[#f2f4f7] flex items-center justify-center">
            <span className="text-[#667085] text-xl leading-none">×</span>
          </button>
        </div>

        {flowStep === "preview" && (
          <div className="px-6 pb-6">
            <p className="text-[12px] text-[#344054] mb-4">{stampName}</p>
            <div className="flex items-center justify-center p-8 bg-[#fafbfc] rounded-lg border border-[#e5ecf5] mb-6">
              <div className="w-[120px] h-[120px]">
                {currentImage ? (
                  <img src={currentImage} alt={stampName} className="w-full h-full object-contain" />
                ) : (
                  <svg viewBox="0 0 120 120" className="w-full h-full" style={{ filter: "opacity(0.75)" }}>
                    <circle cx="60" cy="60" r="56" fill="none" stroke="#c41e24" strokeWidth="3" />
                    <circle cx="60" cy="60" r="50" fill="none" stroke="#c41e24" strokeWidth="1" />
                    <polygon points="60,28 65.5,45 83,45 69,55.5 74,72 60,62 46,72 51,55.5 37,45 54.5,45" fill="#c41e24" />
                    <defs><path id={`preview-stamp-${stampName}`} d="M 60, 60 m -40, 0 a 40,40 0 1,1 80,0 a 40,40 0 1,1 -80,0" /></defs>
                    <text fill="#c41e24" fontSize="10" letterSpacing="2"><textPath href={`#preview-stamp-${stampName}`} startOffset="5%">{stampName}</textPath></text>
                    <text x="60" y="92" textAnchor="middle" fill="#c41e24" fontSize="6" letterSpacing="0.5">印章</text>
                  </svg>
                )}
              </div>
            </div>
            <button
              onClick={() => setFlowStep("upload")}
              className="w-full py-3 bg-[#0a6ed1] hover:bg-[#0858b0] text-white rounded-xl text-[15px] transition-colors"
            >
              更换印章
            </button>
          </div>
        )}

        {flowStep === "upload" && (
          <div className="px-6 pb-6">
            <p className="text-[12px] text-[#344054] mb-4">每次最多可上传一个文件，单个文件大小上限为50 MB。</p>
            <div
              onClick={() => fileInputRef.current?.click()}
              className="h-[200px] border-2 border-dashed border-[#d0d5dd] rounded-lg flex flex-col items-center justify-center gap-3 cursor-pointer hover:border-[#0a6ed1]/50 hover:bg-[#f8faff] transition-colors"
            >
              <div className="w-10 h-10 rounded-lg border border-[#eaecf0] flex items-center justify-center">
                <Upload className="w-5 h-5 text-[#344054]" />
              </div>
              <div className="text-center">
                <p className="text-[14px]">
                  <span className="text-[#0a6ed1]">点击上传</span>
                  <span className="text-[#475467]"> 或者拖拽到这里</span>
                </p>
                <p className="text-[12px] text-[#475467] mt-1">doc/pdf/jpg/xlsx (max. 800x400px)</p>
              </div>
            </div>
            <input
              ref={fileInputRef}
              type="file"
              accept="image/*"
              className="hidden"
              onChange={handleFileSelect}
            />
          </div>
        )}

        {flowStep === "confirm" && previewImg && (
          <div className="px-6 pb-6 flex flex-col items-center gap-6">
            <div className="w-[214px] h-[302px] rounded-lg overflow-hidden border border-[#b8c2cc] relative">
              <img src={previewImg} alt="新印章预览" className="w-full h-full object-cover" />
              <div className="absolute inset-0 bg-black/10 rounded-lg" />
            </div>
            <button
              onClick={() => { onReplace(previewImg); onClose(); }}
              className="px-12 py-3 bg-[#0a6ed1] hover:bg-[#0858b0] text-white rounded-md text-[20px] transition-colors"
            >
              确认
            </button>
          </div>
        )}
      </div>
    </div>
  );
}

/* ── Props ── */
interface ExcelFormPanelProps {
  hasChanges: boolean;
  onChangeDetected: () => void;
  onReset?: () => void;
}

/* ── Main Component ── */
export function ExcelFormPanel({ hasChanges, onChangeDetected, onReset }: ExcelFormPanelProps) {
  const [rows, setRows] = useState<FullRow[]>(initialRows);
  const [columns, setColumns] = useState<ColDef[]>(defaultColumns);
  const [metaLeft, setMetaLeft] = useState(initialMetaLeft);
  const [metaRight, setMetaRight] = useState(initialMetaRight);

  // Stamp images
  const [senderStamp, setSenderStamp] = useState<string | null>(null);
  const [receiverStamp, setReceiverStamp] = useState<string | null>(null);
  const [stampFlow, setStampFlow] = useState<{ side: "sender" | "receiver" } | null>(null);

  // Hover tracking for row/column delete
  const [hoveredRowIdx, setHoveredRowIdx] = useState<number | null>(null);
  const [hoveredColKey, setHoveredColKey] = useState<string | null>(null);

  // Req 1: After editing, set aiDetected to false so bg turns white
  const updateCell = (rowIdx: number, colKey: string, value: string) => {
    setRows((prev) => {
      const next = [...prev];
      const row = { ...next[rowIdx], cells: { ...next[rowIdx].cells } };
      row.cells[colKey] = { value, aiDetected: false };
      next[rowIdx] = row;
      return next;
    });
    onChangeDetected();
  };

  const updateMeta = (side: "left" | "right", idx: number, value: string) => {
    const setter = side === "left" ? setMetaLeft : setMetaRight;
    setter((prev) => { const next = [...prev]; next[idx] = { ...next[idx], value }; return next; });
    onChangeDetected();
  };

  const handleReset = () => {
    if (onReset) {
      onReset();
    }
  };

  const addRow = () => {
    const newRow: FullRow = { id: nextRowId++, isAiDetected: false, cells: {} };
    columns.forEach((c) => { newRow.cells[c.key] = mk(c.key === "序号" ? String(rows.length + 1) : ""); });
    setRows((prev) => [...prev, newRow]);
    onChangeDetected();
  };

  const isRowEmpty = (row: FullRow) => {
    const dataKeys = columns.filter((c) => c.key !== "序号").map((c) => c.key);
    return dataKeys.every((k) => !(row.cells[k]?.value?.trim()));
  };

  const deleteRow = (rowIdx: number) => {
    setRows((prev) => {
      const next = prev.filter((_, i) => i !== rowIdx);
      return next.map((r, i) => ({ ...r, cells: { ...r.cells, 序号: mk(String(i + 1)) } }));
    });
    onChangeDetected();
  };

  const isColumnRemovable = (colKey: string) => {
    const isDefault = defaultColumns.some((c) => c.key === colKey);
    if (isDefault) return false;
    return rows.every((r) => !(r.cells[colKey]?.value?.trim()));
  };

  const deleteColumn = (colKey: string) => {
    setColumns((prev) => prev.filter((c) => c.key !== colKey));
    setRows((prev) => prev.map((r) => {
      const newCells = { ...r.cells };
      delete newCells[colKey];
      return { ...r, cells: newCells };
    }));
    onChangeDetected();
  };

  const [showColInput, setShowColInput] = useState(false);
  const [newColName, setNewColName] = useState("");
  const colInputRef = useRef<HTMLInputElement>(null);
  useEffect(() => { if (showColInput && colInputRef.current) colInputRef.current.focus(); }, [showColInput]);

  const confirmAddColumn = () => {
    const name = newColName.trim();
    if (!name || columns.some((c) => c.key === name)) { setShowColInput(false); setNewColName(""); return; }
    setColumns((prev) => [...prev, { key: name, label: name, width: "w-[52px]" }]);
    setRows((prev) => prev.map((r) => ({ ...r, cells: { ...r.cells, [name]: mk("") } })));
    setNewColName(""); setShowColInput(false); onChangeDetected();
  };

  const parseNum = (v: string) => { const n = parseFloat(v); return isNaN(n) ? 0 : n; };
  const aiRows = rows.filter((r) => r.isAiDetected);
  const totalUnits = aiRows.reduce((acc, r) => { const u = r.cells["单位"]?.value || ""; if (u && !acc.includes(u)) acc.push(u); return acc; }, [] as string[]);
  const totalQty = aiRows.reduce((acc, r) => acc + parseNum(r.cells["数量"]?.value || ""), 0);
  const totalPrice = aiRows.reduce((acc, r) => acc + parseNum(r.cells["单价"]?.value || ""), 0);
  const totalAmount = aiRows.reduce((acc, r) => acc + parseNum(r.cells["总额"]?.value || ""), 0);
  const totalRemarks = aiRows.filter((r) => (r.cells["备注"]?.value || "").trim()).length;

  const headerTitle = hasChanges ? "修改表单信息已完成！请核对" : "核对有误！修改表单信息并核对";

  return (
    <div className="w-[540px] shrink-0 bg-white rounded-2xl border border-[#e5ecf5] flex flex-col overflow-hidden shadow-sm">
      {/* ── Header ── */}
      <div className="px-6 pt-5 pb-4 border-b border-[#f0f2f5]">
        <div className="flex items-start justify-between gap-3">
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2 mb-1.5">
              <div className="w-1 h-5 bg-[#0a6ed1] rounded-full shrink-0" />
              <h3 className="text-[#101828] text-[17px] tracking-[-0.2px]">{headerTitle}</h3>
            </div>
            <p className="text-[12px] text-[#667085] ml-3 leading-relaxed">
              点击蓝色空格修改信息，确认无误后便可下载文件。
            </p>
          </div>
          {/* Req 6: Trash icon triggers onReset to go back to template view */}
          <button onClick={handleReset} className="w-10 h-10 rounded-xl bg-[#f0f7ff] hover:bg-[#e0efff] flex items-center justify-center transition-colors shrink-0 group" title="重置">
            <Trash2 className="w-[18px] h-[18px] text-[#0a6ed1] group-hover:scale-110 transition-transform" />
          </button>
        </div>

        {/* Status indicator */}
        <div className="flex items-center gap-1.5 mt-3 ml-3">
          {hasChanges ? (
            <>
              <div className="w-2 h-2 rounded-full bg-[#0a6ed1] shrink-0" />
              <span className="text-[11px]">
                <span className="text-[#0a6ed1] bg-[#eef4ff] rounded px-1 py-px">蓝色区域</span>
                <span className="text-[#0a6ed1]"> 已修改 </span>
                <span className="text-[#667085]">并核对</span>
              </span>
            </>
          ) : (
            <>
              <AlertTriangle className="w-3.5 h-3.5 text-[#f59e0b] shrink-0" />
              <span className="text-[11px]">
                <span className="text-[#0a6ed1] bg-[#eef4ff] rounded px-1 py-px">蓝色区域</span>
                <span className="text-[#d97706]"> 待修改 </span>
                <span className="text-[#667085]">并核对</span>
              </span>
            </>
          )}
        </div>
      </div>

      {/* ── Document Content ── */}
      <div className="flex-1 overflow-auto px-4 py-4">
        <div className="bg-white rounded-xl border border-[#e5ecf5] overflow-hidden shadow-[0_1px_3px_rgba(0,0,0,0.04)]">
          {/* Company Header */}
          <div className="px-6 pt-5 pb-3 text-center border-b border-[#d0d5dd]">
            <h4 className="text-[18px] text-[#101828] tracking-[2px]">惠州市罗丰实业有限公司</h4>
            <div className="text-[11px] text-[#667085] mt-2 leading-[20px] space-y-0.5">
              <p>地址：广东省惠州市惠阳区秋长镇白石村大湖组88号</p>
              <p>电话：0752-3731609　传真：7160373　手机：13902477013</p>
            </div>
            <div className="mt-3 mb-1 flex items-center justify-center gap-3">
              <div className="h-px flex-1 bg-[#d0d5dd]" />
              <span className="text-[15px] text-[#1d2939] tracking-[8px] px-1">送 货 单</span>
              <div className="h-px flex-1 bg-[#d0d5dd]" />
            </div>
          </div>

          {/* Meta Info */}
          <div className="px-5 py-3 border-b border-[#e5ecf5]">
            <div className="flex justify-between text-[12px] text-[#667085] gap-6">
              <div className="space-y-1 flex-1">
                {metaLeft.map((m, i) => <InlineEditField key={m.label} label={m.label} value={m.value} onChange={(v) => updateMeta("left", i, v)} />)}
              </div>
              <div className="space-y-1 shrink-0">
                {metaRight.map((m, i) => <InlineEditField key={m.label} label={m.label} value={m.value} onChange={(v) => updateMeta("right", i, v)} />)}
              </div>
            </div>
          </div>

          {/* Table */}
          <div className="overflow-x-auto">
            <table className="w-full text-[11px] border-collapse">
              <thead>
                <tr className="border-b border-[#d0d5dd] bg-[#fafbfc]">
                  {columns.map((col) => {
                    const removable = isColumnRemovable(col.key);
                    const isColHovered = hoveredColKey === col.key;
                    return (
                      <th
                        key={col.key}
                        className={`${col.width} px-2 py-2.5 text-[#344054] text-center whitespace-nowrap border-r border-[#e5ecf5] last:border-r-0`}
                        onMouseEnter={() => removable && setHoveredColKey(col.key)}
                        onMouseLeave={() => setHoveredColKey(null)}
                      >
                        {removable && isColHovered ? (
                          <button
                            onClick={(e) => { e.stopPropagation(); deleteColumn(col.key); }}
                            className="inline-flex items-center gap-0.5 text-[10px] text-[#d92d20] hover:text-[#b42318] transition-colors"
                            title="减少列"
                          >
                            <Minus className="w-3 h-3" />
                            <span>减少列</span>
                          </button>
                        ) : (
                          col.label
                        )}
                      </th>
                    );
                  })}
                  <th className="w-[30px] px-0 py-2.5 border-l border-[#e5ecf5]">
                    {showColInput ? (
                      <div className="flex flex-col items-center gap-0.5 px-1">
                        <input ref={colInputRef} className="w-[44px] border border-[#0a6ed1] rounded px-1 py-0.5 text-[10px] text-[#101828] outline-none"
                          value={newColName} onChange={(e) => setNewColName(e.target.value)} placeholder="列名" onBlur={confirmAddColumn}
                          onKeyDown={(e) => { if (e.key === "Enter") confirmAddColumn(); if (e.key === "Escape") { setShowColInput(false); setNewColName(""); } }} />
                      </div>
                    ) : (
                      <button onClick={() => setShowColInput(true)} className="w-5 h-5 mx-auto rounded bg-[#f0f7ff] hover:bg-[#dceaff] flex items-center justify-center transition-colors" title="新增列">
                        <Plus className="w-3 h-3 text-[#0a6ed1]" />
                      </button>
                    )}
                  </th>
                </tr>
              </thead>
              <tbody>
                {rows.map((row, rowIdx) => {
                  const rowEmpty = isRowEmpty(row) && !row.isAiDetected;
                  const isRowHovered = hoveredRowIdx === rowIdx;
                  return (
                    <tr
                      key={row.id}
                      className={`border-b border-[#e5ecf5] transition-colors group/row ${row.isAiDetected ? "hover:bg-[#f8fbff]" : "hover:bg-[#fafbfd]"}`}
                      onMouseEnter={() => rowEmpty && setHoveredRowIdx(rowIdx)}
                      onMouseLeave={() => setHoveredRowIdx(null)}
                    >
                      {columns.map((col) => {
                        const cell = row.cells[col.key] || mk("");
                        const isIndex = col.key === "序号";
                        const removableCol = isColumnRemovable(col.key);
                        const showColDelete = removableCol && hoveredColKey === col.key;

                        // Req 3: Empty row hover → every cell shows minus button
                        if (rowEmpty && isRowHovered) {
                          return (
                            <td key={col.key} className={`px-1 py-1 border-r border-[#e5ecf5] last:border-r-0`}>
                              <button
                                onClick={() => deleteRow(rowIdx)}
                                className="w-full flex items-center justify-center min-h-[24px] transition-opacity"
                                title="减少行"
                              >
                                <Minus className="w-3.5 h-3.5 text-[#d92d20]" />
                              </button>
                            </td>
                          );
                        }

                        // Req 3: Removable column hover → every cell in that column shows minus
                        if (showColDelete) {
                          return (
                            <td key={col.key} className={`px-1 py-1 border-r border-[#e5ecf5] last:border-r-0`}>
                              <button
                                onClick={() => deleteColumn(col.key)}
                                className="w-full flex items-center justify-center min-h-[24px] transition-opacity"
                                title="减少列"
                              >
                                <Minus className="w-3.5 h-3.5 text-[#d92d20]" />
                              </button>
                            </td>
                          );
                        }

                        return (
                          <td key={col.key} className={`px-1 py-1 border-r border-[#e5ecf5] last:border-r-0 ${isIndex ? "text-center" : ""}`}>
                            <EditableCell cell={cell} isIndex={isIndex} onChange={(val) => updateCell(rowIdx, col.key, val)} />
                          </td>
                        );
                      })}
                      <td className="border-l border-[#e5ecf5] w-[30px]" />
                    </tr>
                  );
                })}
              </tbody>
            </table>
            <button onClick={addRow} className="w-full py-2 flex items-center justify-center gap-1.5 text-[11px] text-[#0a6ed1] hover:bg-[#f0f7ff] transition-colors border-b border-[#e5ecf5]">
              <Plus className="w-3.5 h-3.5" />新增行
            </button>
          </div>

          {/* Footer */}
          <div className="px-5 py-3 border-t border-[#d0d5dd]">
            <p className="text-[11px] text-[#6b7b8d] leading-[20px]">注：以上货品请核对清楚，如有问题请于收货后3日内通知。</p>
            {/* Req 2: Clickable stamps */}
            <div className="flex justify-between items-end mt-4 mb-2">
              <div className="flex flex-col items-start gap-1">
                <p className="text-[11px] text-[#344054]">送货方签名盖章：</p>
                <CompanyStamp
                  companyName="惠州市罗丰实业有限公司"
                  customImage={senderStamp}
                  onClick={() => setStampFlow({ side: "sender" })}
                />
              </div>
              <div className="flex flex-col items-end gap-1">
                <p className="text-[11px] text-[#344054]">收货方签名盖章：</p>
                <CompanyStamp
                  companyName="保利(南宫)管乐制品(广州)有限公司"
                  customImage={receiverStamp}
                  onClick={() => setStampFlow({ side: "receiver" })}
                />
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* ── Action Bar ── */}
      <div className="px-5 py-3 border-t border-[#f0f2f5] bg-[#fafbfc]">
        <div className="flex items-center gap-2 text-[12px] mb-2">
          <CheckCircle2 className="w-4 h-4 text-[#12b76a] shrink-0" />
          <span className="text-[#344054]">AI 已识别 <span className="text-[#0a6ed1]">{aiRows.length}</span> 项产品</span>
        </div>
        <div className="flex items-center bg-gradient-to-r from-[#f0f7ff] to-[#e8f1fc] rounded-lg px-3 py-2 text-[11px] border border-[#d0e2f7]">
          <span className="text-[#0a6ed1] shrink-0 mr-3">合计</span>
          <div className="flex-1 flex items-center justify-between gap-1 min-w-0">
            <span className="text-[#667085]">—</span>
            <span className="text-[#344054]">{aiRows.length} 项产品</span>
            <span className="text-[#344054]">{totalUnits.join("/") || "—"}</span>
            <span className="text-[#0a6ed1]">{totalQty || "—"}</span>
            <span className="text-[#344054]">{totalPrice ? totalPrice.toFixed(2) : "—"}</span>
            <span className="text-[#0a6ed1]">{totalAmount ? totalAmount.toFixed(2) : "—"}</span>
            <span className="text-[#667085]">{totalRemarks || "—"}</span>
          </div>
        </div>
      </div>

      {/* Stamp Upload Flow Modal */}
      {stampFlow && (
        <StampUploadFlow
          stampName={stampFlow.side === "sender" ? "惠州市罗丰实业有限公司" : "保利(南宫)管乐制品(广州)有限公司"}
          currentImage={stampFlow.side === "sender" ? senderStamp : receiverStamp}
          onClose={() => setStampFlow(null)}
          onReplace={(img) => {
            if (stampFlow.side === "sender") setSenderStamp(img);
            else setReceiverStamp(img);
            onChangeDetected();
          }}
        />
      )}
    </div>
  );
}
