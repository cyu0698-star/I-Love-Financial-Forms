import { useState } from "react";
import { FolderOpen, FilePlus } from "lucide-react";
import img2025120512405121 from "figma:asset/0fb7738e99e722ceb1abac61599257cef011512c.png";

interface TemplateSelectionViewProps {
  onSelectTemplate: () => void;
}

const salesTemplates = [
  { label: "送货单", icon: FolderOpen },
  { label: "对账单", icon: FolderOpen },
  { label: "采购单", icon: FolderOpen },
  { label: "上传新模版", icon: FilePlus },
];

const financeTemplates = [
  { label: "流水对账", icon: FolderOpen },
  { label: "支付清单", icon: FolderOpen },
];

export function TemplateSelectionView({ onSelectTemplate }: TemplateSelectionViewProps) {
  const [selectedTemplate, setSelectedTemplate] = useState<string | null>(null);

  return (
    <div className="flex-1 px-8 pb-4 flex gap-5 min-h-0 overflow-hidden">
      {/* Left: Document Preview */}
      <div className="flex-1 min-w-0 bg-white rounded-2xl border-2 border-[rgba(178,171,171,0.18)] flex flex-col items-center justify-center p-8 gap-5">
        <div className="w-full max-w-[320px] aspect-[305/431] rounded-lg border border-[#d0d5dd] overflow-hidden shadow-sm">
          <img src={img2025120512405121} alt="文档预览" className="w-full h-full object-cover" />
        </div>
        <div className="flex items-center gap-4">
          {[0, 1].map((i) => (
            <div key={i} className="w-[72px] h-[100px] rounded-md overflow-hidden border border-dashed border-[#b8c2cc]">
              <img src={img2025120512405121} alt="" className="w-full h-full object-cover" />
            </div>
          ))}
          <div className="w-[72px] h-[100px] rounded-lg border-2 border-dashed border-[#d0d5dd] flex items-center justify-center">
            <span className="text-[24px] text-[#98a2b3]">+</span>
          </div>
        </div>
        <p className="text-[12px] text-[#667085]">
          温馨提示：普通用户只能上传三页文档！想要上传更多文档请开通{" "}
          <span className="text-[#0a6ed1] underline cursor-pointer">高级会员</span>。
        </p>
      </div>

      {/* Right: Template Selection */}
      <div className="w-[540px] shrink-0 bg-white rounded-2xl border border-[#e5ecf5] flex flex-col overflow-hidden shadow-sm p-8">
        <h3 className="text-[22px] text-[#101828] mb-1">模版选择</h3>
        <p className="text-[12px] text-[#344054] mb-6">每次最多可上传一个文件，单个文件大小上限为50 MB。</p>

        {/* 销售业务 */}
        <h4 className="text-[18px] text-[#101828] mb-4">销售业务</h4>
        <div className="grid grid-cols-2 gap-3 mb-6">
          {salesTemplates.map((t) => {
            const isSelected = selectedTemplate === t.label;
            const Icon = t.icon;
            return (
              <button
                key={t.label}
                onClick={() => setSelectedTemplate(t.label)}
                className={`flex items-center gap-3 px-5 py-4 rounded-xl border transition-colors text-left ${
                  isSelected
                    ? "border-[#0a6ed1] bg-[#f0f7ff]"
                    : "border-[#e5ecf5] hover:bg-[#fafbfc]"
                }`}
              >
                <Icon className="w-5 h-5 text-[#667085] shrink-0" />
                <span className="text-[15px] text-[#101828]">{t.label}</span>
              </button>
            );
          })}
        </div>

        {/* 财务业务 */}
        <h4 className="text-[18px] text-[#101828] mb-4">财务业务</h4>
        <div className="grid grid-cols-2 gap-3 mb-6">
          {financeTemplates.map((t) => {
            const isSelected = selectedTemplate === t.label;
            const Icon = t.icon;
            return (
              <button
                key={t.label}
                onClick={() => setSelectedTemplate(t.label)}
                className={`flex items-center gap-3 px-5 py-4 rounded-xl border transition-colors text-left ${
                  isSelected
                    ? "border-[#0a6ed1] bg-[#f0f7ff]"
                    : "border-[#e5ecf5] hover:bg-[#fafbfc]"
                }`}
              >
                <Icon className="w-5 h-5 text-[#667085] shrink-0" />
                <span className="text-[15px] text-[#101828]">{t.label}</span>
              </button>
            );
          })}
        </div>

        {/* Upload new template */}
        <button className="flex items-center gap-3 px-5 py-4 rounded-xl border border-[#e5ecf5] hover:bg-[#fafbfc] transition-colors text-left w-fit">
          <FilePlus className="w-5 h-5 text-[#667085]" />
          <span className="text-[15px] text-[#101828]">上传新模版</span>
        </button>
      </div>
    </div>
  );
}
