import { useState } from "react";
import { ArrowLeft, Download, Sparkles } from "lucide-react";
import { Sidebar } from "./components/Sidebar";
import { UploadPanel } from "./components/UploadPanel";
import { ExcelFormPanel } from "./components/ExcelFormPanel";
import { DownloadModal } from "./components/DownloadModal";
import { SuccessModal } from "./components/SuccessModal";
import { TemplateSelectionView } from "./components/TemplateSelectionView";

/*
  App states:
  "templateSelection" – Template selection view (图九), shown after trash icon reset
  "reviewing"         – Initial form, warning state, button disabled
  "confirmed"         – After editing cells, header changes, button enabled
  "downloadModal"     – Download modal
  "success"           – Download success modal
*/

type AppView = "templateSelection" | "reviewing" | "confirmed" | "downloadModal" | "success";

export default function App() {
  const [view, setView] = useState<AppView>("reviewing");

  const hasChanges = view !== "reviewing" && view !== "templateSelection";

  const handleChangeDetected = () => {
    if (view === "reviewing") {
      setView("confirmed");
    }
  };

  const handleDownloadClick = () => {
    if (view === "confirmed") {
      setView("downloadModal");
    }
  };

  const handleModalClose = () => {
    setView("confirmed");
  };

  const handleDownload = () => {
    setView("success");
  };

  const handleSuccessClose = () => {
    setView("reviewing");
  };

  // Req 6: Trash icon → go back to template selection view
  const handleReset = () => {
    setView("templateSelection");
  };

  // Template selected → go to reviewing
  const handleTemplateSelected = () => {
    setView("reviewing");
  };

  const isButtonActive = view === "confirmed";
  const isTemplateView = view === "templateSelection";

  return (
    <div className="h-screen w-full flex bg-[#f2f4f7] overflow-hidden">
      {/* Left Sidebar */}
      <Sidebar />

      {/* Main Content */}
      <div className="flex-1 flex flex-col min-w-0 overflow-hidden">
        {/* Top Header */}
        <header className="px-8 pt-6 pb-4 flex items-start justify-between shrink-0">
          <div>
            <h1 className="text-[32px] text-[#101828] tracking-[-0.5px]">
              上传与识别
            </h1>
            <p className="text-[15px] text-[#667085] mt-1">
              将上传的文件匹配合适模版，生成标准化财务文件。
            </p>
          </div>
          {isTemplateView ? (
            <button className="inline-flex items-center gap-2 px-5 py-2.5 bg-[#0a6ed1] hover:bg-[#0858b0] text-white rounded-lg text-[15px] transition-colors shadow-sm">
              <Sparkles className="w-4 h-4" />
              免费试用
            </button>
          ) : (
            <button className="w-[44px] h-[44px] rounded-xl bg-[#f0f7ff] hover:bg-[#e0efff] flex items-center justify-center transition-colors group">
              <ArrowLeft className="w-5 h-5 text-[#0a6ed1] group-hover:-translate-x-0.5 transition-transform" />
            </button>
          )}
        </header>

        {/* Content Area */}
        {isTemplateView ? (
          <TemplateSelectionView onSelectTemplate={handleTemplateSelected} />
        ) : (
          <div className="flex-1 px-8 pb-4 flex gap-5 min-h-0 overflow-hidden">
            <UploadPanel />
            <ExcelFormPanel
              hasChanges={hasChanges}
              onChangeDetected={handleChangeDetected}
              onReset={handleReset}
            />
          </div>
        )}

        {/* Bottom Bar */}
        <div className="mx-8 mb-4 bg-white rounded-2xl border border-[#e5ecf5] px-8 py-3.5 flex items-center justify-between shrink-0 shadow-sm">
          <div className="flex items-center gap-2">
            <div className={`w-2 h-2 rounded-full ${isTemplateView ? "bg-[#0a6ed1]" : "bg-[#12b76a]"}`} />
            <span className="text-[15px] text-[#344054]">
              当前状态：<span className="text-[#101828]">{isTemplateView ? "已上传3个文档" : "已生成文档"}</span>
            </span>
          </div>
          <div className="flex items-center gap-6">
            <span className="text-[15px] text-[#344054]">
              {isTemplateView ? "下一步：选择模版进行生成" : "下一步：点击下载"}
            </span>
            {isTemplateView ? (
              <button
                onClick={handleTemplateSelected}
                className="inline-flex items-center gap-2 px-6 py-2.5 rounded-lg text-[15px] transition-colors shadow-sm bg-[#e5ecf5] text-[#98a2b3]"
              >
                开始生成
              </button>
            ) : (
              <button
                onClick={handleDownloadClick}
                disabled={!isButtonActive}
                className={`inline-flex items-center gap-2 px-6 py-2.5 rounded-lg text-[15px] transition-colors shadow-sm ${
                  isButtonActive
                    ? "bg-[#0a6ed1] hover:bg-[#0858b0] text-white cursor-pointer"
                    : "bg-[#e5ecf5] text-[#98a2b3] cursor-not-allowed"
                }`}
              >
                <Download className="w-4 h-4" />
                确认并下载
              </button>
            )}
          </div>
        </div>
      </div>

      {/* ── Modal Overlays ── */}
      {view === "downloadModal" && (
        <DownloadModal
          onClose={handleModalClose}
          onDownload={handleDownload}
        />
      )}

      {view === "success" && (
        <SuccessModal onClose={handleSuccessClose} />
      )}
    </div>
  );
}
