
  # Refine Excel Form UI

  This is a code bundle for Refine Excel Form UI. The original project is available at https://www.figma.com/design/IO62zRAEwhff33HIqrC0vp/Refine-Excel-Form-UI.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  